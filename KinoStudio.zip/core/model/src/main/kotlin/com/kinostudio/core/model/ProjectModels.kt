package com.kinostudio.core.model

import java.util.UUID

enum class AspectRatioPreset(val label: String, val widthRatio: Int, val heightRatio: Int) {
    RATIO_16_9("16:9", 16, 9),
    RATIO_9_16("9:16", 9, 16),
    RATIO_1_1("1:1", 1, 1),
    RATIO_4_5("4:5", 4, 5),
    RATIO_21_9("21:9", 21, 9),
    CUSTOM("Своё", 16, 9)
}

enum class ProjectResolutionPreset(val label: String, val shortSidePx: Int) {
    HD_720("720p HD", 720),
    FHD_1080("1080p Full HD", 1080),
    QHD_2K("2K QHD", 1440),
    UHD_4K("4K Ultra HD", 2160)
}

enum class MediaKind(val label: String) {
    VIDEO("Видео"),
    IMAGE("Фото"),
    AUDIO("Аудио")
}

enum class TrackKind(val label: String, val prefix: String) {
    VISUAL("Видео / Фото", "V"),
    TEXT("Текст / Субтитры", "T"),
    AUDIO("Звук", "A")
}

enum class TransitionType(val label: String) {
    NONE("Нет"),
    FADE_BLACK("Затемнение"),
    CROSS_DISSOLVE("Растворение"),
    SLIDE_LEFT("Сдвиг влево"),
    SLIDE_RIGHT("Сдвиг вправо"),
    ZOOM_IN("Приближение"),
    FLASH("Вспышка")
}

enum class ClipEdgeEffect(val label: String) {
    NONE("Нет"),
    FADE("Плавное"),
    ZOOM("Приближение"),
    SLIDE("Сдвиг"),
    FLASH("Вспышка")
}

enum class BackgroundMode(val label: String) {
    NONE("Оригинал"),
    TRANSPARENT("Прозрачный"),
    BLUR("Размытие"),
    COLOR("Цвет")
}

data class BackgroundPoint(
    val x: Float,
    val y: Float,
    val isPositive: Boolean
)

data class BackgroundConfig(
    val mode: BackgroundMode = BackgroundMode.NONE,
    val objectSelectionMode: Boolean = false,
    val invertMask: Boolean = false,
    val featherPx: Float = 2f,
    val contourPx: Float = 0f,
    val blurStrength: Float = 16f,
    val solidColorArgb: Long = 0xFF007ACCL,
    val points: List<BackgroundPoint> = emptyList()
)

data class LongTaskState(
    val title: String,
    val progressPercent: Int,
    val detail: String = "",
    val targetClipId: String? = null,
    val isCancellable: Boolean = true
)

enum class ColorPreset(val label: String) {
    NONE("Оригинал"),
    CINEMATIC("Кино"),
    TEAL_ORANGE("Teal & Orange"),
    VIVID("Насыщенный"),
    MOODY("Мрачный"),
    VINTAGE("Винтаж"),
    NOIR("Ч/Б Нуар"),
    WARM_SUNSET("Закат"),
    COLD_ARCTIC("Арктика")
}

data class TransformState(
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotationDeg: Float = 0f,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val opacity: Float = 1f,
    val tlX: Float = 0f,
    val tlY: Float = 0f,
    val trX: Float = 0f,
    val trY: Float = 0f,
    val blX: Float = 0f,
    val blY: Float = 0f,
    val brX: Float = 0f,
    val brY: Float = 0f
) {
    fun isIdentity(): Boolean =
        offsetX == 0f && offsetY == 0f &&
        scaleX == 1f && scaleY == 1f &&
        rotationDeg == 0f && !flipH && !flipV &&
        opacity == 1f && !hasPerspective()

    fun hasPerspective(): Boolean =
        tlX != 0f || tlY != 0f || trX != 0f || trY != 0f ||
        blX != 0f || blY != 0f || brX != 0f || brY != 0f
}

data class SpeedRampPoint(val positionFraction: Float, val speed: Float)

data class ColorGradingConfig(
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val exposure: Float = 0f,
    val saturation: Float = 1f,
    val temperature: Float = 0f,
    val tint: Float = 0f,
    val highlights: Float = 0f,
    val shadows: Float = 0f,
    val sharpen: Float = 0f,
    val vignette: Float = 0f,
    val hslHue: Float = 0f,
    val hslSaturation: Float = 0f,
    val hslLuminance: Float = 0f,
    val rgbRedGain: Float = 1f,
    val rgbGreenGain: Float = 1f,
    val rgbBlueGain: Float = 1f,
    val preset: ColorPreset = ColorPreset.NONE
) {
    fun isIdentity(): Boolean =
        brightness == 0f && contrast == 1f && exposure == 0f &&
        saturation == 1f && temperature == 0f && tint == 0f &&
        highlights == 0f && shadows == 0f && sharpen == 0f &&
        vignette == 0f && hslHue == 0f && hslSaturation == 0f &&
        hslLuminance == 0f && rgbRedGain == 1f && rgbGreenGain == 1f &&
        rgbBlueGain == 1f && preset == ColorPreset.NONE
}

data class BufferedMediaItem(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val displayName: String,
    val kind: MediaKind,
    val durationMs: Long = 4000L,
    val width: Int = 1920,
    val height: Int = 1080,
    val hasAudio: Boolean = false
)

data class TimelineTrack(
    val id: String = UUID.randomUUID().toString(),
    val kind: TrackKind,
    val name: String,
    val isHidden: Boolean = false,
    val isMuted: Boolean = false,
    val isLocked: Boolean = false
)

data class VisualClipItem(
    val id: String = UUID.randomUUID().toString(),
    val trackId: String,
    val sourceUri: String,
    val reversedUri: String? = null,
    val displayName: String = "Клип",
    val isImage: Boolean = false,
    val sourceDurationMs: Long = 5000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 5000L,
    val timelineStartMs: Long = 0L,
    val speed: Float = 1f,
    val speedRampPoints: List<SpeedRampPoint> = emptyList(),
    val isReversed: Boolean = false,
    val volume: Float = 1f,
    val isAudioMuted: Boolean = false,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val transform: TransformState = TransformState(),
    val colorGrading: ColorGradingConfig = ColorGradingConfig(),
    val transitionIn: TransitionType = TransitionType.NONE,
    val transitionDurationMs: Long = 500L,
    val edgeEffectIn: ClipEdgeEffect = ClipEdgeEffect.NONE,
    val edgeEffectInMs: Long = 500L,
    val edgeEffectOut: ClipEdgeEffect = ClipEdgeEffect.NONE,
    val edgeEffectOutMs: Long = 500L,
    val bgProcessedUri: String? = null,
    val bgMaskUri: String? = null,
    val backgroundConfig: BackgroundConfig = BackgroundConfig(),
    val isLocked: Boolean = false,
    val isHidden: Boolean = false
) {
    val rawVideoUri: String
        get() = if (!isImage && isReversed && !reversedUri.isNullOrBlank()) reversedUri else sourceUri

    val activeUri: String
        get() = when {
            !bgProcessedUri.isNullOrBlank() -> bgProcessedUri
            !isImage && isReversed && !reversedUri.isNullOrBlank() -> reversedUri
            else -> sourceUri
        }

    val hasTransparentVideoMask: Boolean
        get() = !isImage && backgroundConfig.mode == BackgroundMode.TRANSPARENT && !bgMaskUri.isNullOrBlank()

    val trimmedSourceDurationMs: Long
        get() = (trimEndMs - trimStartMs).coerceAtLeast(100L)

    val effectiveDurationMs: Long
        get() {
            if (isImage) return trimmedSourceDurationMs.coerceAtLeast(200L)
            val avgSpeed = if (speedRampPoints.size >= 2) {
                speedRampPoints.map { it.speed }.average().toFloat().coerceIn(0.25f, 8f)
            } else {
                speed.coerceIn(0.25f, 8f)
            }
            return (trimmedSourceDurationMs / avgSpeed).toLong().coerceAtLeast(100L)
        }

    val timelineEndMs: Long get() = timelineStartMs + effectiveDurationMs
}

data class TextTrackItem(
    val id: String = UUID.randomUUID().toString(),
    val trackId: String,
    val displayName: String = "Текст",
    val isSubtitle: Boolean = false,
    val timelineStartMs: Long = 0L,
    val durationMs: Long = 4000L,
    val studioOverlayJson: String = "",
    val transform: TransformState = TransformState(),
    val isLocked: Boolean = false,
    val isHidden: Boolean = false
) {
    val timelineEndMs: Long get() = timelineStartMs + durationMs.coerceAtLeast(200L)
}

data class AudioClipItem(
    val id: String = UUID.randomUUID().toString(),
    val trackId: String,
    val displayName: String = "Аудио",
    val sourceUri: String,
    val isVoiceover: Boolean = false,
    val sourceDurationMs: Long = 10000L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 10000L,
    val timelineStartMs: Long = 0L,
    val volume: Float = 0.9f,
    val isMuted: Boolean = false,
    val speed: Float = 1f,
    val fadeInMs: Long = 200L,
    val fadeOutMs: Long = 300L,
    val waveform: List<Float> = emptyList(),
    val isLocked: Boolean = false,
    val isHidden: Boolean = false
) {
    val effectiveDurationMs: Long
        get() = (((trimEndMs - trimStartMs).coerceAtLeast(100L)) / speed.coerceIn(0.25f, 4f)).toLong()
    val timelineEndMs: Long get() = timelineStartMs + effectiveDurationMs
}

data class VideoProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Новый проект",
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis(),
    val thumbnailPath: String? = null,
    val aspectRatio: AspectRatioPreset = AspectRatioPreset.RATIO_9_16,
    val resolutionPreset: ProjectResolutionPreset = ProjectResolutionPreset.FHD_1080,
    val projectWidth: Int = 1080,
    val projectHeight: Int = 1920,
    val mediaBuffer: List<BufferedMediaItem> = emptyList(),
    val tracks: List<TimelineTrack> = defaultTracks(),
    val visualClips: List<VisualClipItem> = emptyList(),
    val textItems: List<TextTrackItem> = emptyList(),
    val audioClips: List<AudioClipItem> = emptyList(),
    val globalColorGrading: ColorGradingConfig = ColorGradingConfig(),
    val magneticSnapEnabled: Boolean = true
) {
    val totalDurationMs: Long
        get() {
            val vEnd = visualClips.maxOfOrNull { it.timelineEndMs } ?: 0L
            val tEnd = textItems.maxOfOrNull { it.timelineEndMs } ?: 0L
            val aEnd = audioClips.maxOfOrNull { it.timelineEndMs } ?: 0L
            return maxOf(vEnd, tEnd, aEnd, 0L)
        }

    fun resolvedDimensions(): Pair<Int, Int> {
        val w = ((projectWidth / 2) * 2).coerceIn(360, 4096)
        val h = ((projectHeight / 2) * 2).coerceIn(360, 4096)
        return w to h
    }

    fun aspectLabel(): String {
        val (w, h) = resolvedDimensions()
        return if (aspectRatio == AspectRatioPreset.CUSTOM) "${w}x${h}" else "${aspectRatio.label} • ${w}x${h}"
    }

    companion object {
        fun computeDimensions(
            ratio: AspectRatioPreset,
            resolution: ProjectResolutionPreset,
            customW: Int = 1080,
            customH: Int = 1920
        ): Pair<Int, Int> {
            if (ratio == AspectRatioPreset.CUSTOM) {
                return ((customW.coerceIn(360, 4096)) / 2) * 2 to ((customH.coerceIn(360, 4096)) / 2) * 2
            }
            val shortSide = resolution.shortSidePx
            val rw = ratio.widthRatio
            val rh = ratio.heightRatio
            val rawW: Int
            val rawH: Int
            if (rw >= rh) {
                rawH = shortSide
                rawW = ((shortSide.toFloat() * rw) / rh).toInt()
            } else {
                rawW = shortSide
                rawH = ((shortSide.toFloat() * rh) / rw).toInt()
            }
            return ((rawW / 2) * 2).coerceIn(360, 4096) to ((rawH / 2) * 2).coerceIn(360, 4096)
        }

        fun defaultTracks(): List<TimelineTrack> = listOf(
            TimelineTrack(id = "track_v1", kind = TrackKind.VISUAL, name = "V1")
        )
    }
}

enum class ExportCodec(val label: String, val mimeType: String) {
    H264("H.264 (AVC)", "video/avc"),
    H265("H.265 (HEVC)", "video/hevc")
}

enum class ExportContainer(val label: String, val extension: String) {
    MP4("MP4", "mp4"),
    MOV("MOV", "mov")
}

data class ExportConfig(
    val resolution: ProjectResolutionPreset = ProjectResolutionPreset.FHD_1080,
    val fps: Int = 30,
    val codec: ExportCodec = ExportCodec.H264,
    val container: ExportContainer = ExportContainer.MP4,
    val videoBitrateMbps: Float = 16f,
    val audioBitrateKbps: Int = 256
)

sealed interface ExportStatus {
    data object Idle : ExportStatus
    data class Running(val progressPercent: Int, val stageLabel: String = "Рендеринг...") : ExportStatus
    data class Completed(val outputUri: String, val fileName: String, val durationMs: Long) : ExportStatus
    data class Failed(val errorMessage: String) : ExportStatus
    data object Cancelled : ExportStatus
}
