package com.kinostudio.core.hardware

import android.app.Activity
import android.content.Context
import android.media.MediaCodecList
import android.os.Build
import android.os.PowerManager
import android.view.Display
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

enum class SocPlatform(val displayName: String) {
    SNAPDRAGON_8_GEN_3("Snapdragon 8 Gen 3"),
    EXYNOS_2400("Exynos 2400"),
    GENERIC_ARM64("Android SoC")
}

enum class ThermalState(val label: String, val scaleFactor: Float) {
    NOMINAL("Оптимально", 1.0f),
    MODERATE("Нагрев", 0.85f),
    SEVERE("Троттлинг", 0.65f),
    CRITICAL("Перегрев", 0.50f)
}

data class DeviceHardwareProfile(
    val isGalaxyS24Family: Boolean,
    val socPlatform: SocPlatform,
    val modelName: String,
    val supportedRefreshRates: List<Float>,
    val activeRefreshRate: Float,
    val preferredAvcEncoder: String?,
    val preferredHevcEncoder: String?,
    val maxConcurrentDecoders: Int
)

class GalaxyS24Optimizer(private val context: Context) {
    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    private val _thermalState = MutableStateFlow(ThermalState.NOMINAL)
    val thermalState: StateFlow<ThermalState> = _thermalState.asStateFlow()
    private var thermalListener: Any? = null

    fun detectHardwareProfile(activity: Activity? = null): DeviceHardwareProfile {
        val model = Build.MODEL.orEmpty()
        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Build.SOC_MODEL.orEmpty() else Build.HARDWARE.orEmpty()
        val combined = "$model $socModel ${Build.HARDWARE.orEmpty()} ${Build.BOARD.orEmpty()}".lowercase()

        val isS24 = model.startsWith("SM-S921", true) || model.startsWith("SM-S926", true) || model.startsWith("SM-S928", true) ||
            combined.contains("e1q") || combined.contains("e2q") || combined.contains("e3q") || combined.contains("e1s") || combined.contains("e2s")

        val soc = when {
            combined.contains("sm8650") || combined.contains("pineapple") || (isS24 && combined.contains("qcom")) -> SocPlatform.SNAPDRAGON_8_GEN_3
            combined.contains("s5e9945") || combined.contains("exynos2400") || combined.contains("exynos 2400") || (isS24 && combined.contains("exynos")) -> SocPlatform.EXYNOS_2400
            else -> SocPlatform.GENERIC_ARM64
        }

        val display = resolveDisplay(activity)
        val supportedRates = display?.supportedModes?.map { it.refreshRate }?.distinctBy { it.toInt() }?.sorted() ?: listOf(60f)
        val activeRate = display?.refreshRate ?: 60f
        val preferredPrefix = when (soc) {
            SocPlatform.SNAPDRAGON_8_GEN_3 -> listOf("c2.qti.", "omx.qcom.")
            SocPlatform.EXYNOS_2400 -> listOf("c2.exynos.", "c2.sec.", "omx.exynos.")
            SocPlatform.GENERIC_ARM64 -> listOf("c2.qti.", "c2.exynos.", "c2.mtk.", "c2.android.")
        }

        return DeviceHardwareProfile(
            isGalaxyS24Family = isS24,
            socPlatform = soc,
            modelName = model.ifBlank { "Android Device" },
            supportedRefreshRates = supportedRates,
            activeRefreshRate = activeRate,
            preferredAvcEncoder = findHardwareEncoder("video/avc", preferredPrefix),
            preferredHevcEncoder = findHardwareEncoder("video/hevc", preferredPrefix),
            maxConcurrentDecoders = if (soc == SocPlatform.SNAPDRAGON_8_GEN_3) 6 else 4
        )
    }

    fun applyPreferredRefreshRate(activity: Activity, enableHighRefreshRate: Boolean): Float {
        val powerSave = powerManager?.isPowerSaveMode == true
        val targetHz = when {
            powerSave || !enableHighRefreshRate -> 60f
            _thermalState.value == ThermalState.CRITICAL -> 60f
            _thermalState.value == ThermalState.SEVERE -> 90f
            else -> 120f
        }
        val display = resolveDisplay(activity) ?: return 60f
        val modes = display.supportedModes
        if (modes.isNullOrEmpty()) return display.refreshRate
        val currentMode = display.mode
        val sameRes = modes.filter { it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight }.ifEmpty { modes.toList() }
        val bestMode = sameRes.filter { it.refreshRate <= targetHz + 1f }.maxByOrNull { it.refreshRate }
            ?: sameRes.minByOrNull { abs(it.refreshRate - targetHz) } ?: currentMode
        runCatching {
            val attrs = activity.window.attributes
            if (attrs.preferredDisplayModeId != bestMode.modeId) {
                attrs.preferredDisplayModeId = bestMode.modeId
                activity.window.attributes = attrs
            }
        }
        return bestMode.refreshRate
    }

    fun startThermalMonitoring() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val pm = powerManager ?: return
        updateThermalStatus(pm.currentThermalStatus)
        if (thermalListener != null) return
        val listener = PowerManager.OnThermalStatusChangedListener { status -> updateThermalStatus(status) }
        thermalListener = listener
        runCatching { pm.addThermalStatusListener(listener) }
    }

    fun stopThermalMonitoring() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val listener = thermalListener as? PowerManager.OnThermalStatusChangedListener ?: return
        runCatching { powerManager?.removeThermalStatusListener(listener) }
        thermalListener = null
    }

    private fun updateThermalStatus(status: Int) {
        _thermalState.value = when {
            status >= PowerManager.THERMAL_STATUS_CRITICAL -> ThermalState.CRITICAL
            status >= PowerManager.THERMAL_STATUS_SEVERE -> ThermalState.SEVERE
            status >= PowerManager.THERMAL_STATUS_MODERATE -> ThermalState.MODERATE
            else -> ThermalState.NOMINAL
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveDisplay(activity: Activity?): Display? =
        if (activity != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) activity.display else activity.windowManager.defaultDisplay
        } else null

    private fun findHardwareEncoder(mimeType: String, preferredPrefixes: List<String>): String? {
        return runCatching {
            val codecInfos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(mimeType, true) } &&
                    (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || info.isHardwareAccelerated)
            }
            for (prefix in preferredPrefixes) {
                codecInfos.firstOrNull { it.name.lowercase().startsWith(prefix) }?.let { return@runCatching it.name }
            }
            codecInfos.firstOrNull()?.name
        }.getOrNull()
    }
}
