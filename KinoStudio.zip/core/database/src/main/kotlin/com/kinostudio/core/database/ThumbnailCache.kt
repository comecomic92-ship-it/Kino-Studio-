package com.kinostudio.core.database

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ThumbnailCache(private val context: Context) {
    private val maxMemoryKb = (Runtime.getRuntime().maxMemory() / 1024L).toInt()
    private val cacheSizeKb = (maxMemoryKb / 8).coerceIn(24_576, 81_920)
    private val decodeSemaphore = Semaphore(2)

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSizeKb) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }

    suspend fun getFilmstripFrames(
        uriString: String,
        trimStartMs: Long,
        trimEndMs: Long,
        frameCount: Int,
        tileWidth: Int = 112,
        tileHeight: Int = 72
    ): List<Bitmap?> = withContext(Dispatchers.IO) {
        val count = frameCount.coerceIn(1, 20)
        val spanMs = (trimEndMs - trimStartMs).coerceAtLeast(100L)
        val timesUs = List(count) { idx ->
            val frac = if (count == 1) 0f else idx.toFloat() / (count - 1).toFloat()
            val ms = trimStartMs + (spanMs * frac).toLong()
            ((ms / 250L) * 250L) * 1000L
        }

        val result = MutableList<Bitmap?>(count) { null }
        val missingIndices = mutableListOf<Int>()
        for (i in 0 until count) {
            val key = "${uriString.hashCode()}_${timesUs[i]}_${tileWidth}x$tileHeight"
            val cached = memoryCache.get(key)
            if (cached != null && !cached.isRecycled) result[i] = cached
            else missingIndices += i
        }
        if (missingIndices.isEmpty()) return@withContext result

        decodeSemaphore.withPermit {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(uriString))
                for (i in missingIndices) {
                    val tUs = timesUs[i]
                    val key = "${uriString.hashCode()}_${tUs}_${tileWidth}x$tileHeight"
                    val cachedNow = memoryCache.get(key)
                    if (cachedNow != null && !cachedNow.isRecycled) {
                        result[i] = cachedNow
                        continue
                    }
                    val raw = runCatching {
                        retriever.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }.getOrNull()
                    if (raw != null) {
                        val scaled = Bitmap.createScaledBitmap(raw, tileWidth, tileHeight, true)
                        if (scaled !== raw) raw.recycle()
                        memoryCache.put(key, scaled)
                        result[i] = scaled
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { retriever.release() }
            }
        }
        result
    }

    suspend fun getImageBitmap(uriString: String, maxDimension: Int = 1080): Bitmap? = withContext(Dispatchers.IO) {
        val key = "img_${uriString.hashCode()}_$maxDimension"
        memoryCache.get(key)?.let { if (!it.isRecycled) return@withContext it }

        decodeSemaphore.withPermit {
            runCatching {
                val uri = Uri.parse(uriString)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, bounds)
                }
                var sample = 1
                while (bounds.outWidth / sample > maxDimension * 2 || bounds.outHeight / sample > maxDimension * 2) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val decoded = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, opts)
                } ?: return@runCatching null
                val out = if (decoded.width > maxDimension || decoded.height > maxDimension) {
                    val scale = maxDimension.toFloat() / maxOf(decoded.width, decoded.height).toFloat()
                    val sw = (decoded.width * scale).toInt().coerceAtLeast(2)
                    val sh = (decoded.height * scale).toInt().coerceAtLeast(2)
                    val scaled = Bitmap.createScaledBitmap(decoded, sw, sh, true)
                    if (scaled !== decoded) decoded.recycle()
                    scaled
                } else decoded
                memoryCache.put(key, out)
                out
            }.getOrNull()
        }
    }

    suspend fun saveProjectCover(projectId: String, uriString: String, isImage: Boolean): String? =
        withContext(Dispatchers.IO) {
            val bmp = if (isImage) getImageBitmap(uriString, 480)
            else getFilmstripFrames(uriString, 0L, 1000L, 1, 480, 270).firstOrNull()
            if (bmp == null) return@withContext null
            val dir = File(context.filesDir, "project_thumbs").apply { mkdirs() }
            val file = File(dir, "$projectId.jpg")
            runCatching {
                FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 85, out) }
                file.absolutePath
            }.getOrNull()
        }

    fun trimMemory(aggressive: Boolean) {
        if (aggressive) memoryCache.evictAll()
        else memoryCache.trimToSize(memoryCache.maxSize() / 2)
    }
}
