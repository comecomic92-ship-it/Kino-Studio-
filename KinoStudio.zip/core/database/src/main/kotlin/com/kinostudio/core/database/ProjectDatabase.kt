package com.kinostudio.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "kino_projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAtMs: Long,
    val updatedAtMs: Long,
    val thumbnailPath: String?,
    val aspectRatioLabel: String,
    val durationMs: Long,
    val payloadJson: String
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM kino_projects ORDER BY updatedAtMs DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM kino_projects WHERE id = :projectId LIMIT 1")
    suspend fun getById(projectId: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ProjectEntity)

    @Query("UPDATE kino_projects SET name = :newName, updatedAtMs = :updatedAtMs, payloadJson = :payloadJson WHERE id = :projectId")
    suspend fun rename(projectId: String, newName: String, updatedAtMs: Long, payloadJson: String)

    @Query("DELETE FROM kino_projects WHERE id = :projectId")
    suspend fun deleteById(projectId: String)
}

@Database(entities = [ProjectEntity::class], version = 2, exportSchema = false)
abstract class ProjectDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var INSTANCE: ProjectDatabase? = null

        fun getInstance(context: Context): ProjectDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ProjectDatabase::class.java,
                    "kinostudio_projects.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}
