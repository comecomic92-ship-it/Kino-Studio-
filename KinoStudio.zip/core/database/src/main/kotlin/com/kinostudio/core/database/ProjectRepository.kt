package com.kinostudio.core.database

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.kinostudio.core.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

private val Context.kinoDataStore by preferencesDataStore(name = "kinostudio_prefs")

data class ProjectSummary(
    val id: String,
    val name: String,
    val updatedAtMs: Long,
    val thumbnailPath: String?,
    val aspectRatioLabel: String,
    val durationMs: Long
)

class ProjectRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dao = ProjectDatabase.getInstance(appContext).projectDao()
    private val gson: Gson = GsonBuilder().serializeNulls().create()

    private object Keys {
        val LAST_OPENED_PROJECT_ID = stringPreferencesKey("last_opened_project_id")
        val HIGH_REFRESH_RATE = booleanPreferencesKey("high_refresh_rate_enabled")
    }

    fun observeProjectSummaries(): Flow<List<ProjectSummary>> {
        return dao.observeAll().map { entities ->
            entities.map { entity ->
                ProjectSummary(
                    id = entity.id,
                    name = entity.name,
                    updatedAtMs = entity.updatedAtMs,
                    thumbnailPath = entity.thumbnailPath,
                    aspectRatioLabel = entity.aspectRatioLabel,
                    durationMs = entity.durationMs
                )
            }
        }
    }

    suspend fun saveProject(project: VideoProject) = withContext(Dispatchers.IO) {
        val updated = project.copy(updatedAtMs = System.currentTimeMillis())
        val entity = ProjectEntity(
            id = updated.id,
            name = updated.name,
            createdAtMs = updated.createdAtMs,
            updatedAtMs = updated.updatedAtMs,
            thumbnailPath = updated.thumbnailPath,
            aspectRatioLabel = updated.aspectLabel(),
            durationMs = updated.totalDurationMs,
            payloadJson = gson.toJson(updated)
        )
        dao.upsert(entity)
    }

    suspend fun loadProject(projectId: String): VideoProject? = withContext(Dispatchers.IO) {
        val entity = dao.getById(projectId) ?: return@withContext null
        runCatching {
            val parsed = gson.fromJson(entity.payloadJson, VideoProject::class.java)
            if (parsed.tracks.isEmpty()) parsed.copy(tracks = VideoProject.defaultTracks()) else parsed
        }.getOrNull()
    }

    suspend fun renameProject(projectId: String, newName: String) = withContext(Dispatchers.IO) {
        val current = loadProject(projectId) ?: return@withContext
        val updated = current.copy(name = newName.trim().ifEmpty { current.name }, updatedAtMs = System.currentTimeMillis())
        dao.rename(projectId, updated.name, updated.updatedAtMs, gson.toJson(updated))
    }

    suspend fun deleteProject(projectId: String) = withContext(Dispatchers.IO) {
        dao.deleteById(projectId)
        if (getLastOpenedProjectId() == projectId) setLastOpenedProjectId(null)
    }

    suspend fun setLastOpenedProjectId(projectId: String?) {
        appContext.kinoDataStore.edit { prefs ->
            if (projectId == null) prefs.remove(Keys.LAST_OPENED_PROJECT_ID)
            else prefs[Keys.LAST_OPENED_PROJECT_ID] = projectId
        }
    }

    suspend fun getLastOpenedProjectId(): String? =
        appContext.kinoDataStore.data.first()[Keys.LAST_OPENED_PROJECT_ID]

    fun observeHighRefreshRatePref(): Flow<Boolean> =
        appContext.kinoDataStore.data.map { prefs -> prefs[Keys.HIGH_REFRESH_RATE] ?: true }

    suspend fun setHighRefreshRatePref(enabled: Boolean) {
        appContext.kinoDataStore.edit { prefs -> prefs[Keys.HIGH_REFRESH_RATE] = enabled }
    }
}
