@file:Suppress("unused", "MemberVisibilityCanBePrivate")

package com.layerstudio.kit

// ============================================================================
// LayerStudioTextAndDesignKit.kt
// Единый автономный файл для импорта:
//   1. Общей дизайн-системы семейства Layer Studio (цвета, формы, отступы, тема, значки, кнопки, слайдеры, палитра)
//   2. Полной системы текста Layer Studio v7.3 (18 шрифтов + .TTF/.OTF, прямой и дуговой текст без смещения,
//      горизонтальное и вертикальное выравнивание, обводка, градиент, тень, WYSIWYG-редактор на превью,
//      панель «Стиль текста», JSON-сохранение и рендеринг на кадр видео по таймкоду)
//
// Как подключить в свой проект:
//   1. Скопируйте файл в app/src/main/java/<ваш_пакет>/ (при желании поменяйте package в строке 3).
//   2. Убедитесь, что в app/build.gradle.kts подключены:
//        implementation("androidx.compose.material3:material3")
//        implementation("androidx.compose.material:material-icons-extended")
//   3. В Activity на корневом контейнере добавьте Modifier.imePadding(), чтобы клавиатура не закрывала панель текста.
//   4. Оберните приложение в LayerStudioTheme { ... }.
// ============================================================================

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.AutoFixNormal
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Contrast
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HorizontalRule
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerticalAlignBottom
import androidx.compose.material.icons.filled.VerticalAlignCenter
import androidx.compose.material.icons.filled.VerticalAlignTop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Typeface as ComposeTypeface
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

// ============================================================================
// 1. ОБЩИЙ ДИЗАЙН СЕМЕЙСТВА LAYER STUDIO (Цвета, Формы, Отступы, Тема, Значки)
// ============================================================================

object StudioColors {
    // Базовая тёмная графитовая палитра (идентична фоторедактору Layer Studio)
    val BgBlack = Color(0xFF121212)
    val BgDarkGray = Color(0xFF1E1E1E)
    val BgGraphite = Color(0xFF252526)
    val BgPanel = Color(0xFF2D2D30)
    val BorderSubtle = Color(0xFF3E3E42)

    // Фирменные акценты и состояния
    val AccentBlue = Color(0xFF007ACC)
    val AccentLightBlue = Color(0xFF3794FF)
    val TextPrimary = Color(0xFFF0F0F0)
    val TextSecondary = Color(0xFFA0A0A5)
    val DangerRed = Color(0xFFE05252)
    val SuccessGreen = Color(0xFF4EC9B0)
    val WarningOrange = Color(0xFFFF9800)

    // Направляющие и выделение на превью
    val GuideCenterMagenta = Color(0xFFFF2A85)
    val GuideEdgeCyan = Color(0xFF00E5FF)
    val OverlayScrim = Color(0x66000000)

    // Цвета дорожек таймлайна в едином стиле семейства Layer Studio
    val TrackVideo = Color(0xFF1F4E78)
    val TrackAudio = Color(0xFF1F5B4F)
    val TrackText = Color(0xFF53346D)
    val TrackOverlay = Color(0xFF5C4422)
}

object StudioShapes {
    val TextFrame = RoundedCornerShape(2.dp)
    val Micro = RoundedCornerShape(3.dp)
    val Small = RoundedCornerShape(4.dp)
    val Button = RoundedCornerShape(5.dp)
    val Chip = RoundedCornerShape(6.dp)
    val ToolSlot = RoundedCornerShape(8.dp)
    val Panel = RoundedCornerShape(8.dp)
    val Card = RoundedCornerShape(10.dp)
    val Badge = RoundedCornerShape(12.dp)
    val Pill = RoundedCornerShape(16.dp)
    val Circle = CircleShape
}

object StudioDimens {
    val TopBarHeight = 50.dp
    val DesktopMenuBarHeight = 36.dp
    val ToolOptionsStripHeight = 20.dp
    val ToolOptionsRowHeight = 46.dp
    val MobileDockHeight = 60.dp
    val VerticalDockWidth = 68.dp
    val DesktopToolbarWidth = 86.dp

    val ToolSlotWidth = 58.dp
    val ToolSlotHeight = 50.dp
    val ToolIconSize = 20.dp
    val DesktopSlotSize = 36.dp
    val DesktopIconSize = 18.dp
    val SmallChipIconSize = 14.dp
    val ResizeHandleSize = 20.dp
    val InspectorMaxHeight = 240.dp
}

private val DarkStudioColorScheme = darkColorScheme(
    primary = StudioColors.AccentBlue,
    onPrimary = Color.White,
    secondary = StudioColors.AccentLightBlue,
    onSecondary = Color.White,
    background = StudioColors.BgBlack,
    onBackground = StudioColors.TextPrimary,
    surface = StudioColors.BgDarkGray,
    onSurface = StudioColors.TextPrimary,
    surfaceVariant = StudioColors.BgPanel,
    onSurfaceVariant = StudioColors.TextSecondary,
    outline = StudioColors.BorderSubtle,
    error = StudioColors.DangerRed
)

@Composable
fun LayerStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkStudioColorScheme,
        content = content
    )
}

/**
 * Единый справочник иконок семейства Layer Studio (фото + видео)
 */
object StudioIcons {
    // Общие инструменты редактора
    val Move: ImageVector = Icons.Default.OpenWith
    val Transform: ImageVector = Icons.Default.Transform
    val Crop: ImageVector = Icons.Default.Crop
    val SelectRect: ImageVector = Icons.Default.CropSquare
    val SelectCircle: ImageVector = Icons.Default.RadioButtonUnchecked
    val SelectLasso: ImageVector = Icons.Default.Gesture
    val SelectObjectAi: ImageVector = Icons.Default.CenterFocusStrong
    val MagicWand: ImageVector = Icons.Default.AutoFixHigh
    val Brush: ImageVector = Icons.Default.Brush
    val Eraser: ImageVector = Icons.Default.AutoFixNormal
    val Fill: ImageVector = Icons.Default.FormatColorFill
    val Eyedropper: ImageVector = Icons.Default.Colorize
    val Text: ImageVector = Icons.Default.TextFields
    val Shape: ImageVector = Icons.Default.Category
    val LayerFx: ImageVector = Icons.Default.AutoAwesome
    val Adjust: ImageVector = Icons.Default.Tune
    val Filters: ImageVector = Icons.Default.AutoAwesome
    val Mask: ImageVector = Icons.Default.Contrast

    // Текст и шрифты
    val Font: ImageVector = Icons.Default.FontDownload
    val AlignLeft: ImageVector = Icons.Default.FormatAlignLeft
    val AlignCenter: ImageVector = Icons.Default.FormatAlignCenter
    val AlignRight: ImageVector = Icons.Default.FormatAlignRight
    val VerticalTop: ImageVector = Icons.Default.VerticalAlignTop
    val VerticalCenter: ImageVector = Icons.Default.VerticalAlignCenter
    val VerticalBottom: ImageVector = Icons.Default.VerticalAlignBottom
    val Palette: ImageVector = Icons.Default.Palette

    // Видеоредактор (в том же визуальном стиле)
    val Video: ImageVector = Icons.Default.Videocam
    val Timeline: ImageVector = Icons.Default.Movie
    val SplitClip: ImageVector = Icons.Default.ContentCut
    val Audio: ImageVector = Icons.Default.MusicNote
    val Waveform: ImageVector = Icons.Default.GraphicEq
    val Volume: ImageVector = Icons.Default.VolumeUp
    val Speed: ImageVector = Icons.Default.Speed
    val Play: ImageVector = Icons.Default.PlayArrow
    val Pause: ImageVector = Icons.Default.Pause
    val PrevFrame: ImageVector = Icons.Default.SkipPrevious
    val NextFrame: ImageVector = Icons.Default.SkipNext

    // Панели и действия
    val Layers: ImageVector = Icons.Default.Layers
    val Undo: ImageVector = Icons.AutoMirrored.Filled.Undo
    val Redo: ImageVector = Icons.AutoMirrored.Filled.Redo
    val History: ImageVector = Icons.Default.History
    val Save: ImageVector = Icons.Default.Save
    val Export: ImageVector = Icons.Default.Download
    val Projects: ImageVector = Icons.Default.Folder
    val OpenFile: ImageVector = Icons.Default.FolderOpen
    val DesktopDex: ImageVector = Icons.Default.DesktopWindows
    val Add: ImageVector = Icons.Default.Add
    val Delete: ImageVector = Icons.Default.Delete
    val Check: ImageVector = Icons.Default.Check
    val Close: ImageVector = Icons.Default.Close
}

// ============================================================================
// 2. ТРЕКЕР ФОКУСА ТЕКСТОВЫХ ПОЛЕЙ (защита от перехвата Backspace / Delete)
// ============================================================================

/**
 * Используйте `TextInputFocusTracker.isAnyTextFieldFocused` в `Activity.dispatchKeyEvent`,
 * чтобы клавиши Backspace / Delete и буквенные хоткеи никогда не срабатывали,
 * пока пользователь печатает текст в любом Compose-поле.
 */
object TextInputFocusTracker {
    private val focusedTokens = ConcurrentHashMap.newKeySet<Int>()
    private val nextId = AtomicInteger(1)

    val isAnyTextFieldFocused: Boolean
        get() = focusedTokens.isNotEmpty()

    fun acquireToken(): Int = nextId.getAndIncrement()

    fun setFocused(token: Int, focused: Boolean) {
        if (focused) focusedTokens.add(token) else focusedTokens.remove(token)
    }

    fun release(token: Int) {
        focusedTokens.remove(token)
    }
}

fun Modifier.trackTextInputFocus(): Modifier = composed {
    val token = remember { TextInputFocusTracker.acquireToken() }
    DisposableEffect(token) {
        onDispose { TextInputFocusTracker.release(token) }
    }
    this.onFocusChanged { focusState ->
        TextInputFocusTracker.setFocused(token, focusState.isFocused)
    }
}

// ============================================================================
// 3. МОДЕЛИ ТЕКСТА, 18 ШРИФТОВ И JSON-СЕРИАЛИЗАЦИЯ
// ============================================================================

enum class LayerFontFamily(
    val displayName: String,
    val familyName: String,
    val weight: Int,
    val defaultItalic: Boolean = false,
    val scaleX: Float = 1f,
    val baseLetterSpacing: Float = 0f,
    val fontFeatureSettings: String? = null,
    val sampleSubtitle: String = "Аа Бб Вв 123"
) {
    SANS_SERIF("Sans Serif (Стандарт)", "sans-serif", 400, sampleSubtitle = "Чистый современный гротеск"),
    SERIF("Serif (Классика с засечками)", "serif", 400, sampleSubtitle = "Книжный шрифт с засечками"),
    MONOSPACE("Monospace (Печатная машинка)", "monospace", 400, sampleSubtitle = "Моноширинный код и ретро"),
    CURSIVE("Cursive (Каллиграфия)", "cursive", 400, sampleSubtitle = "Рукописный изящный росчерк"),
    DISPLAY("Display Impact (Плакатный)", "sans-serif-black", 900, scaleX = 0.92f, sampleSubtitle = "Мощный шрифт для заголовков и мемов"),
    CONDENSED("Condensed (Узкий высокий)", "sans-serif-condensed", 700, scaleX = 0.82f, sampleSubtitle = "Компактный высокий постерный стиль"),
    CONDENSED_LIGHT("Condensed Light (Тонкий узкий)", "sans-serif-condensed-light", 300, scaleX = 0.85f, sampleSubtitle = "Лёгкий вытянутый силуэт"),
    LIGHT_CLEAN("Thin Modern (Ультратонкий)", "sans-serif-thin", 200, baseLetterSpacing = 0.05f, sampleSubtitle = "Воздушный минимализм"),
    MEDIUM_GEOMETRIC("Geometric Medium (Геометрия)", "sans-serif-medium", 500, baseLetterSpacing = 0.02f, sampleSubtitle = "Сбалансированный интерфейсный"),
    BLACK_HEAVY("Ultra Heavy (Сверхжирный)", "sans-serif-black", 900, scaleX = 1.08f, sampleSubtitle = "Максимальный вес для баннеров"),
    WIDE_EXPANDED("Expanded Wide (Широкий)", "sans-serif-medium", 700, scaleX = 1.28f, baseLetterSpacing = 0.06f, sampleSubtitle = "Растянутый футуристичный"),
    SMALL_CAPS("Small Caps (Капитель)", "serif", 600, fontFeatureSettings = "smcp", baseLetterSpacing = 0.08f, sampleSubtitle = "Строчные буквы как малые заглавные"),
    SERIF_ITALIC_ELEGANT("Editorial Italic (Журнальный)", "serif", 400, defaultItalic = true, sampleSubtitle = "Элегантный глянцевый курсив"),
    SLAB_SERIF("Slab Serif (Брусковый)", "serif-monospace", 700, scaleX = 1.05f, sampleSubtitle = "Плотные индустриальные засечки"),
    CASUAL_SCRIPT("Casual Script (Живой почерк)", "casual", 400, sampleSubtitle = "Непринуждённый рукописный стиль"),
    COMIC_ROUND("Rounded Pop (Мягкий поп-арт)", "casual", 700, scaleX = 1.06f, sampleSubtitle = "Дружелюбный округлый шрифт"),
    RETRO_PIXEL("Tech Mono (Техно-терминал)", "monospace", 700, scaleX = 0.9f, baseLetterSpacing = 0.1f, sampleSubtitle = "Киберпанк и цифровые штампы"),
    CINEMATIC_TRAILER("Cinematic (Кинотрейлер)", "sans-serif-light", 300, scaleX = 1.12f, baseLetterSpacing = 0.28f, sampleSubtitle = "Широкая разрядка как в титрах кино")
}

enum class TextAlignment(val displayName: String) {
    LEFT("Влево"),
    CENTER("По центру"),
    RIGHT("Вправо")
}

enum class TextVerticalAlignment(val displayName: String) {
    TOP("Сверху"),
    CENTER("По центру"),
    BOTTOM("Снизу")
}

data class TextStyleConfig(
    val text: String = "Новый текст",
    val fontFamily: LayerFontFamily = LayerFontFamily.SANS_SERIF,
    val customFontPath: String? = null,
    val customFontName: String? = null,
    val fontSize: Float = 56f,
    val color: Int = AndroidColor.WHITE,
    val useGradient: Boolean = false,
    val gradientEndColor: Int = 0xFF3794FF.toInt(),
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val alignment: TextAlignment = TextAlignment.CENTER,
    val verticalAlignment: TextVerticalAlignment = TextVerticalAlignment.CENTER,
    val lineSpacingMultiplier: Float = 1.15f,
    val strokeColor: Int = AndroidColor.BLACK,
    val strokeWidth: Float = 0f,
    val shadowColor: Int = 0xB4000000.toInt(),
    val shadowRadius: Float = 0f,
    val shadowDx: Float = 4f,
    val shadowDy: Float = 4f,
    val arcAngle: Float = 0f,      // -359f..359f градусов
    val letterSpacing: Float = 0f, // -0.2f..1.0f em
    val boxWidth: Float = 480f,    // ширина рамки в пикселях видео/холста
    val boxHeight: Float = 160f    // высота рамки в пикселях видео/холста
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("text", text)
        put("fontFamily", fontFamily.name)
        put("customFontPath", customFontPath ?: "")
        put("customFontName", customFontName ?: "")
        put("fontSize", fontSize.toDouble())
        put("color", color)
        put("useGradient", useGradient)
        put("gradientEndColor", gradientEndColor)
        put("isBold", isBold)
        put("isItalic", isItalic)
        put("alignment", alignment.name)
        put("verticalAlignment", verticalAlignment.name)
        put("lineSpacingMultiplier", lineSpacingMultiplier.toDouble())
        put("strokeColor", strokeColor)
        put("strokeWidth", strokeWidth.toDouble())
        put("shadowColor", shadowColor)
        put("shadowRadius", shadowRadius.toDouble())
        put("shadowDx", shadowDx.toDouble())
        put("shadowDy", shadowDy.toDouble())
        put("arcAngle", arcAngle.toDouble())
        put("letterSpacing", letterSpacing.toDouble())
        put("boxWidth", boxWidth.toDouble())
        put("boxHeight", boxHeight.toDouble())
    }

    companion object {
        fun fromJson(obj: JSONObject): TextStyleConfig {
            val rawFont = obj.optString("fontFamily", LayerFontFamily.SANS_SERIF.name)
            val fontEnum = LayerFontFamily.entries.find { it.name == rawFont } ?: LayerFontFamily.SANS_SERIF
            val rawAlign = obj.optString("alignment", TextAlignment.CENTER.name)
            val alignEnum = TextAlignment.entries.find { it.name == rawAlign } ?: TextAlignment.CENTER
            val rawVAlign = obj.optString("verticalAlignment", TextVerticalAlignment.CENTER.name)
            val vAlignEnum = TextVerticalAlignment.entries.find { it.name == rawVAlign } ?: TextVerticalAlignment.CENTER
            return TextStyleConfig(
                text = obj.optString("text", ""),
                fontFamily = fontEnum,
                customFontPath = obj.optString("customFontPath", "").ifEmpty { null },
                customFontName = obj.optString("customFontName", "").ifEmpty { null },
                fontSize = obj.optDouble("fontSize", 56.0).toFloat(),
                color = obj.optInt("color", AndroidColor.WHITE),
                useGradient = obj.optBoolean("useGradient", false),
                gradientEndColor = obj.optInt("gradientEndColor", 0xFF3794FF.toInt()),
                isBold = obj.optBoolean("isBold", false),
                isItalic = obj.optBoolean("isItalic", false),
                alignment = alignEnum,
                verticalAlignment = vAlignEnum,
                lineSpacingMultiplier = obj.optDouble("lineSpacingMultiplier", 1.15).toFloat(),
                strokeColor = obj.optInt("strokeColor", AndroidColor.BLACK),
                strokeWidth = obj.optDouble("strokeWidth", 0.0).toFloat(),
                shadowColor = obj.optInt("shadowColor", 0xB4000000.toInt()),
                shadowRadius = obj.optDouble("shadowRadius", 0.0).toFloat(),
                shadowDx = obj.optDouble("shadowDx", 4.0).toFloat(),
                shadowDy = obj.optDouble("shadowDy", 4.0).toFloat(),
                arcAngle = obj.optDouble("arcAngle", 0.0).toFloat(),
                letterSpacing = obj.optDouble("letterSpacing", 0.0).toFloat(),
                boxWidth = obj.optDouble("boxWidth", 480.0).toFloat(),
                boxHeight = obj.optDouble("boxHeight", 160.0).toFloat()
            )
        }
    }
}

/**
 * Универсальный текстовый слой/титр для видеоредактора (с таймкодами startTimeMs..endTimeMs).
 */
data class StudioTextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Текст",
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val rotation: Float = 0f,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,
    val opacity: Float = 1f,
    val isVisible: Boolean = true,
    val isLocked: Boolean = false,
    val startTimeMs: Long = 0L,
    val endTimeMs: Long = 5_000L,
    val style: TextStyleConfig = TextStyleConfig()
) {
    fun isVisibleAt(timeMs: Long): Boolean =
        isVisible && opacity > 0.001f && timeMs in startTimeMs..endTimeMs

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("offsetX", offsetX.toDouble())
        put("offsetY", offsetY.toDouble())
        put("scaleX", scaleX.toDouble())
        put("scaleY", scaleY.toDouble())
        put("rotation", rotation.toDouble())
        put("flipHorizontal", flipHorizontal)
        put("flipVertical", flipVertical)
        put("opacity", opacity.toDouble())
        put("isVisible", isVisible)
        put("isLocked", isLocked)
        put("startTimeMs", startTimeMs)
        put("endTimeMs", endTimeMs)
        put("style", style.toJson())
    }

    companion object {
        fun fromJson(obj: JSONObject): StudioTextOverlay {
            val styleObj = obj.optJSONObject("style")
            return StudioTextOverlay(
                id = obj.optString("id", UUID.randomUUID().toString()),
                name = obj.optString("name", "Текст"),
                offsetX = obj.optDouble("offsetX", 0.0).toFloat(),
                offsetY = obj.optDouble("offsetY", 0.0).toFloat(),
                scaleX = obj.optDouble("scaleX", 1.0).toFloat(),
                scaleY = obj.optDouble("scaleY", 1.0).toFloat(),
                rotation = obj.optDouble("rotation", 0.0).toFloat(),
                flipHorizontal = obj.optBoolean("flipHorizontal", false),
                flipVertical = obj.optBoolean("flipVertical", false),
                opacity = obj.optDouble("opacity", 1.0).toFloat(),
                isVisible = obj.optBoolean("isVisible", true),
                isLocked = obj.optBoolean("isLocked", false),
                startTimeMs = obj.optLong("startTimeMs", 0L),
                endTimeMs = obj.optLong("endTimeMs", 5_000L),
                style = if (styleObj != null) TextStyleConfig.fromJson(styleObj) else TextStyleConfig()
            )
        }
    }
}

// ============================================================================
// 4. ДВИЖОК РЕНДЕРИНГА, КЕШИРОВАНИЯ, ХИТ-ТЕСТА И КОМПЕНСАЦИИ ПОЗИЦИИ ТЕКСТА
// ============================================================================

object StudioTextEngine {

    private data class RenderCacheKey(
        val config: TextStyleConfig,
        val maxCanvasWidth: Int
    )

    private data class CurvedArcLayout(
        val lines: List<String>,
        val radii: FloatArray,
        val bmpW: Int,
        val bmpH: Int,
        val circleCx: Float,
        val circleCy: Float,
        val sweepDeg: Float,
        val vOffset: Float
    )

    private val customTypefaceCache = ConcurrentHashMap<String, Typeface>()
    private val bitmapCache = ConcurrentHashMap<String, Pair<RenderCacheKey, Bitmap>>()

    fun clearCache() {
        bitmapCache.clear()
    }

    /**
     * Копирует выбранный пользователем файл шрифта (.TTF / .OTF) в папку приложения и возвращает (путь, имя).
     */
    fun importCustomFontFromUri(context: Context, uri: Uri): Pair<String, String>? {
        return try {
            var displayName = "CustomFont"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) displayName = cursor.getString(idx) ?: displayName
                }
            }
            val cleanName = displayName.substringBeforeLast('.').ifBlank { "CustomFont" }
            val ext = displayName.substringAfterLast('.', "ttf").lowercase(Locale.US)
            val fontsDir = File(context.filesDir, "fonts").apply { if (!exists()) mkdirs() }
            val outFile = File(fontsDir, "${cleanName}_${System.currentTimeMillis()}.$ext")
            context.contentResolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { out -> input.copyTo(out) }
            } ?: return null
            outFile.absolutePath to cleanName
        } catch (_: Exception) {
            null
        }
    }

    fun buildTypefaceForFont(
        font: LayerFontFamily,
        isBold: Boolean,
        isItalic: Boolean,
        customFontPath: String? = null
    ): Typeface {
        if (!customFontPath.isNullOrBlank()) {
            val cachedTf = customTypefaceCache[customFontPath]
            val baseTf = cachedTf ?: try {
                val f = File(customFontPath)
                if (f.exists()) {
                    Typeface.createFromFile(f).also { customTypefaceCache[customFontPath] = it }
                } else null
            } catch (_: Exception) {
                null
            }
            if (baseTf != null) {
                val style = when {
                    isBold && isItalic -> Typeface.BOLD_ITALIC
                    isBold -> Typeface.BOLD
                    isItalic -> Typeface.ITALIC
                    else -> Typeface.NORMAL
                }
                return Typeface.create(baseTf, style)
            }
        }

        val effectiveItalic = isItalic || font.defaultItalic
        val effectiveWeight = if (isBold) (font.weight + 300).coerceAtMost(900) else font.weight
        val styleInt = when {
            effectiveWeight >= 600 && effectiveItalic -> Typeface.BOLD_ITALIC
            effectiveWeight >= 600 -> Typeface.BOLD
            effectiveItalic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val base = Typeface.create(font.familyName, styleInt)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Typeface.create(base, effectiveWeight, effectiveItalic)
        } else {
            base
        }
    }

    private fun configureTextPaint(cfg: TextStyleConfig): TextPaint {
        val ff = cfg.fontFamily
        val tf = buildTypefaceForFont(ff, cfg.isBold, cfg.isItalic, cfg.customFontPath)
        return TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            textSize = cfg.fontSize.coerceIn(8f, 1000f)
            typeface = tf
            color = cfg.color
            textScaleX = ff.scaleX
            letterSpacing = ff.baseLetterSpacing + cfg.letterSpacing
            ff.fontFeatureSettings?.let { fontFeatureSettings = it }
        }
    }

    fun computeTextBitmapPadding(cfg: TextStyleConfig): Int {
        return (cfg.strokeWidth + cfg.shadowRadius + abs(cfg.shadowDx) + abs(cfg.shadowDy) + 16f).roundToInt()
    }

    fun computeTextLineHeightPx(cfg: TextStyleConfig): Float {
        val tp = configureTextPaint(cfg)
        val fm = tp.fontMetrics
        val naturalLineH = (fm.descent - fm.ascent).coerceAtLeast(cfg.fontSize)
        return naturalLineH * cfg.lineSpacingMultiplier.coerceIn(0.5f, 4.0f)
    }

    private fun computeCurvedArcLayout(cfg: TextStyleConfig): CurvedArcLayout {
        val rawLines = cfg.text.ifEmpty { " " }.split('\n')
        val lines = rawLines.ifEmpty { listOf(" ") }
        val textPaint = configureTextPaint(cfg)
        val fm = textPaint.fontMetrics
        val ascentAbs = abs(fm.ascent).coerceAtLeast(cfg.fontSize * 0.75f)
        val descentAbs = abs(fm.descent).coerceAtLeast(cfg.fontSize * 0.22f)
        val fontHeight = (ascentAbs + descentAbs).coerceAtLeast(cfg.fontSize)
        val lineStep = (fontHeight * cfg.lineSpacingMultiplier.coerceIn(0.6f, 3.0f)).coerceAtLeast(fontHeight * 0.85f)

        val maxLineW = max(
            lines.maxOfOrNull { textPaint.measureText(it.ifEmpty { " " }) } ?: cfg.fontSize,
            cfg.fontSize * 1.5f
        )

        val sweepDeg = cfg.arcAngle.coerceIn(-359f, 359f)
        val absSweep = abs(sweepDeg)
        val sweepRad = Math.toRadians(absSweep.toDouble()).toFloat().coerceAtLeast(0.03f)
        val baseRadius = (maxLineW / sweepRad).coerceIn(fontHeight * 0.85f, 6500f)

        val radii = FloatArray(lines.size) { i ->
            if (sweepDeg > 0f) {
                (baseRadius - i * lineStep).coerceAtLeast(fontHeight * 0.65f)
            } else {
                baseRadius + i * lineStep
            }
        }

        val pad = computeTextBitmapPadding(cfg).toFloat()
        var minX = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY

        val steps = 48
        val startDeg = if (sweepDeg > 0f) -90f - absSweep / 2f else 90f + absSweep / 2f
        val endDeg = if (sweepDeg > 0f) -90f + absSweep / 2f else 90f - absSweep / 2f

        for (i in lines.indices) {
            val r = radii[i]
            val rOuter = if (sweepDeg > 0f) r + ascentAbs * 1.12f else r + descentAbs * 1.25f
            val rInner = (if (sweepDeg > 0f) r - descentAbs * 1.25f else r - ascentAbs * 1.12f).coerceAtLeast(2f)

            for (s in 0..steps) {
                val t = s.toFloat() / steps.toFloat()
                val deg = startDeg + (endDeg - startDeg) * t
                val rad = Math.toRadians(deg.toDouble())
                val ca = cos(rad).toFloat()
                val sa = sin(rad).toFloat()

                val ox = rOuter * ca
                val oy = rOuter * sa
                val ix = rInner * ca
                val iy = rInner * sa

                if (ox < minX) minX = ox
                if (ox > maxX) maxX = ox
                if (oy < minY) minY = oy
                if (oy > maxY) maxY = oy

                if (ix < minX) minX = ix
                if (ix > maxX) maxX = ix
                if (iy < minY) minY = iy
                if (iy > maxY) maxY = iy
            }
        }

        if (!minX.isFinite() || !minY.isFinite()) {
            minX = -60f; maxX = 60f; minY = -40f; maxY = 40f
        }

        val rawW = (maxX - minX) + pad * 2f
        val rawH = (maxY - minY) + pad * 2f
        val bmpW = rawW.roundToInt().coerceIn(64, 2600)
        val bmpH = rawH.roundToInt().coerceIn(64, 2600)
        val extraX = (bmpW - (maxX - minX)) * 0.5f
        val extraY = (bmpH - (maxY - minY)) * 0.5f

        return CurvedArcLayout(
            lines = lines,
            radii = radii,
            bmpW = bmpW,
            bmpH = bmpH,
            circleCx = extraX - minX,
            circleCy = extraY - minY,
            sweepDeg = sweepDeg,
            vOffset = 0f
        )
    }

    fun measureTextBitmapSize(cfg: TextStyleConfig, maxCanvasWidth: Int): Pair<Int, Int> {
        if (abs(cfg.arcAngle) >= 1.5f) {
            val layout = computeCurvedArcLayout(cfg)
            return layout.bmpW to layout.bmpH
        }
        val text = cfg.text.ifEmpty { " " }
        val textPaint = configureTextPaint(cfg)
        val hasFixedBox = cfg.boxWidth >= 48f
        val layoutWidth = if (hasFixedBox) {
            cfg.boxWidth.roundToInt().coerceIn(48, 3600)
        } else {
            (maxCanvasWidth * 0.9f).roundToInt().coerceAtLeast(120)
        }
        val layoutAlign = when (cfg.alignment) {
            TextAlignment.LEFT -> Layout.Alignment.ALIGN_NORMAL
            TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignment.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
        }
        val staticLayout = StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, layoutWidth)
            .setAlignment(layoutAlign)
            .setLineSpacing(0f, cfg.lineSpacingMultiplier.coerceIn(0.5f, 4.0f))
            .setIncludePad(true)
            .build()

        var maxLineW = 0f
        for (i in 0 until staticLayout.lineCount) {
            maxLineW = maxOf(maxLineW, staticLayout.getLineWidth(i))
        }
        val pad = computeTextBitmapPadding(cfg)
        val bmpW = if (hasFixedBox) {
            (layoutWidth + pad * 2).coerceAtLeast(64)
        } else {
            (maxLineW.roundToInt() + pad * 2).coerceAtLeast(64)
        }
        val minBoxH = if (cfg.boxHeight >= 32f) cfg.boxHeight.roundToInt() else 0
        val bmpH = maxOf(staticLayout.height + pad * 2, minBoxH + pad * 2).coerceAtLeast(64)
        return bmpW to bmpH
    }

    fun renderTextBitmap(cfg: TextStyleConfig, maxCanvasWidth: Int): Bitmap {
        if (abs(cfg.arcAngle) >= 1.5f) {
            return renderCurvedArcTextBitmap(cfg)
        }

        val text = cfg.text.ifEmpty { " " }
        val textPaint = configureTextPaint(cfg)
        val hasFixedBox = cfg.boxWidth >= 48f
        val layoutWidth = if (hasFixedBox) {
            cfg.boxWidth.roundToInt().coerceIn(48, 3600)
        } else {
            (maxCanvasWidth * 0.9f).roundToInt().coerceAtLeast(120)
        }
        val layoutAlign = when (cfg.alignment) {
            TextAlignment.LEFT -> Layout.Alignment.ALIGN_NORMAL
            TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignment.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
        }

        val staticLayout = StaticLayout.Builder
            .obtain(text, 0, text.length, textPaint, layoutWidth)
            .setAlignment(layoutAlign)
            .setLineSpacing(0f, cfg.lineSpacingMultiplier.coerceIn(0.5f, 4.0f))
            .setIncludePad(true)
            .build()

        var maxLineW = 0f
        for (i in 0 until staticLayout.lineCount) {
            maxLineW = maxOf(maxLineW, staticLayout.getLineWidth(i))
        }

        val pad = computeTextBitmapPadding(cfg)
        val bmpW = if (hasFixedBox) {
            (layoutWidth + pad * 2).coerceAtLeast(64)
        } else {
            (maxLineW.roundToInt() + pad * 2).coerceAtLeast(64)
        }
        val minBoxH = if (cfg.boxHeight >= 32f) cfg.boxHeight.roundToInt() else 0
        val bmpH = maxOf(staticLayout.height + pad * 2, minBoxH + pad * 2).coerceAtLeast(64)

        val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bmp)
        canvas.save()
        val dx = if (hasFixedBox) {
            pad.toFloat()
        } else {
            when (cfg.alignment) {
                TextAlignment.CENTER -> (bmpW - layoutWidth) / 2f
                TextAlignment.RIGHT -> (bmpW - layoutWidth - pad).toFloat()
                TextAlignment.LEFT -> pad.toFloat()
            }
        }
        val contentAreaH = (bmpH - pad * 2).toFloat()
        val textH = staticLayout.height.toFloat()
        val dy = when (cfg.verticalAlignment) {
            TextVerticalAlignment.TOP -> pad.toFloat()
            TextVerticalAlignment.CENTER -> pad.toFloat() + ((contentAreaH - textH) * 0.5f).coerceAtLeast(0f)
            TextVerticalAlignment.BOTTOM -> pad.toFloat() + (contentAreaH - textH).coerceAtLeast(0f)
        }
        canvas.translate(dx, dy)

        if (cfg.shadowRadius > 0f) {
            textPaint.setShadowLayer(cfg.shadowRadius, cfg.shadowDx, cfg.shadowDy, cfg.shadowColor)
        }

        if (cfg.strokeWidth > 0f) {
            textPaint.shader = null
            textPaint.style = Paint.Style.STROKE
            textPaint.strokeWidth = cfg.strokeWidth * 2f
            textPaint.strokeJoin = Paint.Join.ROUND
            textPaint.color = cfg.strokeColor
            staticLayout.draw(canvas)
            textPaint.clearShadowLayer()
        }

        textPaint.style = Paint.Style.FILL
        textPaint.color = cfg.color
        if (cfg.useGradient) {
            textPaint.shader = LinearGradient(
                0f, 0f, 0f, staticLayout.height.toFloat().coerceAtLeast(32f),
                cfg.color, cfg.gradientEndColor, Shader.TileMode.CLAMP
            )
        } else {
            textPaint.shader = null
        }
        if (cfg.shadowRadius > 0f && cfg.strokeWidth <= 0f) {
            textPaint.setShadowLayer(cfg.shadowRadius, cfg.shadowDx, cfg.shadowDy, cfg.shadowColor)
        }
        staticLayout.draw(canvas)
        canvas.restore()
        return bmp
    }

    private fun renderCurvedArcTextBitmap(cfg: TextStyleConfig): Bitmap {
        val layout = computeCurvedArcLayout(cfg)
        val textPaint = configureTextPaint(cfg).apply {
            textAlign = when (cfg.alignment) {
                TextAlignment.LEFT -> Paint.Align.LEFT
                TextAlignment.CENTER -> Paint.Align.CENTER
                TextAlignment.RIGHT -> Paint.Align.RIGHT
            }
        }

        val bmp = Bitmap.createBitmap(layout.bmpW, layout.bmpH, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bmp)
        val absSweep = abs(layout.sweepDeg)
        val path = AndroidPath()

        for (i in layout.lines.indices) {
            val lineText = layout.lines[i]
            if (lineText.isEmpty()) continue
            val r = layout.radii[i]
            val oval = RectF(
                layout.circleCx - r,
                layout.circleCy - r,
                layout.circleCx + r,
                layout.circleCy + r
            )
            path.reset()
            if (layout.sweepDeg > 0f) {
                path.addArc(oval, -90f - absSweep / 2f, absSweep)
            } else {
                path.addArc(oval, 90f + absSweep / 2f, -absSweep)
            }

            if (cfg.shadowRadius > 0f) {
                textPaint.setShadowLayer(cfg.shadowRadius, cfg.shadowDx, cfg.shadowDy, cfg.shadowColor)
            }

            if (cfg.strokeWidth > 0f) {
                textPaint.shader = null
                textPaint.style = Paint.Style.STROKE
                textPaint.strokeWidth = cfg.strokeWidth * 2f
                textPaint.strokeJoin = Paint.Join.ROUND
                textPaint.color = cfg.strokeColor
                canvas.drawTextOnPath(lineText, path, 0f, layout.vOffset, textPaint)
                textPaint.clearShadowLayer()
            }

            textPaint.style = Paint.Style.FILL
            textPaint.color = cfg.color
            if (cfg.useGradient) {
                textPaint.shader = LinearGradient(
                    0f, 0f, layout.bmpW.toFloat(), layout.bmpH.toFloat(),
                    cfg.color, cfg.gradientEndColor, Shader.TileMode.CLAMP
                )
            } else {
                textPaint.shader = null
            }
            if (cfg.shadowRadius > 0f && cfg.strokeWidth <= 0f) {
                textPaint.setShadowLayer(cfg.shadowRadius, cfg.shadowDx, cfg.shadowDy, cfg.shadowColor)
            }
            canvas.drawTextOnPath(lineText, path, 0f, layout.vOffset, textPaint)
        }
        return bmp
    }

    fun getOrRenderCachedBitmap(overlayId: String, cfg: TextStyleConfig, maxCanvasWidth: Int): Bitmap {
        val key = RenderCacheKey(cfg, maxCanvasWidth)
        val cached = bitmapCache[overlayId]
        if (cached != null && cached.first == key && !cached.second.isRecycled) {
            return cached.second
        }
        val rendered = renderTextBitmap(cfg, maxCanvasWidth)
        bitmapCache[overlayId] = key to rendered
        return rendered
    }

    fun buildTransformMatrix(item: StudioTextOverlay, contentWidth: Int, contentHeight: Int): Matrix {
        val w = contentWidth.toFloat().coerceAtLeast(1f)
        val h = contentHeight.toFloat().coerceAtLeast(1f)
        val cx = w / 2f
        val cy = h / 2f
        val matrix = Matrix()
        matrix.postTranslate(-cx, -cy)
        val sx = item.scaleX * (if (item.flipHorizontal) -1f else 1f)
        val sy = item.scaleY * (if (item.flipVertical) -1f else 1f)
        matrix.postScale(sx, sy)
        matrix.postRotate(item.rotation)
        matrix.postTranslate(cx + item.offsetX, cy + item.offsetY)
        return matrix
    }

    /**
     * Обновляет стиль текста с автоматической компенсацией offsetX/offsetY,
     * чтобы при сгибании в дугу (arcAngle), смене обводки/тени или наборе текста слой НЕ сползал.
     */
    fun applyStyleUpdateKeepingPosition(
        item: StudioTextOverlay,
        newStyle: TextStyleConfig,
        canvasWidth: Int
    ): StudioTextOverlay {
        val oldStyle = item.style
        val (oldW, oldH) = measureTextBitmapSize(oldStyle, canvasWidth)
        val (newW, newH) = measureTextBitmapSize(newStyle, canvasWidth)
        val involvesArc = abs(oldStyle.arcAngle) >= 1.5f || abs(newStyle.arcAngle) >= 1.5f

        val nextOffsetX: Float
        val nextOffsetY: Float
        if (involvesArc) {
            nextOffsetX = item.offsetX + (oldW - newW) * 0.5f
            nextOffsetY = item.offsetY + (oldH - newH) * 0.5f
        } else {
            val oldPad = computeTextBitmapPadding(oldStyle).toFloat()
            val newPad = computeTextBitmapPadding(newStyle).toFloat()
            val oldM = buildTransformMatrix(item, oldW, oldH)
            val oldOrigin = floatArrayOf(oldPad, oldPad)
            oldM.mapPoints(oldOrigin)

            val newM = buildTransformMatrix(item, newW, newH)
            val newOrigin = floatArrayOf(newPad, newPad)
            newM.mapPoints(newOrigin)

            nextOffsetX = item.offsetX + (oldOrigin[0] - newOrigin[0])
            nextOffsetY = item.offsetY + (oldOrigin[1] - newOrigin[1])
        }

        return item.copy(
            name = newStyle.text.take(18).ifBlank { "Текст" },
            offsetX = nextOffsetX,
            offsetY = nextOffsetY,
            style = newStyle
        )
    }

    /**
     * Создаёт новый текстовый слой точно в координатах (leftDoc, topDoc) с учётом padding.
     */
    fun createTextOverlayAt(
        leftDoc: Float,
        topDoc: Float,
        boxWidth: Float,
        boxHeight: Float,
        startTimeMs: Long = 0L,
        endTimeMs: Long = 5_000L,
        color: Int = AndroidColor.WHITE,
        fontSize: Float = (boxHeight * 0.38f).coerceIn(28f, 96f)
    ): StudioTextOverlay {
        val cfg = TextStyleConfig(
            text = "",
            fontSize = fontSize,
            color = color,
            alignment = TextAlignment.CENTER,
            verticalAlignment = TextVerticalAlignment.CENTER,
            boxWidth = boxWidth.coerceAtLeast(120f),
            boxHeight = boxHeight.coerceAtLeast(60f)
        )
        val pad = computeTextBitmapPadding(cfg).toFloat()
        return StudioTextOverlay(
            name = "Текст",
            offsetX = leftDoc - pad,
            offsetY = topDoc - pad,
            startTimeMs = startTimeMs,
            endTimeMs = endTimeMs,
            style = cfg
        )
    }

    /**
     * Хит-тест для касания по существующему текстовому слою поверх видео.
     */
    fun hitTestTextOverlays(
        items: List<StudioTextOverlay>,
        docX: Float,
        docY: Float,
        canvasWidth: Int,
        currentTimeMs: Long? = null,
        activeId: String? = null,
        marginDoc: Float = 28f
    ): StudioTextOverlay? {
        fun hits(item: StudioTextOverlay): Boolean {
            if (!item.isVisible || item.isLocked) return false
            if (currentTimeMs != null && !item.isVisibleAt(currentTimeMs)) return false
            val (w, h) = measureTextBitmapSize(item.style, canvasWidth)
            val m = buildTransformMatrix(item, w, h)
            val inv = Matrix()
            if (!m.invert(inv)) return false
            val pts = floatArrayOf(docX, docY)
            inv.mapPoints(pts)
            val mX = marginDoc / abs(item.scaleX).coerceAtLeast(0.15f)
            val mY = marginDoc / abs(item.scaleY).coerceAtLeast(0.15f)
            return pts[0] in -mX..(w.toFloat() + mX) && pts[1] in -mY..(h.toFloat() + mY)
        }

        val active = activeId?.let { id -> items.find { it.id == id } }
        if (active != null && hits(active)) return active
        return items.asReversed().firstOrNull { it.id != active?.id && hits(it) }
    }

    /**
     * Рисует все видимые текстовые слои на Android Canvas (подходит и для превью, и для экспорта видео!).
     */
    fun drawOverlaysOnCanvas(
        canvas: AndroidCanvas,
        items: List<StudioTextOverlay>,
        canvasWidth: Int,
        currentTimeMs: Long? = null
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        for (item in items) {
            if (!item.isVisible || item.opacity <= 0.001f) continue
            if (currentTimeMs != null && !item.isVisibleAt(currentTimeMs)) continue
            val bmp = getOrRenderCachedBitmap(item.id, item.style, canvasWidth)
            val matrix = buildTransformMatrix(item, bmp.width, bmp.height)
            paint.alpha = (item.opacity.coerceIn(0f, 1f) * 255f).roundToInt().coerceIn(1, 255)
            canvas.drawBitmap(bmp, matrix, paint)
        }
    }
}

// ============================================================================
// 5. ФИРМЕННЫЕ UI-КОМПОНЕНТЫ ДИЗАЙНА LAYER STUDIO
// ============================================================================

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StudioToolSlotButton(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    hasSubMenu: Boolean = false,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val bg = if (selected) StudioColors.AccentBlue else Color.Transparent
    val tint = if (selected) Color.White else StudioColors.TextSecondary

    Box(
        modifier = Modifier
            .size(width = StudioDimens.ToolSlotWidth, height = StudioDimens.ToolSlotHeight)
            .clip(StudioShapes.ToolSlot)
            .background(bg)
            .pointerInput(label, onLongClick) {
                if (onLongClick != null) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            if (ev.type == PointerEventType.Press && ev.buttons.isSecondaryPressed) {
                                ev.changes.forEach { it.consume() }
                                onLongClick.invoke()
                            }
                        }
                    }
                }
            }
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick ?: onClick
            )
            .padding(vertical = 4.dp, horizontal = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(StudioDimens.ToolIconSize)
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = label,
                color = tint,
                fontSize = 9.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (hasSubMenu) {
            Text(
                text = "◢",
                color = if (selected) Color.White else StudioColors.AccentLightBlue,
                fontSize = 7.sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 3.dp, bottom = 1.dp)
            )
        }
    }
}

@Composable
fun StudioActionChip(
    label: String,
    icon: ImageVector,
    enabled: Boolean = true,
    accent: Boolean = false,
    onClick: () -> Unit
) {
    val bg = when {
        !enabled -> StudioColors.BgPanel.copy(alpha = 0.4f)
        accent -> StudioColors.AccentBlue
        else -> StudioColors.BgPanel
    }
    Row(
        modifier = Modifier
            .clip(StudioShapes.Chip)
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) Color.White else StudioColors.TextSecondary.copy(alpha = 0.4f),
            modifier = Modifier.size(StudioDimens.SmallChipIconSize)
        )
        Spacer(Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (enabled) Color.White else StudioColors.TextSecondary.copy(alpha = 0.4f)
        )
    }
}

@Composable
fun StudioManualNumberDialog(
    title: String,
    initialValue: Float,
    unitSuffix: String = "",
    minAllowed: Float = -100000f,
    maxAllowed: Float = 100000f,
    allowDecimals: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: (Float) -> Unit
) {
    val formattedInit = remember(initialValue, allowDecimals) {
        if (!allowDecimals || initialValue == initialValue.roundToInt().toFloat()) {
            initialValue.roundToInt().toString()
        } else {
            String.format(Locale.US, "%.2f", initialValue)
        }
    }
    var text by remember { mutableStateOf(formattedInit) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioColors.BgPanel,
        title = {
            Text(
                text = if (unitSuffix.isNotEmpty()) "$title ($unitSuffix)" else title,
                color = StudioColors.TextPrimary,
                fontSize = 16.sp
            )
        },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { input ->
                    text = input.filter { it.isDigit() || it == '.' || it == ',' || it == '-' }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (allowDecimals) KeyboardType.Decimal else KeyboardType.Number
                ),
                label = { Text("Введите значение") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = StudioColors.TextPrimary,
                    unfocusedTextColor = StudioColors.TextPrimary,
                    focusedBorderColor = StudioColors.AccentLightBlue
                ),
                modifier = Modifier.fillMaxWidth().trackTextInputFocus()
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val parsed = text.replace(',', '.').toFloatOrNull()
                if (parsed != null) onConfirm(parsed.coerceIn(minAllowed, maxAllowed)) else onDismiss()
            }) {
                Text("Применить", color = StudioColors.AccentLightBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudioColors.TextSecondary)
            }
        }
    )
}

@Composable
fun StudioEditableSliderRow(
    label: String,
    value: Float,
    sliderRange: ClosedFloatingPointRange<Float>,
    unitSuffix: String = "",
    minManual: Float = sliderRange.start,
    maxManual: Float = sliderRange.endInclusive,
    allowDecimals: Boolean = sliderRange.endInclusive <= 10f,
    onValueChange: (Float) -> Unit,
    onValueCommit: ((Float) -> Unit)? = null
) {
    var showManualDialog by remember { mutableStateOf(false) }
    val displayValue = if (allowDecimals && value != value.roundToInt().toFloat()) {
        String.format(Locale.US, "%.2f%s", value, unitSuffix)
    } else {
        "${value.roundToInt()}$unitSuffix"
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = StudioColors.TextSecondary, fontSize = 11.sp)
            Box(
                modifier = Modifier
                    .clip(StudioShapes.Small)
                    .background(StudioColors.BgDarkGray)
                    .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Small)
                    .clickable { showManualDialog = true }
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$displayValue ✎",
                    color = StudioColors.AccentLightBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
        Slider(
            value = value.coerceIn(sliderRange.start, sliderRange.endInclusive),
            onValueChange = onValueChange,
            onValueChangeFinished = { onValueCommit?.invoke(value) },
            valueRange = sliderRange,
            modifier = Modifier.height(26.dp)
        )
    }

    if (showManualDialog) {
        StudioManualNumberDialog(
            title = label,
            initialValue = value,
            unitSuffix = unitSuffix,
            minAllowed = minManual,
            maxAllowed = maxManual,
            allowDecimals = allowDecimals,
            onDismiss = { showManualDialog = false },
            onConfirm = { entered ->
                showManualDialog = false
                onValueChange(entered)
                onValueCommit?.invoke(entered)
            }
        )
    }
}

@Composable
fun StudioInlineEditableSlider(
    label: String,
    value: Float,
    sliderRange: ClosedFloatingPointRange<Float>,
    minManual: Float = sliderRange.start,
    maxManual: Float = sliderRange.endInclusive,
    unitSuffix: String = "",
    onValueChange: (Float) -> Unit,
    onValueCommit: ((Float) -> Unit)? = null
) {
    var showDialog by remember { mutableStateOf(false) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, color = StudioColors.TextSecondary, fontSize = 11.sp)
        Box(
            modifier = Modifier
                .clip(StudioShapes.Small)
                .background(StudioColors.BgPanel)
                .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Small)
                .clickable { showDialog = true }
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${value.roundToInt()}$unitSuffix ✎",
                color = StudioColors.AccentLightBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Slider(
            value = value.coerceIn(sliderRange.start, sliderRange.endInclusive),
            onValueChange = onValueChange,
            onValueChangeFinished = { onValueCommit?.invoke(value) },
            valueRange = sliderRange,
            modifier = Modifier.width(96.dp)
        )
    }

    if (showDialog) {
        StudioManualNumberDialog(
            title = label,
            initialValue = value,
            unitSuffix = unitSuffix,
            minAllowed = minManual,
            maxAllowed = maxManual,
            allowDecimals = true,
            onDismiss = { showDialog = false },
            onConfirm = { entered ->
                showDialog = false
                onValueChange(entered)
                onValueCommit?.invoke(entered)
            }
        )
    }
}

// ============================================================================
// 6. КОМПОНЕНТЫ СИСТЕМЫ ТЕКСТА (Превью WYSIWYG, Верхняя панель, Стиль, Шрифты, Палитра)
// ============================================================================

/**
 * Полноценный WYSIWYG-редактор текста поверх превью видео.
 *
 * Поместите этот Composable в отдельный Box поверх вашего плеера/Canvas
 * (вне pointerInput самого холста, чтобы клики по кнопкам не пробивались вниз).
 *
 * @param item активный текстовый слой
 * @param canvasWidth ширина видеокадра в пикселях (например, 1080 или 1920)
 * @param originX экранная координата X левого края видеокадра внутри этого Box
 * @param originY экранная координата Y верхнего края видеокадра внутри этого Box
 * @param totalScale масштаб отображения (экранных px на 1 px видеокадра)
 * @param viewportWidthPx ширина области превью в px
 * @param viewportHeightPx высота области превью в px
 */
@Composable
fun StudioOnCanvasTextEditor(
    item: StudioTextOverlay,
    canvasWidth: Int,
    originX: Float,
    originY: Float,
    totalScale: Float,
    viewportWidthPx: Float,
    viewportHeightPx: Float,
    onUpdateStyle: (TextStyleConfig, Boolean) -> Unit,
    onTranslate: (Float, Float, Boolean) -> Unit,
    onOpenFontPicker: () -> Unit,
    onOpenColorPicker: () -> Unit,
    onDone: () -> Unit,
    showFloatingToolbar: Boolean = true
) {
    val tc = item.style
    val density = LocalDensity.current
    val currentScale by rememberUpdatedState(totalScale)
    val currentItem by rememberUpdatedState(item)

    val padDoc = StudioTextEngine.computeTextBitmapPadding(tc).toFloat()
    val (iw, ih) = remember(item.id, tc, canvasWidth) {
        StudioTextEngine.measureTextBitmapSize(tc, canvasWidth)
    }
    val layerMatrix = StudioTextEngine.buildTransformMatrix(item, iw, ih)

    val contentWDoc = (iw.toFloat() - padDoc * 2f).coerceAtLeast(48f)
    val contentHDoc = (ih.toFloat() - padDoc * 2f).coerceAtLeast(32f)
    val centerPts = floatArrayOf(iw / 2f, ih / 2f)
    layerMatrix.mapPoints(centerPts)

    val absScaleX = abs(item.scaleX).coerceAtLeast(0.05f)
    val absScaleY = abs(item.scaleY).coerceAtLeast(0.05f)
    val screenBoxW = (contentWDoc * absScaleX * totalScale).coerceAtLeast(16f)
    val screenBoxH = (contentHDoc * absScaleY * totalScale).coerceAtLeast(16f)
    val screenBoxLeft = originX + centerPts[0] * totalScale - screenBoxW / 2f
    val screenBoxTop = originY + centerPts[1] * totalScale - screenBoxH / 2f

    val boxWidthDp = with(density) { screenBoxW.toDp() }
    val boxHeightDp = with(density) { screenBoxH.toDp() }
    val exactFontSp = with(density) { (tc.fontSize * absScaleY * totalScale).coerceAtLeast(1f).toSp() }
    val exactLineHeightPx = remember(tc.fontFamily, tc.fontSize, tc.isBold, tc.isItalic, tc.customFontPath, tc.lineSpacingMultiplier) {
        StudioTextEngine.computeTextLineHeightPx(tc)
    }
    val exactLineHeightSp = with(density) { (exactLineHeightPx * absScaleY * totalScale).coerceAtLeast(1f).toSp() }
    val exactLetterSpacingEm = (tc.fontFamily.baseLetterSpacing + tc.letterSpacing).em

    val composeFontFamily = remember(tc.fontFamily, tc.isBold, tc.isItalic, tc.customFontPath) {
        val nativeTf = StudioTextEngine.buildTypefaceForFont(tc.fontFamily, tc.isBold, tc.isItalic, tc.customFontPath)
        FontFamily(ComposeTypeface(nativeTf))
    }

    val isCurvedArc = abs(tc.arcAngle) >= 1.5f
    val placeholderColor = remember(tc.color) {
        val c = if (AndroidColor.alpha(tc.color) < 10) AndroidColor.WHITE else tc.color
        Color(c).copy(alpha = 0.55f)
    }
    val composeAlign = when (tc.alignment) {
        TextAlignment.LEFT -> TextAlign.Left
        TextAlignment.CENTER -> TextAlign.Center
        TextAlignment.RIGHT -> TextAlign.Right
    }
    val composeVertAlign = when (tc.verticalAlignment) {
        TextVerticalAlignment.TOP -> Alignment.TopStart
        TextVerticalAlignment.CENTER -> Alignment.CenterStart
        TextVerticalAlignment.BOTTOM -> Alignment.BottomStart
    }

    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(item.id, isCurvedArc) {
        try {
            focusRequester.requestFocus()
        } catch (_: Exception) {
        }
    }

    // 1. Рамка текста прямо на кадре
    if (isCurvedArc) {
        Box(
            modifier = Modifier
                .offset { IntOffset(screenBoxLeft.roundToInt(), screenBoxTop.roundToInt()) }
                .size(width = boxWidthDp, height = boxHeightDp)
                .graphicsLayer { rotationZ = item.rotation }
                .border(1.5.dp, StudioColors.AccentLightBlue.copy(alpha = 0.9f), StudioShapes.Small)
                .pointerInput(item.id) {
                    detectDragGestures(
                        onDragEnd = { onTranslate(0f, 0f, true) }
                    ) { change, dragAmount ->
                        change.consume()
                        val sc = currentScale.coerceAtLeast(0.1f)
                        onTranslate(dragAmount.x / sc, dragAmount.y / sc, false)
                    }
                }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    try {
                        focusRequester.requestFocus()
                    } catch (_: Exception) {
                    }
                }
        )
    } else {
        Box(
            modifier = Modifier
                .offset { IntOffset(screenBoxLeft.roundToInt(), screenBoxTop.roundToInt()) }
                .size(width = boxWidthDp, height = boxHeightDp)
                .graphicsLayer { rotationZ = item.rotation }
                .border(1.5.dp, StudioColors.AccentLightBlue.copy(alpha = 0.9f), StudioShapes.TextFrame)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    try {
                        focusRequester.requestFocus()
                    } catch (_: Exception) {
                    }
                }
        ) {
            BasicTextField(
                value = tc.text,
                onValueChange = { onUpdateStyle(tc.copy(text = it), false) },
                textStyle = TextStyle(
                    color = Color.Transparent,
                    fontFamily = composeFontFamily,
                    fontSize = exactFontSp,
                    lineHeight = exactLineHeightSp,
                    letterSpacing = exactLetterSpacingEm,
                    fontWeight = if (tc.isBold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (tc.isItalic) FontStyle.Italic else FontStyle.Normal,
                    textAlign = composeAlign,
                    platformStyle = PlatformTextStyle(includeFontPadding = true)
                ),
                cursorBrush = SolidColor(StudioColors.AccentLightBlue),
                modifier = Modifier
                    .fillMaxSize()
                    .focusRequester(focusRequester)
                    .trackTextInputFocus(),
                decorationBox = { innerTextField ->
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = composeVertAlign
                    ) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            if (tc.text.isEmpty()) {
                                Text(
                                    text = "Введите текст...",
                                    color = placeholderColor,
                                    fontFamily = composeFontFamily,
                                    fontSize = exactFontSp,
                                    lineHeight = exactLineHeightSp,
                                    letterSpacing = exactLetterSpacingEm,
                                    textAlign = composeAlign,
                                    style = TextStyle(platformStyle = PlatformTextStyle(includeFontPadding = true)),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            innerTextField()
                        }
                    }
                }
            )

            // Уголок изменения размера рамки текста
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(StudioDimens.ResizeHandleSize)
                    .clip(StudioShapes.Micro)
                    .background(StudioColors.AccentBlue)
                    .border(1.dp, Color.White, StudioShapes.Micro)
                    .pointerInput(item.id) {
                        var curW = 240f
                        var curH = 100f
                        detectDragGestures(
                            onDragStart = {
                                val latest = currentItem.style
                                curW = latest.boxWidth.coerceAtLeast(120f)
                                curH = latest.boxHeight.coerceAtLeast(60f)
                            },
                            onDragEnd = {
                                onUpdateStyle(currentItem.style.copy(boxWidth = curW, boxHeight = curH), true)
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            val sxNow = abs(currentItem.scaleX).coerceAtLeast(0.05f)
                            val syNow = abs(currentItem.scaleY).coerceAtLeast(0.05f)
                            val scX = (currentScale * sxNow).coerceAtLeast(0.1f)
                            val scY = (currentScale * syNow).coerceAtLeast(0.1f)
                            curW = (curW + dragAmount.x / scX).coerceIn(100f, 3200f)
                            curH = (curH + dragAmount.y / scY).coerceIn(50f, 3200f)
                            onUpdateStyle(currentItem.style.copy(boxWidth = curW, boxHeight = curH), false)
                        }
                    }
            )
        }
    }

    // 2. Прямая строка редактирования дугового текста
    if (isCurvedArc) {
        val editBarW = (viewportWidthPx - 16f).coerceIn(220f, 440f)
        val editBarH = with(density) { 46.dp.toPx() }
        val editBarLeft = ((screenBoxLeft + screenBoxW / 2f) - editBarW / 2f)
            .coerceIn(8f, (viewportWidthPx - editBarW - 8f).coerceAtLeast(8f))
        val preferBelow = screenBoxTop + screenBoxH + 8f
        val editBarTop = if (preferBelow + editBarH <= viewportHeightPx - 8f) {
            preferBelow
        } else {
            (viewportHeightPx - editBarH - 8f).coerceAtLeast(48f)
        }

        Row(
            modifier = Modifier
                .offset { IntOffset(editBarLeft.roundToInt(), editBarTop.roundToInt()) }
                .width(with(density) { editBarW.toDp() })
                .clip(StudioShapes.Panel)
                .background(StudioColors.BgGraphite.copy(alpha = 0.96f))
                .border(1.5.dp, StudioColors.AccentLightBlue, StudioShapes.Panel)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {}
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "⌒ ${tc.arcAngle.roundToInt()}°",
                color = StudioColors.AccentLightBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(StudioShapes.Button)
                    .background(StudioColors.BgDarkGray)
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                BasicTextField(
                    value = tc.text,
                    onValueChange = { onUpdateStyle(tc.copy(text = it), false) },
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(StudioColors.AccentLightBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                        .trackTextInputFocus(),
                    decorationBox = { inner ->
                        if (tc.text.isEmpty()) {
                            Text("Введите текст по дуге...", color = StudioColors.TextSecondary, fontSize = 13.sp)
                        }
                        inner()
                    }
                )
            }
            Box(
                modifier = Modifier
                    .clip(StudioShapes.Button)
                    .background(StudioColors.BgPanel)
                    .clickable { onUpdateStyle(tc.copy(arcAngle = 0f), true) }
                    .padding(horizontal = 7.dp, vertical = 4.dp)
            ) {
                Text("0°", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }

    // 3. Плавающая мини-панель (Двигать + Гориз./Верт. выравнивание + Шрифт + Цвет + Готово)
    if (showFloatingToolbar) {
    val toolbarH = with(density) { 40.dp.toPx() }
    val maxToolbarW = (viewportWidthPx - 12f).coerceAtLeast(180f)
    val toolbarLeftPx = screenBoxLeft.coerceIn(
        6f,
        (viewportWidthPx - minOf(maxToolbarW, with(density) { 360.dp.toPx() }) - 6f).coerceAtLeast(6f)
    )
    val preferredTop = screenBoxTop - toolbarH - 8f
    val toolbarTopPx = if (preferredTop >= 6f) preferredTop else 6f

    Row(
        modifier = Modifier
            .offset { IntOffset(toolbarLeftPx.roundToInt(), toolbarTopPx.roundToInt()) }
            .widthIn(max = with(density) { maxToolbarW.toDp() })
            .clip(StudioShapes.Panel)
            .background(StudioColors.BgGraphite.copy(alpha = 0.97f))
            .border(1.dp, StudioColors.AccentLightBlue, StudioShapes.Panel)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {}
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Кнопка-захват «Двигать»
        Row(
            modifier = Modifier
                .height(26.dp)
                .clip(StudioShapes.Button)
                .background(StudioColors.AccentBlue.copy(alpha = 0.35f))
                .border(1.dp, StudioColors.AccentLightBlue, StudioShapes.Button)
                .pointerInput(item.id) {
                    detectDragGestures(
                        onDragEnd = { onTranslate(0f, 0f, true) }
                    ) { change, dragAmount ->
                        change.consume()
                        val sc = currentScale.coerceAtLeast(0.1f)
                        onTranslate(dragAmount.x / sc, dragAmount.y / sc, false)
                    }
                }
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(StudioIcons.Move, "Переместить", tint = Color.White, modifier = Modifier.size(14.dp))
            Text("Двигать", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }

        // Горизонтальное выравнивание
        listOf(
            TextAlignment.LEFT to StudioIcons.AlignLeft,
            TextAlignment.CENTER to StudioIcons.AlignCenter,
            TextAlignment.RIGHT to StudioIcons.AlignRight
        ).forEach { (mode, iconVec) ->
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(StudioShapes.Button)
                    .background(if (tc.alignment == mode) StudioColors.AccentBlue else StudioColors.BgPanel)
                    .clickable { onUpdateStyle(tc.copy(alignment = mode), true) },
                contentAlignment = Alignment.Center
            ) {
                Icon(iconVec, mode.displayName, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }

        // Вертикальное выравнивание
        listOf(
            TextVerticalAlignment.TOP to StudioIcons.VerticalTop,
            TextVerticalAlignment.CENTER to StudioIcons.VerticalCenter,
            TextVerticalAlignment.BOTTOM to StudioIcons.VerticalBottom
        ).forEach { (vMode, iconVec) ->
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(StudioShapes.Button)
                    .background(if (tc.verticalAlignment == vMode) StudioColors.AccentBlue else StudioColors.BgPanel)
                    .clickable { onUpdateStyle(tc.copy(verticalAlignment = vMode), true) },
                contentAlignment = Alignment.Center
            ) {
                Icon(iconVec, vMode.displayName, tint = Color.White, modifier = Modifier.size(15.dp))
            }
        }

        // Шрифт
        Box(
            modifier = Modifier
                .clip(StudioShapes.Button)
                .background(StudioColors.BgPanel)
                .clickable(onClick = onOpenFontPicker)
                .padding(horizontal = 7.dp, vertical = 4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(StudioIcons.Font, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(3.dp))
                Text("Шрифт", color = Color.White, fontSize = 11.sp)
            }
        }

        // Цвет
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(StudioShapes.Circle)
                .background(Color(tc.color))
                .border(1.5.dp, Color.White, StudioShapes.Circle)
                .clickable(onClick = onOpenColorPicker)
        )

        // Готово
        Box(
            modifier = Modifier
                .clip(StudioShapes.Button)
                .background(StudioColors.SuccessGreen)
                .clickable(onClick = onDone)
                .padding(horizontal = 7.dp, vertical = 4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(StudioIcons.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(2.dp))
                Text("Готово", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    }
}

/**
 * Верхняя строка быстрых параметров инструмента «Текст» в фирменном стиле Layer Studio.
 */
@Composable
fun StudioTextOptionsBar(
    style: TextStyleConfig,
    onUpdateStyle: (TextStyleConfig, Boolean) -> Unit,
    onOpenFontPicker: () -> Unit,
    onToggleStyleInspector: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenColorPicker: (() -> Unit)? = null,
    onDone: (() -> Unit)? = null
) {
    val fontTitle = style.customFontName ?: style.fontFamily.displayName
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(StudioDimens.ToolOptionsRowHeight)
            .background(StudioColors.BgDarkGray)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StudioActionChip("Влево", StudioIcons.AlignLeft, accent = style.alignment == TextAlignment.LEFT) {
            onUpdateStyle(style.copy(alignment = TextAlignment.LEFT), true)
        }
        StudioActionChip("Центр", StudioIcons.AlignCenter, accent = style.alignment == TextAlignment.CENTER) {
            onUpdateStyle(style.copy(alignment = TextAlignment.CENTER), true)
        }
        StudioActionChip("Вправо", StudioIcons.AlignRight, accent = style.alignment == TextAlignment.RIGHT) {
            onUpdateStyle(style.copy(alignment = TextAlignment.RIGHT), true)
        }
        StudioActionChip("Верх", StudioIcons.VerticalTop, accent = style.verticalAlignment == TextVerticalAlignment.TOP) {
            onUpdateStyle(style.copy(verticalAlignment = TextVerticalAlignment.TOP), true)
        }
        StudioActionChip("Верт. центр", StudioIcons.VerticalCenter, accent = style.verticalAlignment == TextVerticalAlignment.CENTER) {
            onUpdateStyle(style.copy(verticalAlignment = TextVerticalAlignment.CENTER), true)
        }
        StudioActionChip("Низ", StudioIcons.VerticalBottom, accent = style.verticalAlignment == TextVerticalAlignment.BOTTOM) {
            onUpdateStyle(style.copy(verticalAlignment = TextVerticalAlignment.BOTTOM), true)
        }

        Row(
            modifier = Modifier
                .clip(StudioShapes.Chip)
                .background(StudioColors.BgPanel)
                .border(1.dp, StudioColors.AccentLightBlue, StudioShapes.Chip)
                .clickable(onClick = onOpenFontPicker)
                .padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(StudioIcons.Font, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(fontTitle, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(3.dp))
            Icon(Icons.Default.ArrowDropDown, null, tint = Color.White, modifier = Modifier.size(15.dp))
        }

        StudioInlineEditableSlider(
            label = "Размер",
            value = style.fontSize,
            sliderRange = 12f..300f,
            minManual = 4f,
            maxManual = 2000f,
            unitSuffix = " pt",
            onValueChange = { onUpdateStyle(style.copy(fontSize = it), false) },
            onValueCommit = { onUpdateStyle(style.copy(fontSize = it), true) }
        )

        StudioInlineEditableSlider(
            label = "Дуга",
            value = style.arcAngle,
            sliderRange = -360f..360f,
            minManual = -360f,
            maxManual = 360f,
            unitSuffix = "°",
            onValueChange = { onUpdateStyle(style.copy(arcAngle = it), false) },
            onValueCommit = { onUpdateStyle(style.copy(arcAngle = it), true) }
        )

        if (style.arcAngle != 0f) {
            StudioActionChip("0°", Icons.Default.HorizontalRule) {
                onUpdateStyle(style.copy(arcAngle = 0f), true)
            }
        }

        if (onOpenColorPicker != null) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(StudioShapes.Circle)
                    .background(Color(style.color))
                    .border(1.5.dp, Color.White, StudioShapes.Circle)
                    .clickable(onClick = onOpenColorPicker)
            )
        }
        StudioActionChip("Стиль", StudioIcons.Text, onClick = onToggleStyleInspector)
        if (onDone != null) {
            StudioActionChip("Готово", StudioIcons.Check, accent = true, onClick = onDone)
        }
    }
}

/**
 * Нижняя панель «Стиль текста» с закреплённым сверху полем ввода (клавиатура не перекрывает!).
 */
@Composable
fun StudioTextStyleInspectorPanel(
    style: TextStyleConfig,
    onUpdateStyle: (TextStyleConfig, Boolean) -> Unit,
    onOpenFontPicker: () -> Unit,
    onClosePanel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var colorPickerTarget by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(max = StudioDimens.InspectorMaxHeight),
        color = StudioColors.BgGraphite,
        tonalElevation = 8.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Стиль текста, выравнивание и дуга",
                    color = StudioColors.TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
                IconButton(onClick = onClosePanel, modifier = Modifier.size(26.dp)) {
                    Icon(Icons.Default.KeyboardArrowDown, "Свернуть", tint = StudioColors.TextSecondary)
                }
            }

            OutlinedTextField(
                value = style.text,
                onValueChange = { onUpdateStyle(style.copy(text = it), false) },
                label = { Text("Текст слоя", fontSize = 11.sp) },
                maxLines = 2,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = StudioColors.TextPrimary,
                    unfocusedTextColor = StudioColors.TextPrimary,
                    focusedBorderColor = StudioColors.AccentLightBlue
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
                    .trackTextInputFocus()
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val fontTitle = style.customFontName ?: style.fontFamily.displayName
                    Row(
                        modifier = Modifier
                            .clip(StudioShapes.Chip)
                            .background(StudioColors.BgPanel)
                            .border(1.dp, StudioColors.AccentLightBlue, StudioShapes.Chip)
                            .clickable(onClick = onOpenFontPicker)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(StudioIcons.Font, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Шрифт: $fontTitle", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(StudioShapes.Circle)
                            .background(Color(style.color))
                            .border(1.5.dp, Color.White, StudioShapes.Circle)
                            .clickable { colorPickerTarget = "fill" }
                    )
                    FilterChip(
                        selected = style.useGradient,
                        onClick = { onUpdateStyle(style.copy(useGradient = !style.useGradient), true) },
                        label = { Text("Градиент", fontSize = 10.sp) }
                    )
                    if (style.useGradient) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(StudioShapes.Circle)
                                .background(Color(style.gradientEndColor))
                                .border(1.5.dp, StudioColors.AccentLightBlue, StudioShapes.Circle)
                                .clickable { colorPickerTarget = "gradEnd" }
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(StudioShapes.Circle)
                            .background(Color(style.strokeColor))
                            .border(1.5.dp, StudioColors.AccentLightBlue, StudioShapes.Circle)
                            .clickable { colorPickerTarget = "stroke" }
                    )
                    FilterChip(
                        selected = style.isBold,
                        onClick = { onUpdateStyle(style.copy(isBold = !style.isBold), true) },
                        label = { Text("Ж", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = style.isItalic,
                        onClick = { onUpdateStyle(style.copy(isItalic = !style.isItalic), true) },
                        label = { Text("К", fontSize = 11.sp) }
                    )
                    TextAlignment.entries.forEach { al ->
                        FilterChip(
                            selected = style.alignment == al,
                            onClick = { onUpdateStyle(style.copy(alignment = al), true) },
                            label = { Text(al.displayName, fontSize = 10.sp) }
                        )
                    }
                    TextVerticalAlignment.entries.forEach { valAl ->
                        FilterChip(
                            selected = style.verticalAlignment == valAl,
                            onClick = { onUpdateStyle(style.copy(verticalAlignment = valAl), true) },
                            label = { Text("↕ ${valAl.displayName}", fontSize = 10.sp) }
                        )
                    }
                }

                StudioEditableSliderRow(
                    label = "Изгиб текста дугой (°)",
                    value = style.arcAngle,
                    sliderRange = -360f..360f,
                    minManual = -360f,
                    maxManual = 360f,
                    unitSuffix = "°",
                    onValueChange = { onUpdateStyle(style.copy(arcAngle = it), false) },
                    onValueCommit = { onUpdateStyle(style.copy(arcAngle = it), true) }
                )
                StudioEditableSliderRow(
                    label = "Размер шрифта",
                    value = style.fontSize,
                    sliderRange = 12f..300f,
                    minManual = 4f,
                    maxManual = 2000f,
                    unitSuffix = " pt",
                    onValueChange = { onUpdateStyle(style.copy(fontSize = it), false) },
                    onValueCommit = { onUpdateStyle(style.copy(fontSize = it), true) }
                )
                StudioEditableSliderRow(
                    label = "Разрядка букв (%)",
                    value = style.letterSpacing * 100f,
                    sliderRange = -20f..100f,
                    minManual = -50f,
                    maxManual = 500f,
                    unitSuffix = "%",
                    onValueChange = { onUpdateStyle(style.copy(letterSpacing = it / 100f), false) },
                    onValueCommit = { onUpdateStyle(style.copy(letterSpacing = it / 100f), true) }
                )
                StudioEditableSliderRow(
                    label = "Обводка текста",
                    value = style.strokeWidth,
                    sliderRange = 0f..30f,
                    unitSuffix = " px",
                    onValueChange = { onUpdateStyle(style.copy(strokeWidth = it), false) },
                    onValueCommit = { onUpdateStyle(style.copy(strokeWidth = it), true) }
                )
                StudioEditableSliderRow(
                    label = "Тень текста",
                    value = style.shadowRadius,
                    sliderRange = 0f..30f,
                    unitSuffix = " px",
                    onValueChange = { onUpdateStyle(style.copy(shadowRadius = it), false) },
                    onValueCommit = { onUpdateStyle(style.copy(shadowRadius = it), true) }
                )
            }
        }
    }

    colorPickerTarget?.let { target ->
        val initC = when (target) {
            "stroke" -> style.strokeColor
            "gradEnd" -> style.gradientEndColor
            else -> style.color
        }
        StudioColorPickerDialog(
            initialColor = initC,
            onDismiss = { colorPickerTarget = null },
            onConfirm = { picked ->
                val next = when (target) {
                    "stroke" -> style.copy(strokeColor = picked)
                    "gradEnd" -> style.copy(gradientEndColor = picked, useGradient = true)
                    else -> style.copy(color = picked)
                }
                onUpdateStyle(next, true)
                colorPickerTarget = null
            }
        )
    }
}

/**
 * Диалог выбора из 18 встроенных шрифтов с живым предпросмотром + загрузка .TTF/.OTF.
 */
@Composable
fun StudioFontPickerDialog(
    selectedFont: LayerFontFamily,
    customFontName: String?,
    previewText: String,
    onSelectFont: (LayerFontFamily) -> Unit,
    onImportCustomFontFile: () -> Unit,
    onClearCustomFont: () -> Unit,
    onDismiss: () -> Unit
) {
    val sampleLine = previewText.replace('\n', ' ').trim().take(22).ifEmpty { "Layer Studio АаБб" }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioColors.BgPanel,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Выбор шрифта (${LayerFontFamily.entries.size} встроенных + .TTF/.OTF)",
                    color = StudioColors.TextPrimary,
                    fontSize = 15.sp
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            onImportCustomFontFile()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = StudioShapes.Chip,
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(StudioIcons.OpenFile, null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Загрузить шрифт (.TTF / .OTF)", fontSize = 11.sp, color = Color.White)
                    }
                    if (!customFontName.isNullOrBlank()) {
                        OutlinedButton(
                            onClick = onClearCustomFont,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Сбросить ($customFontName)", fontSize = 10.sp, color = StudioColors.AccentLightBlue)
                        }
                    }
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.heightIn(max = 400.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(LayerFontFamily.entries) { _, font ->
                    val isSelected = font == selectedFont && customFontName.isNullOrBlank()
                    val previewBmp = remember(font, sampleLine) {
                        StudioTextEngine.renderTextBitmap(
                            TextStyleConfig(
                                text = sampleLine,
                                fontFamily = font,
                                fontSize = 36f,
                                color = AndroidColor.WHITE,
                                alignment = TextAlignment.LEFT,
                                verticalAlignment = TextVerticalAlignment.CENTER,
                                boxWidth = 460f,
                                boxHeight = 64f
                            ),
                            maxCanvasWidth = 520
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(StudioShapes.Panel)
                            .background(if (isSelected) StudioColors.AccentBlue.copy(alpha = 0.35f) else StudioColors.BgDarkGray)
                            .border(
                                1.dp,
                                if (isSelected) StudioColors.AccentLightBlue else StudioColors.BorderSubtle,
                                StudioShapes.Panel
                            )
                            .clickable {
                                onSelectFont(font)
                                onDismiss()
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(font.displayName, color = StudioColors.TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(font.sampleSubtitle, color = StudioColors.TextSecondary, fontSize = 10.sp)
                            }
                            if (isSelected) {
                                Icon(StudioIcons.Check, null, tint = StudioColors.AccentLightBlue)
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Image(
                            bitmap = previewBmp.asImageBitmap(),
                            contentDescription = font.displayName,
                            contentScale = ContentScale.Fit,
                            alignment = Alignment.CenterStart,
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть", color = StudioColors.AccentLightBlue)
            }
        }
    )
}

private val studioPaletteSwatches = listOf(
    AndroidColor.WHITE, AndroidColor.BLACK, AndroidColor.GRAY,
    0xFF3794FF.toInt(), 0xFF007ACC.toInt(),
    0xFFE05252.toInt(), 0xFFFF9800.toInt(),
    0xFFFFEB3B.toInt(), 0xFF4EC9B0.toInt(),
    0xFF4CAF50.toInt(), 0xFF9C27B0.toInt(),
    0xFFE91E63.toInt()
)

/**
 * Фирменная палитра цветов Layer Studio (квадрат S×V, спектр Hue, альфа, HEX, пресеты, ползунки).
 */
@Composable
fun StudioColorPickerDialog(
    initialColor: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val initHsv = remember(initialColor) {
        FloatArray(3).also { AndroidColor.colorToHSV(initialColor, it) }
    }
    var hue by remember { mutableFloatStateOf(initHsv[0]) }
    var sat by remember { mutableFloatStateOf(initHsv[1]) }
    var value by remember { mutableFloatStateOf(initHsv[2]) }
    var alpha by remember { mutableFloatStateOf(AndroidColor.alpha(initialColor).toFloat()) }

    val currentColor = remember(hue, sat, value, alpha) {
        AndroidColor.HSVToColor(alpha.roundToInt().coerceIn(0, 255), floatArrayOf(hue, sat, value))
    }

    var hexInput by remember(currentColor) {
        mutableStateOf(String.format(Locale.US, "%06X", currentColor and 0xFFFFFF))
    }

    fun updateFromRgb(r: Int, g: Int, b: Int) {
        val hsv = FloatArray(3)
        AndroidColor.RGBToHSV(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255), hsv)
        hue = hsv[0]
        sat = hsv[1]
        value = hsv[2]
    }

    val rVal = AndroidColor.red(currentColor).toFloat()
    val gVal = AndroidColor.green(currentColor).toFloat()
    val bVal = AndroidColor.blue(currentColor).toFloat()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioColors.BgPanel,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Палитра цветов", color = StudioColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier
                        .clip(StudioShapes.Chip)
                        .border(1.dp, Color.White, StudioShapes.Chip)
                ) {
                    Box(modifier = Modifier.size(width = 28.dp, height = 24.dp).background(Color(initialColor)))
                    Box(modifier = Modifier.size(width = 28.dp, height = 24.dp).background(Color(currentColor)))
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(175.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val pureHueColor = remember(hue) {
                        Color(AndroidColor.HSVToColor(floatArrayOf(hue, 1f, 1f)))
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(StudioShapes.Panel)
                            .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Panel)
                            .pointerInput(Unit) {
                                awaitPointerEventScope {
                                    while (true) {
                                        val ev = awaitPointerEvent()
                                        val ch = ev.changes.firstOrNull { it.pressed } ?: continue
                                        val w = size.width.toFloat().coerceAtLeast(1f)
                                        val h = size.height.toFloat().coerceAtLeast(1f)
                                        sat = (ch.position.x / w).coerceIn(0f, 1f)
                                        value = (1f - (ch.position.y / h)).coerceIn(0f, 1f)
                                        ch.consume()
                                    }
                                }
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(brush = Brush.horizontalGradient(listOf(Color.White, pureHueColor)), size = size)
                            drawRect(brush = Brush.verticalGradient(listOf(Color.Transparent, Color.Black)), size = size)
                            val cx = sat * size.width
                            val cy = (1f - value) * size.height
                            drawCircle(Color.Black, radius = 8f, center = Offset(cx, cy), style = Stroke(width = 3f))
                            drawCircle(Color.White, radius = 8f, center = Offset(cx, cy), style = Stroke(width = 1.8f))
                        }
                    }

                    val rainbowColors = remember {
                        listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)
                    }
                    Box(
                        modifier = Modifier
                            .width(30.dp)
                            .fillMaxHeight()
                            .clip(StudioShapes.Panel)
                            .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Panel)
                            .pointerInput(Unit) {
                                awaitPointerEventScope {
                                    while (true) {
                                        val ev = awaitPointerEvent()
                                        val ch = ev.changes.firstOrNull { it.pressed } ?: continue
                                        val h = size.height.toFloat().coerceAtLeast(1f)
                                        hue = ((ch.position.y / h) * 360f).coerceIn(0f, 360f)
                                        ch.consume()
                                    }
                                }
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(brush = Brush.verticalGradient(rainbowColors), size = size)
                            val hy = (hue / 360f) * size.height
                            drawRect(
                                color = Color.White,
                                topLeft = Offset(0f, (hy - 3f).coerceIn(0f, size.height - 6f)),
                                size = Size(size.width, 6f),
                                style = Stroke(width = 2f)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(22.dp)
                        .clip(StudioShapes.Chip)
                        .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Chip)
                        .pointerInput(Unit) {
                            awaitPointerEventScope {
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val ch = ev.changes.firstOrNull { it.pressed } ?: continue
                                    val w = size.width.toFloat().coerceAtLeast(1f)
                                    alpha = ((ch.position.x / w) * 255f).coerceIn(0f, 255f)
                                    ch.consume()
                                }
                            }
                        }
                ) {
                    val opaqueCurrent = Color(AndroidColor.HSVToColor(255, floatArrayOf(hue, sat, value)))
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawRect(brush = Brush.horizontalGradient(listOf(Color.Transparent, opaqueCurrent)), size = size)
                        val ax = (alpha / 255f) * size.width
                        drawCircle(Color.White, radius = 7f, center = Offset(ax, size.height / 2f), style = Stroke(width = 2f))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = hexInput,
                        onValueChange = { raw ->
                            val clean = raw.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(6)
                            hexInput = clean
                            if (clean.length == 6) {
                                clean.toIntOrNull(16)?.let { rgb ->
                                    updateFromRgb((rgb shr 16) and 0xFF, (rgb shr 8) and 0xFF, rgb and 0xFF)
                                }
                            }
                        },
                        label = { Text("HEX #", fontSize = 10.sp) },
                        singleLine = true,
                        modifier = Modifier.width(120.dp).trackTextInputFocus(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = StudioColors.TextPrimary,
                            unfocusedTextColor = StudioColors.TextPrimary
                        )
                    )

                    Row(
                        modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        studioPaletteSwatches.forEach { swatch ->
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(StudioShapes.Circle)
                                    .background(Color(swatch))
                                    .border(1.dp, Color.White, StudioShapes.Circle)
                                    .clickable {
                                        updateFromRgb(
                                            AndroidColor.red(swatch),
                                            AndroidColor.green(swatch),
                                            AndroidColor.blue(swatch)
                                        )
                                        alpha = 255f
                                    }
                            )
                        }
                    }
                }

                StudioEditableSliderRow("H (Тон °)", hue, 0f..360f, "°", allowDecimals = false, onValueChange = { hue = it })
                StudioEditableSliderRow("S (Насыщ. %)", sat * 100f, 0f..100f, "%", allowDecimals = false, onValueChange = { sat = (it / 100f).coerceIn(0f, 1f) })
                StudioEditableSliderRow("B (Яркость %)", value * 100f, 0f..100f, "%", allowDecimals = false, onValueChange = { value = (it / 100f).coerceIn(0f, 1f) })
                StudioEditableSliderRow("R (Красный)", rVal, 0f..255f, allowDecimals = false, onValueChange = { updateFromRgb(it.roundToInt(), gVal.roundToInt(), bVal.roundToInt()) })
                StudioEditableSliderRow("G (Зелёный)", gVal, 0f..255f, allowDecimals = false, onValueChange = { updateFromRgb(rVal.roundToInt(), it.roundToInt(), bVal.roundToInt()) })
                StudioEditableSliderRow("B (Синий)", bVal, 0f..255f, allowDecimals = false, onValueChange = { updateFromRgb(rVal.roundToInt(), gVal.roundToInt(), it.roundToInt()) })
                StudioEditableSliderRow("Alpha (Прозр.)", alpha, 0f..255f, allowDecimals = false, onValueChange = { alpha = it })
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(currentColor) }) {
                Text("Выбрать", color = StudioColors.AccentLightBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена", color = StudioColors.TextSecondary)
            }
        }
    )
}
