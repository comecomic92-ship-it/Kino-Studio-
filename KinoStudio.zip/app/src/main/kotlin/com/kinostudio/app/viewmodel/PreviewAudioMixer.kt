package com.kinostudio.app.viewmodel

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.kinostudio.core.model.AudioClipItem
import com.kinostudio.core.model.TimelineTrack
import com.kinostudio.core.model.TrackKind
import kotlin.math.abs

class PreviewAudioMixer(private val context: Context) {
    private data class TrackPlayer(val clipId: String, val uri: String, val trimStart: Long, val trimEnd: Long, val player: ExoPlayer)
    private val players = mutableMapOf<String, TrackPlayer>()

    fun syncTracks(tracks: List<TimelineTrack>, clips: List<AudioClipItem>, playheadMs: Long, isPlaying: Boolean) {
        val audibleTrackIds = tracks.filter { it.kind == TrackKind.AUDIO && !it.isHidden && !it.isMuted }.map { it.id }.toSet()
        val activeIds = clips.map { it.id }.toSet()
        players.keys.filter { it !in activeIds }.forEach { id -> players.remove(id)?.player?.release() }

        for (clip in clips) {
            val existing = players[clip.id]
            val tp = if (existing == null || existing.uri != clip.sourceUri || existing.trimStart != clip.trimStartMs || existing.trimEnd != clip.trimEndMs) {
                existing?.player?.release()
                val exo = ExoPlayer.Builder(context).build().apply {
                    val item = MediaItem.Builder()
                        .setUri(Uri.parse(clip.sourceUri))
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(clip.trimStartMs.coerceAtLeast(0L))
                                .setEndPositionMs(clip.trimEndMs.coerceAtLeast(clip.trimStartMs + 100L))
                                .build()
                        )
                        .build()
                    setMediaItem(item); prepare()
                }
                TrackPlayer(clip.id, clip.sourceUri, clip.trimStartMs, clip.trimEndMs, exo).also { players[clip.id] = it }
            } else existing

            val inRange = clip.trackId in audibleTrackIds && !clip.isHidden && !clip.isMuted && playheadMs in clip.timelineStartMs until clip.timelineEndMs
            if (inRange) {
                val localMs = (playheadMs - clip.timelineStartMs).coerceAtLeast(0L)
                var gain = clip.volume.coerceIn(0f, 1f)
                if (clip.fadeInMs > 0L && localMs < clip.fadeInMs) gain *= (localMs.toFloat() / clip.fadeInMs.toFloat()).coerceIn(0f, 1f)
                val remMs = (clip.timelineEndMs - playheadMs).coerceAtLeast(0L)
                if (clip.fadeOutMs > 0L && remMs < clip.fadeOutMs) gain *= (remMs.toFloat() / clip.fadeOutMs.toFloat()).coerceIn(0f, 1f)
                tp.player.volume = gain
                tp.player.setPlaybackSpeed(clip.speed.coerceIn(0.25f, 4f))
                if (abs(tp.player.currentPosition - localMs) > 280L) tp.player.seekTo(localMs)
                if (tp.player.playWhenReady != isPlaying) tp.player.playWhenReady = isPlaying
            } else {
                if (tp.player.playWhenReady) tp.player.playWhenReady = false
            }
        }
    }

    fun pauseAll() { players.values.forEach { it.player.playWhenReady = false } }
    fun releaseAll() { players.values.forEach { runCatching { it.player.release() } }; players.clear() }
}
