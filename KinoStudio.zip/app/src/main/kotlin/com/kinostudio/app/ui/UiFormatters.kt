package com.kinostudio.app.ui

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatTimecode(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val totalSec = safe / 1000L
    return String.format(Locale.US, "%02d:%02d.%d", totalSec / 60L, totalSec % 60L, (safe % 1000L) / 100L)
}

fun formatProjectDate(epochMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(epochMs))
