package com.kinostudio.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kinostudio.app.viewmodel.SelectionState
import com.kinostudio.core.database.ThumbnailCache
import com.kinostudio.core.model.AudioClipItem
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.core.model.LongTaskState
import com.kinostudio.core.model.ClipEdgeEffect
import com.kinostudio.core.model.TextTrackItem
import com.kinostudio.core.model.TrackKind
import com.kinostudio.core.model.TransitionType
import com.kinostudio.core.model.VideoProject
import com.kinostudio.core.model.VisualClipItem
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioShapes
import kotlin.math.abs

private val LEFT_SIDEBAR_WIDTH = 62.dp

@Composable
fun MultiTrackTimeline(
    project: VideoProject,
    playheadMs: Long,
    zoom: Float,
    selection: SelectionState,
    longTask: LongTaskState? = null,
    thumbnailCache: ThumbnailCache,
    onSeek: (Long) -> Unit,
    onZoomChange: (Float) -> Unit,
    onToggleTrackSelect: (String) -> Unit,
    onToggleTrackHidden: (String) -> Unit,
    onMoveTrackOrder: (String, Int) -> Unit,
    onSelectVisual: (String, Boolean) -> Unit,
    onSelectText: (String, Boolean) -> Unit,
    onSelectAudio: (String, Boolean) -> Unit,
    onDragVisual: (String, Long, Int, Boolean) -> Unit,
    onDragText: (String, Long, Int, Boolean) -> Unit,
    onDragAudio: (String, Long, Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val dpPerSecond = (54f * zoom).coerceIn(22f, 220f)
    val density = LocalDensity.current
    val pxPerMs = with(density) { dpPerSecond.dp.toPx() / 1000f }
    val visualRowStepPx = with(density) { 34.dp.toPx() }
    val compactRowStepPx = with(density) { 26.dp.toPx() }
    val hScroll = rememberScrollState()
    val vScroll = rememberScrollState()
    val haptic = LocalHapticFeedback.current
    val timelineDurationMs = maxOf(project.totalDurationMs + 5000L, 15_000L)
    val totalWidthDp = ((timelineDurationMs / 1000f) * dpPerSecond).dp + 120.dp

    val orderedTracks = remember(project.tracks) {
        project.tracks.filter { it.kind == TrackKind.VISUAL }.reversed() +
            project.tracks.filter { it.kind == TrackKind.TEXT }.reversed() +
            project.tracks.filter { it.kind == TrackKind.AUDIO }
    }

    Row(modifier = modifier.fillMaxWidth().background(StudioColors.BgDarkGray).border(0.5.dp, StudioColors.BorderSubtle)) {
        // Compact pinned left sidebar (hide, reorder, multi-select track)
        Column(modifier = Modifier.width(LEFT_SIDEBAR_WIDTH).fillMaxHeight().background(StudioColors.BgGraphite).border(0.5.dp, StudioColors.BorderSubtle)) {
            Box(modifier = Modifier.fillMaxWidth().height(20.dp).background(StudioColors.BgPanel), contentAlignment = Alignment.Center) {
                Text("Слои", fontSize = 8.sp, color = StudioColors.TextSecondary, fontWeight = FontWeight.Medium)
            }
            Column(modifier = Modifier.fillMaxSize().verticalScroll(vScroll)) {
                orderedTracks.forEach { track ->
                    val rowH = when (track.kind) { TrackKind.VISUAL -> 46.dp; TrackKind.TEXT -> 32.dp; TrackKind.AUDIO -> 36.dp }
                    val isTrackSel = track.id in selection.selectedTrackIds
                    val kindColor = when (track.kind) { TrackKind.VISUAL -> StudioColors.TrackVideo; TrackKind.TEXT -> StudioColors.TrackText; TrackKind.AUDIO -> StudioColors.TrackAudio }
                    Row(
                        modifier = Modifier.fillMaxWidth().height(rowH)
                            .background(if (isTrackSel) StudioColors.AccentBlue.copy(alpha = 0.28f) else StudioColors.BgGraphite)
                            .border(0.5.dp, StudioColors.BorderSubtle).padding(horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier.clip(StudioShapes.Small).background(if (isTrackSel) StudioColors.AccentBlue else kindColor)
                                .clickable { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onToggleTrackSelect(track.id) }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) { Text(track.name, fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold) }
                        Icon(
                            if (track.isHidden) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Скрыть",
                            tint = if (track.isHidden) StudioColors.DangerRed else StudioColors.TextSecondary,
                            modifier = Modifier.size(13.dp).clickable { onToggleTrackHidden(track.id) }
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.KeyboardArrowUp, "Вверх", tint = StudioColors.TextSecondary, modifier = Modifier.size(12.dp).clickable { onMoveTrackOrder(track.id, if (track.kind == TrackKind.AUDIO) -1 else 1) })
                            Icon(Icons.Default.KeyboardArrowDown, "Вниз", tint = StudioColors.TextSecondary, modifier = Modifier.size(12.dp).clickable { onMoveTrackOrder(track.id, if (track.kind == TrackKind.AUDIO) 1 else -1) })
                        }
                    }
                }
            }
        }

        // Scrollable multi-track lanes + playhead
        Box(modifier = Modifier.weight(1f).fillMaxHeight().pointerInput(zoom) {
            detectTransformGestures { _, _, gestureZoom, _ -> if (gestureZoom != 1f) onZoomChange(zoom * gestureZoom) }
        }) {
            Column(modifier = Modifier.fillMaxSize().horizontalScroll(hScroll).width(totalWidthDp)) {
                TimeRulerRow(timelineDurationMs, dpPerSecond, pxPerMs, onSeek)
                Column(modifier = Modifier.fillMaxSize().verticalScroll(vScroll)) {
                    orderedTracks.forEach { track ->
                        val rowH = when (track.kind) { TrackKind.VISUAL -> 46.dp; TrackKind.TEXT -> 32.dp; TrackKind.AUDIO -> 36.dp }
                        Box(modifier = Modifier.fillMaxWidth().height(rowH).background(if (track.isHidden) StudioColors.BgBlack.copy(alpha = 0.85f) else StudioColors.BgBlack.copy(alpha = 0.45f)).border(0.5.dp, StudioColors.BorderSubtle.copy(alpha = 0.6f)).padding(vertical = 2.dp)) {
                            when (track.kind) {
                                TrackKind.VISUAL -> project.visualClips.filter { it.trackId == track.id }.forEach { clip ->
                                    FilmstripVisualClipBlock(
                                        clip = clip,
                                        startDp = ((clip.timelineStartMs / 1000f) * dpPerSecond).dp,
                                        widthDp = ((clip.effectiveDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(38.dp),
                                        pxPerMs = pxPerMs,
                                        rowStepPx = visualRowStepPx,
                                        isSelected = clip.id in selection.visualClipIds,
                                        taskProgressPercent = if (longTask?.targetClipId == clip.id) longTask.progressPercent else null,
                                        thumbnailCache = thumbnailCache,
                                        onTap = { onSelectVisual(clip.id, false) },
                                        onLongTap = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onSelectVisual(clip.id, true) },
                                        onDrag = { ms, vDelta, commit ->
                                            if (vDelta != 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            onDragVisual(clip.id, ms, vDelta, commit)
                                        }
                                    )
                                }
                                TrackKind.TEXT -> project.textItems.filter { it.trackId == track.id }.forEach { item ->
                                    TextTrackBlock(
                                        item = item,
                                        startDp = ((item.timelineStartMs / 1000f) * dpPerSecond).dp,
                                        widthDp = ((item.durationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(42.dp),
                                        pxPerMs = pxPerMs,
                                        rowStepPx = compactRowStepPx,
                                        isSelected = item.id in selection.textItemIds,
                                        onTap = { onSelectText(item.id, false) },
                                        onLongTap = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onSelectText(item.id, true) },
                                        onDrag = { ms, vDelta, commit ->
                                            if (vDelta != 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            onDragText(item.id, ms, vDelta, commit)
                                        }
                                    )
                                }
                                TrackKind.AUDIO -> project.audioClips.filter { it.trackId == track.id }.forEach { audio ->
                                    AudioTrackBlock(
                                        track = audio,
                                        startDp = ((audio.timelineStartMs / 1000f) * dpPerSecond).dp,
                                        widthDp = ((audio.effectiveDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(44.dp),
                                        pxPerMs = pxPerMs,
                                        rowStepPx = compactRowStepPx,
                                        isSelected = audio.id in selection.audioClipIds,
                                        onTap = { onSelectAudio(audio.id, false) },
                                        onLongTap = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onSelectAudio(audio.id, true) },
                                        onDrag = { ms, vDelta, commit ->
                                            if (vDelta != 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            // Audio tracks display A1 top -> A2 bottom, so dragging DOWN (+dy) moves to higher index (+1)
                                            onDragAudio(audio.id, ms, -vDelta, commit)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            val playheadX = with(density) { ((playheadMs / 1000f) * dpPerSecond).dp.toPx() } - hScroll.value
            if (playheadX >= 0f) {
                val playheadDp = with(density) { playheadX.toDp() }
                Box(modifier = Modifier.offset(x = playheadDp - 1.dp).fillMaxHeight().width(2.dp).background(Color.White))
                Box(modifier = Modifier.offset(x = playheadDp - 5.dp, y = 2.dp).size(10.dp).clip(CircleShape).background(StudioColors.AccentLightBlue).border(1.dp, Color.White, CircleShape))
            }
        }
    }
}

@Composable
private fun TimeRulerRow(totalDurationMs: Long, dpPerSecond: Float, pxPerMs: Float, onSeek: (Long) -> Unit) {
    val totalSeconds = (totalDurationMs / 1000L).toInt().coerceAtLeast(1)
    Box(
        modifier = Modifier.fillMaxWidth().height(20.dp).background(StudioColors.BgPanel)
            .pointerInput(pxPerMs) { detectTapGestures { offset -> onSeek((offset.x / pxPerMs).toLong().coerceAtLeast(0L)) } }
            .pointerInput(pxPerMs) { detectHorizontalDragGestures { change, _ -> change.consume(); onSeek((change.position.x / pxPerMs).toLong().coerceAtLeast(0L)) } }
    ) {
        val stepSec = when { dpPerSecond < 30f -> 5; dpPerSecond < 54f -> 2; else -> 1 }
        for (sec in 0..totalSeconds step stepSec) {
            Text(String.format("%02d:%02d", sec / 60, sec % 60), fontSize = 8.sp, color = StudioColors.TextSecondary, modifier = Modifier.offset(x = (sec * dpPerSecond).dp).padding(start = 2.dp, top = 3.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FilmstripVisualClipBlock(
    clip: VisualClipItem, startDp: Dp, widthDp: Dp, pxPerMs: Float, rowStepPx: Float, isSelected: Boolean,
    taskProgressPercent: Int?,
    thumbnailCache: ThumbnailCache, onTap: () -> Unit, onLongTap: () -> Unit, onDrag: (Long, Int, Boolean) -> Unit
) {
    val currentClip by rememberUpdatedState(clip)
    val frameCount = (widthDp.value / 44f).toInt().coerceIn(1, 14)
    var frames by remember(clip.id, clip.activeUri, clip.trimStartMs, clip.trimEndMs, frameCount) { mutableStateOf<List<Bitmap?>>(emptyList()) }
    LaunchedEffect(clip.id, clip.activeUri, clip.trimStartMs, clip.trimEndMs, frameCount) {
        frames = if (clip.isImage) listOf(thumbnailCache.getImageBitmap(clip.activeUri, 180))
        else thumbnailCache.getFilmstripFrames(clip.activeUri, clip.trimStartMs, clip.trimEndMs, frameCount, 96, 64)
    }
    var dragAccumX by remember { mutableFloatStateOf(0f) }
    var dragAccumY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier.offset(x = startDp).width(widthDp).fillMaxHeight().clip(StudioShapes.Small)
            .background(if (clip.isImage) StudioColors.TrackOverlay else StudioColors.TrackVideo)
            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) StudioColors.GuideEdgeCyan else StudioColors.BorderSubtle, StudioShapes.Small)
            .combinedClickable(onClick = onTap, onLongClick = onLongTap)
            .pointerInput(clip.id, clip.isLocked, pxPerMs, rowStepPx) {
                detectDragGestures(
                    onDragStart = { dragAccumX = 0f; dragAccumY = 0f },
                    onDragEnd = { if (!currentClip.isLocked) onDrag(currentClip.timelineStartMs, 0, true) }
                ) { change, dragAmount ->
                    if (!currentClip.isLocked) {
                        change.consume()
                        dragAccumX += dragAmount.x
                        dragAccumY += dragAmount.y

                        var vDelta = 0
                        if (dragAccumY <= -rowStepPx) { vDelta = 1; dragAccumY = 0f }
                        else if (dragAccumY >= rowStepPx) { vDelta = -1; dragAccumY = 0f }

                        val deltaMs = (dragAccumX / pxPerMs).toLong()
                        if (abs(deltaMs) >= 35L || vDelta != 0) {
                            val nextStart = (currentClip.timelineStartMs + if (abs(deltaMs) >= 35L) deltaMs else 0L).coerceAtLeast(0L)
                            if (abs(deltaMs) >= 35L) dragAccumX = 0f
                            onDrag(nextStart, vDelta, false)
                        }
                    }
                }
            }
    ) {
        if (frames.isNotEmpty()) {
            Row(modifier = Modifier.fillMaxSize()) {
                frames.forEach { bmp ->
                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        if (bmp != null && !bmp.isRecycled) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    }
                }
            }
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.22f)))
        }
        Row(modifier = Modifier.align(Alignment.BottomStart).padding(horizontal = 4.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (clip.speed != 1f) Text("${String.format("%.1f", clip.speed)}x", color = StudioColors.GuideEdgeCyan, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            if (clip.isReversed) Text("REV", color = StudioColors.WarningOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            if (clip.backgroundConfig.mode != BackgroundMode.NONE && (!clip.bgProcessedUri.isNullOrBlank() || !clip.bgMaskUri.isNullOrBlank())) {
                Text("BG", color = StudioColors.SuccessGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
            if (clip.transitionIn != TransitionType.NONE || clip.edgeEffectIn != ClipEdgeEffect.NONE || clip.edgeEffectOut != ClipEdgeEffect.NONE) {
                Text("FX", color = StudioColors.WarningOrange, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
        }

        // On-clip long task progress overlay
        if (taskProgressPercent != null) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((taskProgressPercent / 100f).coerceIn(0.03f, 1f))
                        .fillMaxHeight()
                        .background(StudioColors.AccentBlue.copy(alpha = 0.55f))
                )
                Text(
                    text = "$taskProgressPercent%",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TextTrackBlock(
    item: TextTrackItem, startDp: Dp, widthDp: Dp, pxPerMs: Float, rowStepPx: Float, isSelected: Boolean,
    onTap: () -> Unit, onLongTap: () -> Unit, onDrag: (Long, Int, Boolean) -> Unit
) {
    val currentItem by rememberUpdatedState(item)
    var dragAccumX by remember { mutableFloatStateOf(0f) }
    var dragAccumY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier.offset(x = startDp).width(widthDp).fillMaxHeight().clip(StudioShapes.Small)
            .background(if (item.isSubtitle) StudioColors.WarningOrange.copy(alpha = 0.45f) else StudioColors.TrackText)
            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color.White else StudioColors.AccentLightBlue.copy(alpha = 0.6f), StudioShapes.Small)
            .combinedClickable(onClick = onTap, onLongClick = onLongTap)
            .pointerInput(item.id, item.isLocked, pxPerMs, rowStepPx) {
                detectDragGestures(
                    onDragStart = { dragAccumX = 0f; dragAccumY = 0f },
                    onDragEnd = { if (!currentItem.isLocked) onDrag(currentItem.timelineStartMs, 0, true) }
                ) { change, dragAmount ->
                    if (!currentItem.isLocked) {
                        change.consume()
                        dragAccumX += dragAmount.x
                        dragAccumY += dragAmount.y
                        var vDelta = 0
                        if (dragAccumY <= -rowStepPx) { vDelta = 1; dragAccumY = 0f }
                        else if (dragAccumY >= rowStepPx) { vDelta = -1; dragAccumY = 0f }
                        val deltaMs = (dragAccumX / pxPerMs).toLong()
                        if (abs(deltaMs) >= 35L || vDelta != 0) {
                            val nextStart = (currentItem.timelineStartMs + if (abs(deltaMs) >= 35L) deltaMs else 0L).coerceAtLeast(0L)
                            if (abs(deltaMs) >= 35L) dragAccumX = 0f
                            onDrag(nextStart, vDelta, false)
                        }
                    }
                }
            }.padding(horizontal = 5.dp),
        contentAlignment = Alignment.CenterStart
    ) { Text(item.displayName, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AudioTrackBlock(
    track: AudioClipItem, startDp: Dp, widthDp: Dp, pxPerMs: Float, rowStepPx: Float, isSelected: Boolean,
    onTap: () -> Unit, onLongTap: () -> Unit, onDrag: (Long, Int, Boolean) -> Unit
) {
    val currentTrack by rememberUpdatedState(track)
    var dragAccumX by remember { mutableFloatStateOf(0f) }
    var dragAccumY by remember { mutableFloatStateOf(0f) }
    val accent = if (track.isVoiceover) StudioColors.DangerRed else StudioColors.SuccessGreen

    Box(
        modifier = Modifier.offset(x = startDp).width(widthDp).fillMaxHeight().clip(StudioShapes.Small)
            .background(StudioColors.TrackAudio.copy(alpha = if (track.isMuted) 0.35f else 0.85f))
            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) Color.White else accent.copy(alpha = 0.7f), StudioShapes.Small)
            .combinedClickable(onClick = onTap, onLongClick = onLongTap)
            .pointerInput(track.id, track.isLocked, pxPerMs, rowStepPx) {
                detectDragGestures(
                    onDragStart = { dragAccumX = 0f; dragAccumY = 0f },
                    onDragEnd = { if (!currentTrack.isLocked) onDrag(currentTrack.timelineStartMs, 0, true) }
                ) { change, dragAmount ->
                    if (!currentTrack.isLocked) {
                        change.consume()
                        dragAccumX += dragAmount.x
                        dragAccumY += dragAmount.y
                        var vDelta = 0
                        if (dragAccumY <= -rowStepPx) { vDelta = 1; dragAccumY = 0f }
                        else if (dragAccumY >= rowStepPx) { vDelta = -1; dragAccumY = 0f }
                        val deltaMs = (dragAccumX / pxPerMs).toLong()
                        if (abs(deltaMs) >= 35L || vDelta != 0) {
                            val nextStart = (currentTrack.timelineStartMs + if (abs(deltaMs) >= 35L) deltaMs else 0L).coerceAtLeast(0L)
                            if (abs(deltaMs) >= 35L) dragAccumX = 0f
                            onDrag(nextStart, vDelta, false)
                        }
                    }
                }
            }
    ) {
        val bars = if (track.waveform.isNotEmpty()) track.waveform else List(24) { 0.4f }
        Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 4.dp)) {
            val step = size.width / bars.size.coerceAtLeast(1)
            val midY = size.height / 2f
            bars.forEachIndexed { idx, amp ->
                val h = amp.coerceIn(0.1f, 1f) * size.height * 0.85f
                val x = idx * step + step * 0.5f
                drawLine(accent.copy(alpha = 0.85f), Offset(x, midY - h / 2f), Offset(x, midY + h / 2f), strokeWidth = (step * 0.5f).coerceIn(1.5f, 3.5f))
            }
        }
    }
}
