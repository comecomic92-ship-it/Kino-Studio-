package com.kinostudio.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kinostudio.core.database.ThumbnailCache
import com.kinostudio.core.model.BufferedMediaItem
import com.kinostudio.core.model.MediaKind
import com.layerstudio.kit.StudioActionChip
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioIcons
import com.layerstudio.kit.StudioShapes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaBufferSheet(
    bufferItems: List<BufferedMediaItem>,
    replaceMode: Boolean,
    thumbnailCache: ThumbnailCache,
    onImportGalleryVideoPhoto: () -> Unit,
    onImportGalleryAudio: () -> Unit,
    onSelectBufferItem: (BufferedMediaItem) -> Unit,
    onDeleteBufferItem: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = StudioColors.BgGraphite) {
        Column(
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(if (replaceMode) "Буфер: выберите замену" else "Буфер проекта (${bufferItems.size})", color = StudioColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(if (replaceMode) "Нажмите на файл, чтобы заменить выбранный клип" else "Загрузите файлы из галереи в буфер, затем добавляйте на дорожку", color = StudioColors.TextSecondary, fontSize = 11.sp)
                }
                IconButton(onClick = onDismiss) { Icon(StudioIcons.Close, "Закрыть", tint = StudioColors.TextSecondary) }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StudioActionChip("+ Видео / Фото из галереи", StudioIcons.Video, accent = true, onClick = onImportGalleryVideoPhoto)
                if (!replaceMode) StudioActionChip("+ Музыка / Звук", StudioIcons.Audio, onClick = onImportGalleryAudio)
            }

            val displayed = if (replaceMode) bufferItems.filter { it.kind != MediaKind.AUDIO } else bufferItems
            if (displayed.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().height(130.dp).clip(StudioShapes.Card).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card), contentAlignment = Alignment.Center) {
                    Text("Буфер пуст — добавьте файлы из галереи", color = StudioColors.TextSecondary, fontSize = 12.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 104.dp),
                    modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(displayed, key = { it.id }) { item ->
                        BufferMediaCard(item, replaceMode, thumbnailCache, { onSelectBufferItem(item) }, { onDeleteBufferItem(item.id) })
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun BufferMediaCard(item: BufferedMediaItem, replaceMode: Boolean, thumbnailCache: ThumbnailCache, onAddClick: () -> Unit, onDeleteClick: () -> Unit) {
    var thumb by remember(item.uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.uri, item.kind) {
        thumb = when (item.kind) {
            MediaKind.IMAGE -> thumbnailCache.getImageBitmap(item.uri, 240)
            MediaKind.VIDEO -> thumbnailCache.getFilmstripFrames(item.uri, 0L, item.durationMs, 1, 180, 120).firstOrNull()
            MediaKind.AUDIO -> null
        }
    }
    Column(modifier = Modifier.clip(StudioShapes.Panel).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Panel).clickable(onClick = onAddClick)) {
        Box(modifier = Modifier.fillMaxWidth().height(72.dp).background(StudioColors.BgBlack), contentAlignment = Alignment.Center) {
            if (thumb != null) Image(bitmap = thumb!!.asImageBitmap(), contentDescription = item.displayName, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Icon(if (item.kind == MediaKind.AUDIO) StudioIcons.Audio else StudioIcons.Video, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(26.dp))
            Box(modifier = Modifier.align(Alignment.TopStart).padding(4.dp).clip(StudioShapes.Small).background(when (item.kind) { MediaKind.VIDEO -> StudioColors.TrackVideo; MediaKind.IMAGE -> StudioColors.TrackOverlay; MediaKind.AUDIO -> StudioColors.TrackAudio }).padding(horizontal = 4.dp, vertical = 1.dp)) {
                Text(item.kind.label, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Box(modifier = Modifier.align(Alignment.TopEnd).padding(3.dp).size(20.dp).clip(StudioShapes.Small).background(Color.Black.copy(alpha = 0.65f)).clickable(onClick = onDeleteClick), contentAlignment = Alignment.Center) {
                Icon(StudioIcons.Close, "Убрать", tint = StudioColors.DangerRed, modifier = Modifier.size(12.dp))
            }
            if (item.kind != MediaKind.IMAGE) {
                Box(modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp).clip(StudioShapes.Small).background(Color.Black.copy(alpha = 0.7f)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                    Text(formatTimecode(item.durationMs), fontSize = 8.sp, color = Color.White)
                }
            }
        }
        Column(modifier = Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(item.displayName, color = StudioColors.TextPrimary, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Button(onClick = onAddClick, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue), shape = StudioShapes.Small, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp), modifier = Modifier.fillMaxWidth().height(24.dp)) {
                Text(if (replaceMode) "Заменить" else "+ На дорожку", fontSize = 9.sp, color = Color.White)
            }
        }
    }
}
