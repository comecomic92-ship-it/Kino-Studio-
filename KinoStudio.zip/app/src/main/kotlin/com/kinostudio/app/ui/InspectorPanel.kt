package com.kinostudio.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kinostudio.app.viewmodel.AudioSubPanel
import com.kinostudio.app.viewmodel.EditSubPanel
import com.kinostudio.app.viewmodel.EditorToolTab
import com.kinostudio.app.viewmodel.EditorViewModel
import com.kinostudio.app.viewmodel.SelectionState
import com.kinostudio.app.viewmodel.TextOverlayMapper
import com.kinostudio.app.viewmodel.TransformMode
import com.kinostudio.core.model.AudioClipItem
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.core.model.BufferedMediaItem
import com.kinostudio.core.model.ClipEdgeEffect
import com.kinostudio.core.model.ColorPreset
import com.kinostudio.core.model.MediaKind
import com.kinostudio.core.model.SpeedRampPoint
import com.kinostudio.core.model.TextTrackItem
import com.kinostudio.core.model.TransformState
import com.kinostudio.core.model.TransitionType
import com.kinostudio.core.model.VideoProject
import com.kinostudio.core.model.VisualClipItem
import com.layerstudio.kit.StudioActionChip
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioEditableSliderRow
import com.layerstudio.kit.StudioIcons
import com.layerstudio.kit.StudioManualNumberDialog
import com.layerstudio.kit.StudioShapes
import com.layerstudio.kit.StudioTextOptionsBar
import com.layerstudio.kit.StudioTextStyleInspectorPanel
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

private fun resolvePrimaryVisual(project: VideoProject, selection: SelectionState): VisualClipItem? =
    project.visualClips.firstOrNull { it.id == selection.primaryId }
        ?: project.visualClips.firstOrNull { it.id in selection.visualClipIds }

private fun resolvePrimaryText(project: VideoProject, selection: SelectionState): TextTrackItem? =
    project.textItems.firstOrNull { it.id == selection.primaryId }
        ?: project.textItems.firstOrNull { it.id in selection.textItemIds }

private fun resolvePrimaryAudio(project: VideoProject, selection: SelectionState): AudioClipItem? =
    project.audioClips.firstOrNull { it.id == selection.primaryId }
        ?: project.audioClips.firstOrNull { it.id in selection.audioClipIds }

@Composable
fun InspectorPanel(
    viewModel: EditorViewModel,
    project: VideoProject,
    activeTool: EditorToolTab,
    selection: SelectionState,
    onImportGalleryVisual: () -> Unit,
    onImportGalleryAudio: () -> Unit,
    onOpenReplaceBuffer: () -> Unit,
    onPickMusicDirect: () -> Unit,
    onToggleVoiceRecord: () -> Unit,
    onOpenFontPicker: () -> Unit,
    onOpenTextColorPicker: () -> Unit,
    onOpenBgColorPicker: () -> Unit,
    modifier: Modifier = Modifier
) {
    val editSubPanel by viewModel.editSubPanel.collectAsState()
    val transformMode by viewModel.transformMode.collectAsState()
    val audioSubPanel by viewModel.audioSubPanel.collectAsState()
    val hasClipboard by viewModel.hasClipboard.collectAsState()
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsState()
    val reverseProgress by viewModel.reverseProgress.collectAsState()
    val showTextStyleInspector by viewModel.showTextStyleInspector.collectAsState()
    val isBgModelReady by viewModel.isBgModelReady.collectAsState()
    val isPickingBgPoints by viewModel.isPickingBgPoints.collectAsState()
    val bgPointPositiveMode by viewModel.bgPointPositiveMode.collectAsState()
    val longTask by viewModel.longTask.collectAsState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(StudioColors.BgDarkGray)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        when (activeTool) {
            EditorToolTab.ADD -> AddBufferToolInspector(
                viewModel = viewModel,
                project = project,
                onImportGalleryVisual = onImportGalleryVisual,
                onImportGalleryAudio = onImportGalleryAudio
            )
            EditorToolTab.EDIT -> EditToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                subPanel = editSubPanel,
                hasClipboard = hasClipboard,
                onOpenReplaceBuffer = onOpenReplaceBuffer
            )
            EditorToolTab.TRANSFORM -> TransformToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                mode = transformMode
            )
            EditorToolTab.BACKGROUND -> BackgroundToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                isModelReady = isBgModelReady,
                isPickingPoints = isPickingBgPoints,
                positivePointMode = bgPointPositiveMode,
                isBusy = longTask != null,
                onOpenBgColorPicker = onOpenBgColorPicker
            )
            EditorToolTab.AUDIO -> AudioToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                subPanel = audioSubPanel,
                isRecordingVoice = isRecordingVoice,
                onPickMusicDirect = onPickMusicDirect,
                onToggleVoiceRecord = onToggleVoiceRecord
            )
            EditorToolTab.TEXT -> TextToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                showStyleInspector = showTextStyleInspector,
                onOpenFontPicker = onOpenFontPicker,
                onOpenTextColorPicker = onOpenTextColorPicker
            )
            EditorToolTab.COLOR -> ColorToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection
            )
            EditorToolTab.SPEED -> SpeedToolInspector(
                viewModel = viewModel,
                project = project,
                selection = selection,
                reverseProgress = reverseProgress
            )
        }
    }
}

// ============================================================
// НОВЫЙ ПЕРВЫЙ ИНСТРУМЕНТ «+ ДОБАВИТЬ» (БУФЕР ПРОЕКТА)
// ============================================================
@Composable
private fun AddBufferToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    onImportGalleryVisual: () -> Unit,
    onImportGalleryAudio: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        StudioActionChip("+ Видео / Фото", StudioIcons.Video, accent = true, onClick = onImportGalleryVisual)
        StudioActionChip("+ Музыка / Звук", StudioIcons.Audio, onClick = onImportGalleryAudio)
        StudioActionChip("+ Текст", StudioIcons.Text) { viewModel.addStudioText(false) }
        StudioActionChip("+ Субтитры", Icons.Default.Subtitles) { viewModel.addStudioText(true) }
    }

    if (project.mediaBuffer.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp)
                .clip(StudioShapes.Panel)
                .background(StudioColors.BgGraphite)
                .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Panel),
            contentAlignment = Alignment.Center
        ) {
            Text("Буфер пуст — загрузите файлы из галереи", color = StudioColors.TextSecondary, fontSize = 11.sp)
        }
    } else {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(project.mediaBuffer, key = { it.id }) { item ->
                InlineBufferCard(
                    item = item,
                    viewModel = viewModel,
                    onAdd = { viewModel.addBufferedItemToTimeline(item, atPlayhead = true) },
                    onRemove = { viewModel.removeFromBuffer(item.id) }
                )
            }
        }
    }
}

@Composable
private fun InlineBufferCard(
    item: BufferedMediaItem,
    viewModel: EditorViewModel,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    var thumb by remember(item.uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(item.uri, item.kind) {
        thumb = when (item.kind) {
            MediaKind.IMAGE -> viewModel.thumbnailCache.getImageBitmap(item.uri, 220)
            MediaKind.VIDEO -> viewModel.thumbnailCache.getFilmstripFrames(item.uri, 0L, item.durationMs, 1, 160, 100).firstOrNull()
            MediaKind.AUDIO -> null
        }
    }

    Column(
        modifier = Modifier
            .width(102.dp)
            .clip(StudioShapes.Panel)
            .background(StudioColors.BgGraphite)
            .border(1.dp, StudioColors.BorderSubtle, StudioShapes.Panel)
            .clickable(onClick = onAdd)
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(58.dp).background(StudioColors.BgBlack), contentAlignment = Alignment.Center) {
            if (thumb != null) Image(bitmap = thumb!!.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Icon(if (item.kind == MediaKind.AUDIO) StudioIcons.Audio else StudioIcons.Video, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(22.dp))

            Box(
                modifier = Modifier.align(Alignment.TopEnd).padding(2.dp).size(18.dp)
                    .clip(StudioShapes.Small).background(Color.Black.copy(alpha = 0.65f)).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) { Icon(StudioIcons.Close, null, tint = StudioColors.DangerRed, modifier = Modifier.size(11.dp)) }

            if (item.kind != MediaKind.IMAGE) {
                Box(modifier = Modifier.align(Alignment.BottomEnd).padding(2.dp).clip(StudioShapes.Small).background(Color.Black.copy(alpha = 0.7f)).padding(horizontal = 3.dp, vertical = 1.dp)) {
                    Text(formatTimecode(item.durationMs), fontSize = 8.sp, color = Color.White)
                }
            }
        }
        Column(modifier = Modifier.padding(4.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(item.displayName, color = StudioColors.TextPrimary, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Box(
                modifier = Modifier.fillMaxWidth().clip(StudioShapes.Small).background(StudioColors.AccentBlue).padding(vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) { Text("+ На дорожку", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.SemiBold) }
        }
    }
}

// ============================================================
// МОНТАЖ (Разные значки у Обрезка и Разделить + Переделанные Переходы)
// ============================================================
@Composable
private fun EditToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    subPanel: EditSubPanel,
    hasClipboard: Boolean,
    onOpenReplaceBuffer: () -> Unit
) {
    val clip = resolvePrimaryVisual(project, selection)
    val audio = resolvePrimaryAudio(project, selection)
    val textItem = resolvePrimaryText(project, selection)

    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Distinct icons: Crop for Обрезка, Scissors (SplitClip) for Разделить
        StudioActionChip("Обрезка", StudioIcons.Crop, accent = subPanel == EditSubPanel.TRIM) {
            viewModel.setEditSubPanel(EditSubPanel.TRIM)
        }
        StudioActionChip("Копировать", Icons.Default.ContentCopy, enabled = !selection.isEmpty) { viewModel.copySelected() }
        StudioActionChip("Вставить", Icons.Default.ContentPaste, enabled = hasClipboard) { viewModel.pasteClipboardAtPlayhead() }
        StudioActionChip("Дублировать", Icons.Default.LibraryAdd, enabled = !selection.isEmpty) { viewModel.duplicateSelected() }
        StudioActionChip("Заменить", Icons.Default.SwapHoriz, enabled = clip != null) { onOpenReplaceBuffer() }
        StudioActionChip("Переходы", StudioIcons.Filters, enabled = clip != null, accent = subPanel == EditSubPanel.TRANSITIONS) {
            viewModel.setEditSubPanel(EditSubPanel.TRANSITIONS)
        }
        StudioActionChip("Слой ▲", Icons.Default.ArrowUpward, enabled = !selection.isEmpty) { viewModel.moveSelectedItemsVerticalTrack(1) }
        StudioActionChip("Слой ▼", Icons.Default.ArrowDownward, enabled = !selection.isEmpty) { viewModel.moveSelectedItemsVerticalTrack(-1) }
        StudioActionChip("Удалить", StudioIcons.Delete, enabled = !selection.isEmpty) { viewModel.deleteSelected() }
    }

    when (subPanel) {
        EditSubPanel.TRIM -> {
            val canMerge = selection.visualClipIds.size >= 2 || selection.audioClipIds.size >= 2
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StudioActionChip("Разделить", StudioIcons.SplitClip, enabled = !selection.isEmpty, accent = true) { viewModel.splitSelectedAtPlayhead() }
                if (canMerge) {
                    StudioActionChip("Объединить (${selection.totalSelectedCount})", Icons.Default.MergeType, accent = true) { viewModel.mergeSelectedClips() }
                }
            }

            if (clip != null) {
                val maxSec = (clip.sourceDurationMs / 1000f).coerceAtLeast(0.5f)
                val startSec = clip.trimStartMs / 1000f
                val endSec = clip.trimEndMs / 1000f
                StudioEditableSliderRow(
                    label = "Начало (сек)",
                    value = startSec,
                    sliderRange = 0f..(endSec - 0.2f).coerceAtLeast(0.1f),
                    unitSuffix = " с",
                    minManual = 0f,
                    maxManual = (endSec - 0.1f).coerceAtLeast(0.1f),
                    allowDecimals = true,
                    onValueChange = { s -> viewModel.updatePrimaryVisualClip(false) { it.copy(trimStartMs = (s * 1000f).toLong().coerceIn(0L, it.trimEndMs - 100L)) } },
                    onValueCommit = { s -> viewModel.updatePrimaryVisualClip(true) { it.copy(trimStartMs = (s * 1000f).toLong().coerceIn(0L, it.trimEndMs - 100L)) } }
                )
                StudioEditableSliderRow(
                    label = "Конец (сек)",
                    value = endSec,
                    sliderRange = (startSec + 0.2f).coerceAtMost(maxSec)..maxSec.coerceAtLeast(startSec + 0.3f),
                    unitSuffix = " с",
                    minManual = startSec + 0.1f,
                    maxManual = if (clip.isImage) 120f else maxSec,
                    allowDecimals = true,
                    onValueChange = { e ->
                        val ms = (e * 1000f).toLong()
                        viewModel.updatePrimaryVisualClip(false) {
                            if (it.isImage) it.copy(sourceDurationMs = ms.coerceAtLeast(300L), trimEndMs = ms.coerceAtLeast(300L))
                            else it.copy(trimEndMs = ms.coerceIn(it.trimStartMs + 100L, it.sourceDurationMs))
                        }
                    },
                    onValueCommit = { e ->
                        val ms = (e * 1000f).toLong()
                        viewModel.updatePrimaryVisualClip(true) {
                            if (it.isImage) it.copy(sourceDurationMs = ms.coerceAtLeast(300L), trimEndMs = ms.coerceAtLeast(300L))
                            else it.copy(trimEndMs = ms.coerceIn(it.trimStartMs + 100L, it.sourceDurationMs))
                        }
                    }
                )
            } else if (audio != null) {
                val maxSec = (audio.sourceDurationMs / 1000f).coerceAtLeast(0.5f)
                val startSec = audio.trimStartMs / 1000f
                val endSec = audio.trimEndMs / 1000f
                StudioEditableSliderRow("Начало аудио", startSec, 0f..(endSec - 0.2f).coerceAtLeast(0.1f), " с", allowDecimals = true, onValueChange = { s -> viewModel.updatePrimaryAudioClip(false) { it.copy(trimStartMs = (s * 1000f).toLong().coerceIn(0L, it.trimEndMs - 100L)) } })
                StudioEditableSliderRow("Конец аудио", endSec, (startSec + 0.2f).coerceAtMost(maxSec)..maxSec, " с", allowDecimals = true, onValueChange = { e -> viewModel.updatePrimaryAudioClip(false) { it.copy(trimEndMs = (e * 1000f).toLong().coerceIn(it.trimStartMs + 100L, it.sourceDurationMs)) } })
            } else if (textItem != null) {
                StudioEditableSliderRow("Длительность текста", textItem.durationMs / 1000f, 0.3f..30f, " с", minManual = 0.2f, maxManual = 120f, allowDecimals = true, onValueChange = { s -> viewModel.updatePrimaryTextDuration((s * 1000f).toLong(), false) }, onValueCommit = { s -> viewModel.updatePrimaryTextDuration((s * 1000f).toLong(), true) })
            }
        }

        EditSubPanel.TRANSITIONS -> {
            if (clip == null) return
            var transTab by remember { mutableStateOf(0) } // 0 = Между клипами, 1 = Начало, 2 = Конец

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = transTab == 0, onClick = { transTab = 0 }, label = { Text("Между видео", fontSize = 11.sp) })
                FilterChip(selected = transTab == 1, onClick = { transTab = 1 }, label = { Text("Начало клипа", fontSize = 11.sp) })
                FilterChip(selected = transTab == 2, onClick = { transTab = 2 }, label = { Text("Конец клипа", fontSize = 11.sp) })
            }

            when (transTab) {
                0 -> {
                    val junctionTarget = viewModel.findBetweenTransitionTargetClip(project, clip)
                    if (junctionTarget == null) {
                        Text("Поставьте два видео рядом на одной дорожке для стыкового перехода.", fontSize = 11.sp, color = StudioColors.TextSecondary)
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(TransitionType.entries) { tr ->
                                FilterChip(
                                    selected = junctionTarget.transitionIn == tr,
                                    onClick = { viewModel.applyBetweenTransition(junctionTarget.id, tr) },
                                    label = { Text(tr.label, fontSize = 11.sp) }
                                )
                            }
                        }
                        if (junctionTarget.transitionIn != TransitionType.NONE) {
                            StudioEditableSliderRow(
                                label = "Длительность перехода",
                                value = junctionTarget.transitionDurationMs / 1000f,
                                sliderRange = 0.15f..2.0f,
                                unitSuffix = " с",
                                allowDecimals = true,
                                onValueChange = { s -> viewModel.applyBetweenTransition(junctionTarget.id, junctionTarget.transitionIn, (s * 1000f).toLong()) }
                            )
                        }
                    }
                }
                1 -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ClipEdgeEffect.entries) { ef ->
                            FilterChip(
                                selected = clip.edgeEffectIn == ef,
                                onClick = { viewModel.updatePrimaryVisualClip(true) { it.copy(edgeEffectIn = ef) } },
                                label = { Text(ef.label, fontSize = 11.sp) }
                            )
                        }
                    }
                    if (clip.edgeEffectIn != ClipEdgeEffect.NONE) {
                        StudioEditableSliderRow(
                            label = "Длительность в начале",
                            value = clip.edgeEffectInMs / 1000f,
                            sliderRange = 0.15f..3.0f,
                            unitSuffix = " с",
                            allowDecimals = true,
                            onValueChange = { s -> viewModel.updatePrimaryVisualClip(false) { it.copy(edgeEffectInMs = (s * 1000f).toLong()) } }
                        )
                    }
                }
                else -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ClipEdgeEffect.entries) { ef ->
                            FilterChip(
                                selected = clip.edgeEffectOut == ef,
                                onClick = { viewModel.updatePrimaryVisualClip(true) { it.copy(edgeEffectOut = ef) } },
                                label = { Text(ef.label, fontSize = 11.sp) }
                            )
                        }
                    }
                    if (clip.edgeEffectOut != ClipEdgeEffect.NONE) {
                        StudioEditableSliderRow(
                            label = "Длительность в конце",
                            value = clip.edgeEffectOutMs / 1000f,
                            sliderRange = 0.15f..3.0f,
                            unitSuffix = " с",
                            allowDecimals = true,
                            onValueChange = { s -> viewModel.updatePrimaryVisualClip(false) { it.copy(edgeEffectOutMs = (s * 1000f).toLong()) } }
                        )
                    }
                }
            }
        }

        EditSubPanel.NONE -> Unit
    }
}

// ============================================================
// ТРАНСФОРМАЦИЯ (Без подсказок, точная перспектива -38%..+38%)
// ============================================================
@Composable
private fun TransformToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    mode: TransformMode
) {
    val activeTf: TransformState? = resolvePrimaryVisual(project, selection)?.transform
        ?: resolvePrimaryText(project, selection)?.transform

    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StudioActionChip("Свободная", StudioIcons.Transform, accent = mode == TransformMode.FREE) { viewModel.setTransformMode(TransformMode.FREE) }
        StudioActionChip("Перспектива", Icons.Default.GridOn, accent = mode == TransformMode.PERSPECTIVE) { viewModel.setTransformMode(TransformMode.PERSPECTIVE) }
        StudioActionChip("Отразить ↔", Icons.Default.Flip, enabled = !selection.isEmpty) { viewModel.flipSelectedHorizontal() }
        StudioActionChip("Отразить ↕", Icons.Default.SwapHoriz, enabled = !selection.isEmpty) { viewModel.flipSelectedVertical() }
        StudioActionChip("Все слои", Icons.Default.SelectAll) { viewModel.selectAllItems() }
        StudioActionChip("Сбросить", Icons.Default.RestartAlt, enabled = !selection.isEmpty) { viewModel.resetSelectedTransform() }
    }

    if (activeTf == null) return

    if (mode == TransformMode.FREE) {
        StudioEditableSliderRow("Масштаб X", activeTf.scaleX * 100f, 15f..350f, "%", 5f, 500f, false,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(scaleX = (v / 100f).coerceIn(0.05f, 5f)) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(scaleX = (v / 100f).coerceIn(0.05f, 5f)) } })
        StudioEditableSliderRow("Масштаб Y", activeTf.scaleY * 100f, 15f..350f, "%", 5f, 500f, false,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(scaleY = (v / 100f).coerceIn(0.05f, 5f)) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(scaleY = (v / 100f).coerceIn(0.05f, 5f)) } })
        StudioEditableSliderRow("Поворот", activeTf.rotationDeg, -180f..180f, "°", -360f, 360f, true,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(rotationDeg = v) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(rotationDeg = v) } })
        StudioEditableSliderRow("Позиция X", activeTf.offsetX * 100f, -100f..100f, "%", -150f, 150f, true,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(offsetX = v / 100f) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(offsetX = v / 100f) } })
        StudioEditableSliderRow("Позиция Y", activeTf.offsetY * 100f, -100f..100f, "%", -150f, 150f, true,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(offsetY = v / 100f) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(offsetY = v / 100f) } })
        StudioEditableSliderRow("Прозрачность", activeTf.opacity * 100f, 0f..100f, "%", 0f, 100f, false,
            { v -> viewModel.updateSelectedTransforms(false) { it.copy(opacity = (v / 100f).coerceIn(0f, 1f)) } },
            { v -> viewModel.updateSelectedTransforms(true) { it.copy(opacity = (v / 100f).coerceIn(0f, 1f)) } })
    } else {
        StudioEditableSliderRow("Верх-Левый X", activeTf.tlX * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(tlX = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Верх-Левый Y", activeTf.tlY * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(tlY = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Верх-Правый X", activeTf.trX * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(trX = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Верх-Правый Y", activeTf.trY * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(trY = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Низ-Левый X", activeTf.blX * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(blX = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Низ-Левый Y", activeTf.blY * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(blY = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Низ-Правый X", activeTf.brX * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(brX = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
        StudioEditableSliderRow("Низ-Правый Y", activeTf.brY * 100f, -38f..38f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateSelectedTransforms(false) { it.copy(brY = (v / 100f).coerceIn(-0.38f, 0.38f)) } })
    }
}

// ============================================================
// ФОН: Удалить фон, Выбрать объект (зелёные/красные точки), Инверсия, Края, Вариант фона, Сброс
// ============================================================
@Composable
private fun BackgroundToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    isModelReady: Boolean,
    isPickingPoints: Boolean,
    positivePointMode: Boolean,
    isBusy: Boolean,
    onOpenBgColorPicker: () -> Unit
) {
    val clip = resolvePrimaryVisual(project, selection)
    if (clip == null) {
        Text("Выберите видео или фото на дорожке.", fontSize = 11.sp, color = StudioColors.TextSecondary)
        return
    }

    val cfg = clip.backgroundConfig
    val isProcessed = !clip.bgProcessedUri.isNullOrBlank() || !clip.bgMaskUri.isNullOrBlank()

    // Primary Actions Row
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        StudioActionChip(
            label = "Удалить фон",
            icon = StudioIcons.SelectObjectAi,
            enabled = !isBusy,
            accent = !isPickingPoints && isProcessed && !cfg.objectSelectionMode
        ) {
            viewModel.applyAutoRemoveBackground()
        }
        StudioActionChip(
            label = "Выбрать объект",
            icon = Icons.Default.TouchApp,
            enabled = !isBusy,
            accent = isPickingPoints
        ) {
            viewModel.setBgPickingMode(!isPickingPoints)
        }
        StudioActionChip(
            label = "Инверсия",
            icon = Icons.Default.InvertColors,
            enabled = !isBusy,
            accent = cfg.invertMask
        ) {
            viewModel.updateBgConfig(true) { it.copy(invertMask = !it.invertMask) }
        }
        StudioActionChip(
            label = "Сбросить",
            icon = Icons.Default.RestartAlt,
            enabled = !isBusy && (isProcessed || cfg.mode != BackgroundMode.NONE || cfg.points.isNotEmpty())
        ) {
            viewModel.resetSelectedBackground()
        }
    }

    if (!isModelReady) {
        Text(
            text = "При первом нажатии загрузится точная нейросеть (~178 МБ), далее работает офлайн.",
            fontSize = 10.sp,
            color = StudioColors.AccentLightBlue
        )
    }

    // Object Point-Selection Controls (Green Keep / Red Remove + Apply)
    if (isPickingPoints) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = positivePointMode,
                onClick = { viewModel.setBgPointPositive(true) },
                label = { Text("+ Оставить", fontSize = 11.sp, color = Color(0xFF4ADE80)) }
            )
            FilterChip(
                selected = !positivePointMode,
                onClick = { viewModel.setBgPointPositive(false) },
                label = { Text("− Убрать", fontSize = 11.sp, color = Color(0xFFF87171)) }
            )
            StudioActionChip("Очистить (${cfg.points.size})", StudioIcons.Close, enabled = cfg.points.isNotEmpty()) {
                viewModel.clearBgPoints()
            }
            StudioActionChip("Применить", StudioIcons.Check, enabled = !isBusy && cfg.points.isNotEmpty(), accent = true) {
                viewModel.applyObjectSelectionBackground()
            }
        }
    }

    // Background Replacement Variant (Transparent / Blur / Color)
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("Фон:", fontSize = 11.sp, color = StudioColors.TextSecondary)
        listOf(BackgroundMode.TRANSPARENT, BackgroundMode.BLUR, BackgroundMode.COLOR).forEach { mode ->
            FilterChip(
                selected = cfg.mode == mode,
                onClick = {
                    viewModel.updateBgConfig(true) { it.copy(mode = mode) }
                    if (mode == BackgroundMode.COLOR) onOpenBgColorPicker()
                },
                label = { Text(mode.label, fontSize = 11.sp) }
            )
        }
        if (cfg.mode == BackgroundMode.COLOR) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(StudioShapes.Circle)
                    .background(Color(cfg.solidColorArgb))
                    .border(1.5.dp, Color.White, StudioShapes.Circle)
                    .clickable(onClick = onOpenBgColorPicker)
            )
        }
    }

    if (cfg.mode == BackgroundMode.BLUR) {
        StudioEditableSliderRow(
            label = "Сила размытия",
            value = cfg.blurStrength,
            sliderRange = 4f..35f,
            unitSuffix = "",
            allowDecimals = false,
            onValueChange = { v -> viewModel.updateBgConfig(false) { it.copy(blurStrength = v) } }
        )
    }

    // Edge Refinement Sliders (Softness & Contour)
    StudioEditableSliderRow(
        label = "Мягкость края",
        value = cfg.featherPx,
        sliderRange = 0f..20f,
        unitSuffix = " px",
        allowDecimals = false,
        onValueChange = { v -> viewModel.updateBgConfig(false) { it.copy(featherPx = v) } }
    )
    StudioEditableSliderRow(
        label = "Контур (сужение / расширение)",
        value = cfg.contourPx,
        sliderRange = -12f..12f,
        unitSuffix = " px",
        allowDecimals = false,
        onValueChange = { v -> viewModel.updateBgConfig(false) { it.copy(contourPx = v) } }
    )

    if (!isPickingPoints && cfg.mode != BackgroundMode.NONE) {
        Button(
            onClick = { viewModel.reapplyBackgroundSettings() },
            enabled = !isBusy,
            colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue),
            shape = StudioShapes.Chip,
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
            modifier = Modifier.height(32.dp)
        ) {
            Text(if (isProcessed) "Обновить обработку" else "Применить", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ============================================================
// ЗВУК (Убрано длинное название файла, интерфейс больше не ломается)
// ============================================================
@Composable
private fun AudioToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    subPanel: AudioSubPanel,
    isRecordingVoice: Boolean,
    onPickMusicDirect: () -> Unit,
    onToggleVoiceRecord: () -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StudioActionChip("Добавить", StudioIcons.Add, accent = subPanel == AudioSubPanel.ADD) { viewModel.setAudioSubPanel(AudioSubPanel.ADD) }
        StudioActionChip("Редактор", StudioIcons.Waveform, accent = subPanel == AudioSubPanel.EDIT) { viewModel.setAudioSubPanel(AudioSubPanel.EDIT) }
        StudioActionChip("Отделить звук", StudioIcons.SplitClip) { viewModel.detachAudioFromSelectedClip() }
    }

    if (subPanel == AudioSubPanel.ADD) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StudioActionChip("Добавить музыку", StudioIcons.Audio, accent = true, onClick = onPickMusicDirect)
            StudioActionChip(
                label = if (isRecordingVoice) "Стоп запись" else "Запись голоса",
                icon = if (isRecordingVoice) Icons.Default.Stop else Icons.Default.Mic,
                accent = isRecordingVoice,
                onClick = onToggleVoiceRecord
            )
        }
    } else {
        val audio = resolvePrimaryAudio(project, selection)
        val clip = resolvePrimaryVisual(project, selection)

        if (audio != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                StudioActionChip(if (audio.isMuted) "Без звука" else "Звук вкл", if (audio.isMuted) Icons.Default.VolumeOff else StudioIcons.Volume, accent = !audio.isMuted) {
                    viewModel.updatePrimaryAudioClip(true) { it.copy(isMuted = !it.isMuted) }
                }
                StudioActionChip("Удалить", StudioIcons.Delete) { viewModel.deleteSelected() }
            }
            StudioEditableSliderRow("Громкость", audio.volume * 100f, 0f..150f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updatePrimaryAudioClip(false) { it.copy(volume = v / 100f) } })
            StudioEditableSliderRow("Появление", audio.fadeInMs / 1000f, 0f..4f, " с", allowDecimals = true, onValueChange = { v -> viewModel.updatePrimaryAudioClip(false) { it.copy(fadeInMs = (v * 1000f).toLong()) } })
            StudioEditableSliderRow("Затухание", audio.fadeOutMs / 1000f, 0f..4f, " с", allowDecimals = true, onValueChange = { v -> viewModel.updatePrimaryAudioClip(false) { it.copy(fadeOutMs = (v * 1000f).toLong()) } })
            StudioEditableSliderRow("Скорость", audio.speed, 0.5f..2.5f, "x", allowDecimals = true, onValueChange = { v -> viewModel.updatePrimaryAudioClip(false) { it.copy(speed = v) } })
        } else if (clip != null && !clip.isImage) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Звук видео", color = StudioColors.TextPrimary, fontSize = 12.sp)
                Switch(checked = !clip.isAudioMuted, onCheckedChange = { en -> viewModel.updatePrimaryVisualClip(true) { it.copy(isAudioMuted = !en) } })
            }
            if (!clip.isAudioMuted) {
                StudioEditableSliderRow("Громкость", clip.volume * 100f, 0f..150f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updatePrimaryVisualClip(false) { it.copy(volume = v / 100f) } })
                StudioEditableSliderRow("Появление", clip.fadeInMs / 1000f, 0f..3f, " с", allowDecimals = true, onValueChange = { v -> viewModel.updatePrimaryVisualClip(false) { it.copy(fadeInMs = (v * 1000f).toLong()) } })
                StudioEditableSliderRow("Затухание", clip.fadeOutMs / 1000f, 0f..3f, " с", allowDecimals = true, onValueChange = { v -> viewModel.updatePrimaryVisualClip(false) { it.copy(fadeOutMs = (v * 1000f).toLong()) } })
            }
        }
    }
}

// ============================================================
// ТЕКСТ (Layer Studio v7.3)
// ============================================================
@Composable
private fun TextToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    showStyleInspector: Boolean,
    onOpenFontPicker: () -> Unit,
    onOpenTextColorPicker: () -> Unit
) {
    val textItem = resolvePrimaryText(project, selection)
    val (projW, projH) = project.resolvedDimensions()

    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        StudioActionChip("+ Текст", StudioIcons.Text, accent = true) { viewModel.addStudioText(false) }
        StudioActionChip("+ Субтитры", Icons.Default.Subtitles) { viewModel.addStudioText(true) }
        if (textItem != null) {
            StudioActionChip("Редактировать", StudioIcons.Move) { viewModel.setEditingTextOnCanvas(textItem.id) }
            StudioActionChip("Удалить", StudioIcons.Delete) { viewModel.deleteSelected() }
        }
    }

    if (textItem == null) return
    val overlay = TextOverlayMapper.toStudioOverlay(textItem, projW, projH)

    StudioTextOptionsBar(
        style = overlay.style,
        onUpdateStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
        onOpenFontPicker = onOpenFontPicker,
        onToggleStyleInspector = { viewModel.toggleTextStyleInspector() },
        onOpenColorPicker = onOpenTextColorPicker
    )

    if (showStyleInspector) {
        StudioTextStyleInspectorPanel(
            style = overlay.style,
            onUpdateStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
            onOpenFontPicker = onOpenFontPicker,
            onClosePanel = { viewModel.toggleTextStyleInspector() }
        )
    }

    StudioEditableSliderRow("Длительность", textItem.durationMs / 1000f, 0.5f..30f, " с", 0.2f, 120f, true,
        { s -> viewModel.updatePrimaryTextDuration((s * 1000f).toLong(), false) },
        { s -> viewModel.updatePrimaryTextDuration((s * 1000f).toLong(), true) })
}

// ============================================================
// ЦВЕТ
// ============================================================
@Composable
private fun ColorToolInspector(viewModel: EditorViewModel, project: VideoProject, selection: SelectionState) {
    val cfg = resolvePrimaryVisual(project, selection)?.colorGrading ?: project.globalColorGrading

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Пресеты", fontSize = 11.sp, color = StudioColors.TextSecondary)
        OutlinedButton(onClick = { viewModel.resetColorGrading() }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp), modifier = Modifier.height(26.dp)) {
            Text("Сброс", fontSize = 11.sp, color = StudioColors.AccentLightBlue)
        }
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(ColorPreset.entries) { preset -> FilterChip(selected = cfg.preset == preset, onClick = { viewModel.applyColorPreset(preset) }, label = { Text(preset.label, fontSize = 11.sp) }) }
    }

    StudioEditableSliderRow("Яркость", cfg.brightness * 100f, -100f..100f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(brightness = v / 100f) } })
    StudioEditableSliderRow("Контрастность", cfg.contrast * 100f, 20f..200f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(contrast = v / 100f) } })
    StudioEditableSliderRow("Экспозиция", cfg.exposure, -2f..2f, " EV", allowDecimals = true, onValueChange = { v -> viewModel.updateColorGrading { it.copy(exposure = v) } })
    StudioEditableSliderRow("Насыщенность", cfg.saturation * 100f, 0f..200f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(saturation = v / 100f) } })
    StudioEditableSliderRow("Температура", cfg.temperature * 100f, -100f..100f, "", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(temperature = v / 100f) } })
    StudioEditableSliderRow("Оттенок", cfg.tint * 100f, -100f..100f, "", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(tint = v / 100f) } })
    StudioEditableSliderRow("Светлые участки", cfg.highlights * 100f, -100f..100f, "", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(highlights = v / 100f) } })
    StudioEditableSliderRow("Тени", cfg.shadows * 100f, -100f..100f, "", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(shadows = v / 100f) } })
    StudioEditableSliderRow("Резкость", cfg.sharpen * 100f, 0f..100f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(sharpen = v / 100f) } })
    StudioEditableSliderRow("Виньетка", cfg.vignette * 100f, 0f..100f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(vignette = v / 100f) } })
    StudioEditableSliderRow("HSL Оттенок", cfg.hslHue, -180f..180f, "°", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(hslHue = v) } })
    StudioEditableSliderRow("RGB Красный", cfg.rgbRedGain * 100f, 50f..150f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(rgbRedGain = v / 100f) } })
    StudioEditableSliderRow("RGB Зелёный", cfg.rgbGreenGain * 100f, 50f..150f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(rgbGreenGain = v / 100f) } })
    StudioEditableSliderRow("RGB Синий", cfg.rgbBlueGain * 100f, 50f..150f, "%", allowDecimals = false, onValueChange = { v -> viewModel.updateColorGrading { it.copy(rgbBlueGain = v / 100f) } })
}

// ============================================================
// СКОРОСТЬ (Значение 1.0x строго по центру, цвет от центра влево/вправо!)
// ============================================================
@Composable
private fun SpeedToolInspector(
    viewModel: EditorViewModel,
    project: VideoProject,
    selection: SelectionState,
    reverseProgress: Int?
) {
    val clip = resolvePrimaryVisual(project, selection)
    if (clip == null || clip.isImage) return

    CenterSpeedSlider(
        speed = clip.speed,
        onSpeedChange = { viewModel.setClipSpeed(it) }
    )

    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 4.0f, 8.0f)) { spd ->
            FilterChip(selected = clip.speedRampPoints.isEmpty() && abs(clip.speed - spd) < 0.04f, onClick = { viewModel.setClipSpeed(spd) }, label = { Text("${spd}x", fontSize = 11.sp) })
        }
    }

    val ramps = listOf(
        "Ровно" to emptyList(),
        "Монтаж" to listOf(SpeedRampPoint(0f, 2.2f), SpeedRampPoint(0.4f, 0.5f), SpeedRampPoint(0.7f, 0.6f), SpeedRampPoint(1f, 2.0f)),
        "Герой" to listOf(SpeedRampPoint(0f, 1.8f), SpeedRampPoint(0.5f, 0.35f), SpeedRampPoint(1f, 1.8f)),
        "Пуля" to listOf(SpeedRampPoint(0f, 3.0f), SpeedRampPoint(0.25f, 0.4f), SpeedRampPoint(0.75f, 0.4f), SpeedRampPoint(1f, 3.0f)),
        "Ускорение" to listOf(SpeedRampPoint(0f, 0.6f), SpeedRampPoint(0.5f, 1.5f), SpeedRampPoint(1f, 3.2f))
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(ramps) { (name, pts) ->
            FilterChip(selected = (pts.isEmpty() && clip.speedRampPoints.isEmpty()) || (pts.isNotEmpty() && clip.speedRampPoints == pts), onClick = { viewModel.applySpeedRampPreset(pts) }, label = { Text(name, fontSize = 11.sp) })
        }
    }

    Button(
        onClick = { viewModel.reverseSelectedVideoClip() },
        enabled = reverseProgress == null,
        colors = ButtonDefaults.buttonColors(containerColor = if (clip.isReversed) StudioColors.WarningOrange else StudioColors.BgPanel)
    ) {
        Icon(Icons.Default.Replay, null, tint = if (clip.isReversed) Color.Black else Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (clip.isReversed) "Отключить реверс" else "Реверс видео", color = if (clip.isReversed) Color.Black else Color.White, fontSize = 12.sp)
    }

    if (reverseProgress != null) {
        Text("Обработка реверса: $reverseProgress%", color = StudioColors.AccentLightBlue, fontSize = 11.sp)
        LinearProgressIndicator(progress = { reverseProgress / 100f }, modifier = Modifier.fillMaxWidth())
    }
}

private fun speedToNorm(speed: Float): Float {
    val s = speed.coerceIn(0.25f, 8f)
    return if (s <= 1f) {
        // 0.25 -> -1f, 1.0 -> 0f
        (ln(s.toDouble()) / ln(4.0)).toFloat().coerceIn(-1f, 0f)
    } else {
        // 1.0 -> 0f, 8.0 -> +1f
        (ln(s.toDouble()) / ln(8.0)).toFloat().coerceIn(0f, 1f)
    }
}

private fun normToSpeed(norm: Float): Float {
    val t = norm.coerceIn(-1f, 1f)
    if (abs(t) < 0.04f) return 1.0f // Magnetic snap to exact 1.0x at center!
    return if (t < 0f) {
        4.0.pow(t.toDouble()).toFloat().coerceIn(0.25f, 1f)
    } else {
        8.0.pow(t.toDouble()).toFloat().coerceIn(1f, 8f)
    }
}

@Composable
private fun CenterSpeedSlider(
    speed: Float,
    onSpeedChange: (Float) -> Unit
) {
    var showManual by remember { mutableStateOf(false) }
    val norm = speedToNorm(speed) // -1..+1, 0 = 1.0x center
    val activeColor = when {
        norm < -0.02f -> StudioColors.GuideEdgeCyan
        norm > 0.02f -> StudioColors.WarningOrange
        else -> StudioColors.TextPrimary
    }

    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Скорость", color = StudioColors.TextSecondary, fontSize = 11.sp)
            Box(
                modifier = Modifier
                    .clip(StudioShapes.Small)
                    .background(StudioColors.BgGraphite)
                    .border(1.dp, activeColor.copy(alpha = 0.7f), StudioShapes.Small)
                    .clickable { showManual = true }
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(String.format(Locale.US, "%.2fx ✎", speed), color = activeColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val frac = ((offset.x / size.width.toFloat().coerceAtLeast(1f)) * 2f - 1f).coerceIn(-1f, 1f)
                        onSpeedChange(normToSpeed(frac))
                    }
                }
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        val frac = ((change.position.x / size.width.toFloat().coerceAtLeast(1f)) * 2f - 1f).coerceIn(-1f, 1f)
                        onSpeedChange(normToSpeed(frac))
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val trackH = 6.dp.toPx()
                val midY = size.height / 2f
                val midX = size.width / 2f
                val thumbX = ((norm + 1f) * 0.5f) * size.width

                // Background rail
                drawRoundRect(
                    color = StudioColors.BgPanel,
                    topLeft = Offset(0f, midY - trackH / 2f),
                    size = Size(size.width, trackH),
                    cornerRadius = CornerRadius(trackH / 2f)
                )

                // Bidirectional colored fill from exact center (1.0x)
                if (norm < -0.01f) {
                    drawRoundRect(
                        color = StudioColors.GuideEdgeCyan,
                        topLeft = Offset(thumbX, midY - trackH / 2f),
                        size = Size((midX - thumbX).coerceAtLeast(0f), trackH),
                        cornerRadius = CornerRadius(trackH / 2f)
                    )
                } else if (norm > 0.01f) {
                    drawRoundRect(
                        color = StudioColors.WarningOrange,
                        topLeft = Offset(midX, midY - trackH / 2f),
                        size = Size((thumbX - midX).coerceAtLeast(0f), trackH),
                        cornerRadius = CornerRadius(trackH / 2f)
                    )
                }

                // Center 1.0x tick
                drawLine(
                    color = Color.White.copy(alpha = 0.85f),
                    start = Offset(midX, midY - 8.dp.toPx()),
                    end = Offset(midX, midY + 8.dp.toPx()),
                    strokeWidth = 2.dp.toPx()
                )

                // Thumb
                drawCircle(color = Color.White, radius = 9.dp.toPx(), center = Offset(thumbX.coerceIn(9.dp.toPx(), size.width - 9.dp.toPx()), midY))
                drawCircle(color = activeColor, radius = 6.dp.toPx(), center = Offset(thumbX.coerceIn(9.dp.toPx(), size.width - 9.dp.toPx()), midY))
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0.25x", fontSize = 9.sp, color = StudioColors.GuideEdgeCyan)
            Text("1.0x", fontSize = 9.sp, color = StudioColors.TextPrimary, fontWeight = FontWeight.Bold)
            Text("8.0x", fontSize = 9.sp, color = StudioColors.WarningOrange)
        }
    }

    if (showManual) {
        StudioManualNumberDialog(
            title = "Скорость",
            initialValue = speed,
            unitSuffix = "x",
            minAllowed = 0.25f,
            maxAllowed = 8.0f,
            allowDecimals = true,
            onDismiss = { showManual = false },
            onConfirm = { entered -> showManual = false; onSpeedChange(entered) }
        )
    }
}
