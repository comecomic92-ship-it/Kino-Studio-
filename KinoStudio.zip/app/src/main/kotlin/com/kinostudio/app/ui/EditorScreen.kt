package com.kinostudio.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.kinostudio.app.viewmodel.EditorToolTab
import com.kinostudio.app.viewmodel.EditorViewModel
import com.kinostudio.app.viewmodel.TextOverlayMapper
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.core.model.LongTaskState
import com.kinostudio.core.model.MediaKind
import com.layerstudio.kit.StudioColorPickerDialog
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioFontPickerDialog
import com.layerstudio.kit.StudioIcons
import com.layerstudio.kit.StudioShapes
import com.layerstudio.kit.StudioTextOptionsBar
import com.layerstudio.kit.StudioTextStyleInspectorPanel
import com.layerstudio.kit.StudioToolSlotButton

@Composable
fun EditorScreen(viewModel: EditorViewModel) {
    val project = viewModel.activeProject.collectAsState().value ?: return
    val selection by viewModel.selection.collectAsState()
    val activeTool by viewModel.activeTool.collectAsState()
    val transformMode by viewModel.transformMode.collectAsState()
    val editingTextId by viewModel.editingTextOnCanvasId.collectAsState()
    val showTextStyleInspector by viewModel.showTextStyleInspector.collectAsState()
    val playheadMs by viewModel.playheadMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val timelineZoom by viewModel.timelineZoom.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsState()
    val longTask by viewModel.longTask.collectAsState()
    val isPickingBgPoints by viewModel.isPickingBgPoints.collectAsState()
    val bgPreviewMask by viewModel.bgPreviewMask.collectAsState()

    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val focusManager = LocalFocusManager.current
    val screenDensity = LocalDensity.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.screenWidthDp > configuration.screenHeightDp

    val isKeyboardOpen = WindowInsets.ime.getBottom(screenDensity) > 0
    val snackbarHostState = remember { SnackbarHostState() }

    var showExportSheet by remember { mutableStateOf(false) }
    var showReplaceBufferSheet by remember { mutableStateOf(false) }
    var showFontPicker by remember { mutableStateOf(false) }
    var showTextColorPicker by remember { mutableStateOf(false) }
    var showBgColorPicker by remember { mutableStateOf(false) }
    var previewWeight by rememberSaveable { mutableFloatStateOf(0.36f) }

    val activeTextItem = project.textItems.firstOrNull { it.id == selection.primaryId }
        ?: project.textItems.firstOrNull { it.id in selection.textItemIds }
    val isKeyboardTextMode = isKeyboardOpen && (editingTextId != null || (activeTool == EditorToolTab.TEXT && activeTextItem != null))

    BackHandler {
        if (editingTextId != null) {
            focusManager.clearFocus()
            viewModel.setEditingTextOnCanvas(null)
        } else {
            viewModel.closeEditorAndSave()
        }
    }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    val galleryVisualPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) viewModel.importToBuffer(uris) }

    val galleryAudioToBufferPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) viewModel.importToBuffer(uris, MediaKind.AUDIO) }

    val directMusicPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importMusicDirectlyAndAdd(it) } }

    val customFontPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importCustomFontForPrimaryText(it) } }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) viewModel.startVoiceRecording() }

    // Zero double-insets: Scaffold uses empty contentWindowInsets, top bar paints behind status bar cleanly!
    Scaffold(
        containerColor = StudioColors.BgBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Ultra-compact Top Studio Bar flush to top status bar (ZERO ~1cm empty gap!)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(StudioColors.BgGraphite)
                    .statusBarsPadding()
                    .height(36.dp)
                    .border(0.5.dp, StudioColors.BorderSubtle)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = { viewModel.closeEditorAndSave() }, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.ChevronLeft, "Назад", tint = StudioColors.TextPrimary, modifier = Modifier.size(20.dp))
                    }
                    Text(
                        text = project.name,
                        color = StudioColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = project.aspectLabel().substringBefore(" •"),
                        color = StudioColors.AccentLightBlue,
                        fontSize = 9.sp,
                        maxLines = 1
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = { viewModel.undo() }, enabled = canUndo, modifier = Modifier.size(28.dp)) {
                        Icon(StudioIcons.Undo, "Отменить", tint = if (canUndo) StudioColors.TextPrimary else StudioColors.TextSecondary.copy(alpha = 0.35f), modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = { viewModel.redo() }, enabled = canRedo, modifier = Modifier.size(28.dp)) {
                        Icon(StudioIcons.Redo, "Повторить", tint = if (canRedo) StudioColors.TextPrimary else StudioColors.TextSecondary.copy(alpha = 0.35f), modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = { viewModel.saveProjectNow() }, modifier = Modifier.size(28.dp)) {
                        Icon(StudioIcons.Save, "Сохранить", tint = StudioColors.TextSecondary, modifier = Modifier.size(16.dp))
                    }
                    Button(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); showExportSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue),
                        shape = StudioShapes.Small,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(26.dp)
                    ) {
                        Icon(StudioIcons.Export, null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Экспорт", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                    }
                }
            }

            // Compact Long-Running Task Indicator Bar (Model download, AI Background, Reverse)
            longTask?.let { task ->
                LongTaskProgressBanner(
                    task = task,
                    onCancel = { viewModel.cancelLongTask() }
                )
            }

            // =========================================================================
            // MODE A: KEYBOARD TEXT TYPING MODE (Preview full & unchanged + Text Bar above Keyboard)
            // =========================================================================
            if (isKeyboardTextMode && activeTextItem != null) {
                val (cw, ch) = project.resolvedDimensions()
                val ov = TextOverlayMapper.toStudioOverlay(activeTextItem, cw, ch)

                PreviewCanvas(
                    project = project,
                    playheadMs = playheadMs,
                    isPlaying = isPlaying,
                    selection = selection,
                    activeTool = activeTool,
                    transformMode = transformMode,
                    editingTextOnCanvasId = editingTextId,
                    thumbnailCache = viewModel.thumbnailCache,
                    onPlayheadAdvance = { viewModel.setPlayheadMs(it) },
                    onPlaybackEnded = { viewModel.setPlaying(false) },
                    onSelectVisual = { viewModel.selectVisualClip(it, false) },
                    onTapTextOnCanvas = { viewModel.setEditingTextOnCanvas(it) },
                    onUpdateSelectedTransform = { commit, fn -> viewModel.updateSelectedTransforms(commit, fn) },
                    onUpdateTextStyle = { style, commit -> viewModel.updatePrimaryTextStyle(style, commit) },
                    onTranslateTextDoc = { id, dx, dy, commit -> viewModel.translateTextOverlayDoc(id, dx, dy, commit) },
                    onOpenFontPicker = { showFontPicker = true },
                    onOpenTextColorPicker = { showTextColorPicker = true },
                    onDoneEditingText = {
                        focusManager.clearFocus()
                        viewModel.setEditingTextOnCanvas(null)
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f)
                )

                if (showTextStyleInspector) {
                    StudioTextStyleInspectorPanel(
                        style = ov.style,
                        onUpdateStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
                        onOpenFontPicker = { showFontPicker = true },
                        onClosePanel = { viewModel.toggleTextStyleInspector() }
                    )
                }

                // Single horizontal text controls strip sitting flush right above the keyboard
                StudioTextOptionsBar(
                    style = ov.style,
                    onUpdateStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
                    onOpenFontPicker = { showFontPicker = true },
                    onToggleStyleInspector = { viewModel.toggleTextStyleInspector() },
                    onOpenColorPicker = { showTextColorPicker = true },
                    onDone = {
                        focusManager.clearFocus()
                        viewModel.setEditingTextOnCanvas(null)
                    }
                )
            } else if (isLandscape) {
                // =========================================================================
                // MODE B: ADAPTIVE LANDSCAPE NLE LAYOUT (Never breaks on screen rotation!)
                // =========================================================================
                Row(modifier = Modifier.fillMaxWidth().weight(0.55f)) {
                    Column(modifier = Modifier.weight(0.56f).fillMaxHeight()) {
                        PreviewCanvas(
                            project = project, playheadMs = playheadMs, isPlaying = isPlaying, selection = selection,
                            activeTool = activeTool, transformMode = transformMode, editingTextOnCanvasId = editingTextId,
                            isPickingBgPoints = isPickingBgPoints, bgPreviewMask = bgPreviewMask,
                            onAddBgPoint = { nx, ny -> viewModel.addBgPointOnSelectedClip(nx, ny) },
                            thumbnailCache = viewModel.thumbnailCache,
                            onPlayheadAdvance = { viewModel.setPlayheadMs(it) },
                            onPlaybackEnded = { viewModel.setPlaying(false) },
                            onSelectVisual = { viewModel.selectVisualClip(it, false) },
                            onTapTextOnCanvas = { viewModel.setEditingTextOnCanvas(it) },
                            onUpdateSelectedTransform = { c, fn -> viewModel.updateSelectedTransforms(c, fn) },
                            onUpdateTextStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
                            onTranslateTextDoc = { id, dx, dy, c -> viewModel.translateTextOverlayDoc(id, dx, dy, c) },
                            onOpenFontPicker = { showFontPicker = true },
                            onOpenTextColorPicker = { showTextColorPicker = true },
                            onDoneEditingText = { focusManager.clearFocus(); viewModel.setEditingTextOnCanvas(null) },
                            modifier = Modifier.fillMaxWidth().weight(1f)
                        )
                        PlaybackTransportBar(
                            playheadMs = playheadMs,
                            totalDurationMs = project.totalDurationMs,
                            isPlaying = isPlaying,
                            magneticSnap = project.magneticSnapEnabled,
                            onJumpStart = { viewModel.jumpToStart() },
                            onStepPrev = { viewModel.stepPlayheadFrames(-1) },
                            onTogglePlay = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); viewModel.togglePlayPause() },
                            onStepNext = { viewModel.stepPlayheadFrames(1) },
                            onJumpEnd = { viewModel.jumpToEnd() },
                            onToggleSnap = { viewModel.toggleMagneticSnap() },
                            onZoomOut = { viewModel.setTimelineZoom(timelineZoom - 0.35f) },
                            onZoomIn = { viewModel.setTimelineZoom(timelineZoom + 0.35f) }
                        )
                    }
                    Box(modifier = Modifier.width(1.dp).fillMaxHeight().background(StudioColors.BorderSubtle))
                    InspectorPanel(
                        viewModel = viewModel, project = project, activeTool = activeTool, selection = selection,
                        onImportGalleryVisual = { galleryVisualPicker.launch(arrayOf("video/*", "image/*")) },
                        onImportGalleryAudio = { galleryAudioToBufferPicker.launch(arrayOf("audio/*")) },
                        onOpenReplaceBuffer = { showReplaceBufferSheet = true },
                        onPickMusicDirect = { directMusicPicker.launch(arrayOf("audio/*")) },
                        onToggleVoiceRecord = {
                            if (isRecordingVoice) viewModel.stopVoiceRecording()
                            else {
                                val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                if (ok) viewModel.startVoiceRecording() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onOpenFontPicker = { showFontPicker = true },
                        onOpenTextColorPicker = { showTextColorPicker = true },
                        onOpenBgColorPicker = { showBgColorPicker = true },
                        modifier = Modifier.weight(0.44f).fillMaxHeight()
                    )
                }

                MultiTrackTimeline(
                    project = project, playheadMs = playheadMs, zoom = timelineZoom, selection = selection,
                    longTask = longTask, thumbnailCache = viewModel.thumbnailCache,
                    onSeek = { ms -> viewModel.setPlaying(false); viewModel.setPlayheadMs(ms) },
                    onZoomChange = { viewModel.setTimelineZoom(it) },
                    onToggleTrackSelect = { viewModel.toggleSelectTrack(it) },
                    onToggleTrackHidden = { viewModel.toggleTrackHidden(it) },
                    onMoveTrackOrder = { id, d -> viewModel.moveTrackOrder(id, d) },
                    onSelectVisual = { id, add -> viewModel.selectVisualClip(id, add) },
                    onSelectText = { id, add -> viewModel.selectTextItem(id, add) },
                    onSelectAudio = { id, add -> viewModel.selectAudioClip(id, add) },
                    onDragVisual = { id, ms, vd, c -> viewModel.dragVisualClip(id, ms, vd, c) },
                    onDragText = { id, ms, vd, c -> viewModel.dragTextItem(id, ms, vd, c) },
                    onDragAudio = { id, ms, vd, c -> viewModel.dragAudioClip(id, ms, vd, c) },
                    modifier = Modifier.fillMaxWidth().weight(0.45f)
                )

                BottomToolDock(
                    activeTool = activeTool,
                    onSelectTool = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); viewModel.setActiveTool(it) }
                )
            } else {
                // =========================================================================
                // MODE C: PORTRAIT STUDIO LAYOUT (With Resizable Preview Handle Bar!)
                // =========================================================================
                BoxWithConstraints(modifier = Modifier.fillMaxWidth().weight(1f)) {
                    val bodyHeightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
                    val remainingWeight = (1f - previewWeight).coerceAtLeast(0.28f)
                    val timelineWeight = remainingWeight * 0.48f
                    val inspectorWeight = remainingWeight * 0.52f

                    Column(modifier = Modifier.fillMaxSize()) {
                        PreviewCanvas(
                            project = project, playheadMs = playheadMs, isPlaying = isPlaying, selection = selection,
                            activeTool = activeTool, transformMode = transformMode, editingTextOnCanvasId = editingTextId,
                            isPickingBgPoints = isPickingBgPoints, bgPreviewMask = bgPreviewMask,
                            onAddBgPoint = { nx, ny -> viewModel.addBgPointOnSelectedClip(nx, ny) },
                            thumbnailCache = viewModel.thumbnailCache,
                            onPlayheadAdvance = { viewModel.setPlayheadMs(it) },
                            onPlaybackEnded = { viewModel.setPlaying(false) },
                            onSelectVisual = { viewModel.selectVisualClip(it, false) },
                            onTapTextOnCanvas = { viewModel.setEditingTextOnCanvas(it) },
                            onUpdateSelectedTransform = { c, fn -> viewModel.updateSelectedTransforms(c, fn) },
                            onUpdateTextStyle = { s, c -> viewModel.updatePrimaryTextStyle(s, c) },
                            onTranslateTextDoc = { id, dx, dy, c -> viewModel.translateTextOverlayDoc(id, dx, dy, c) },
                            onOpenFontPicker = { showFontPicker = true },
                            onOpenTextColorPicker = { showTextColorPicker = true },
                            onDoneEditingText = { focusManager.clearFocus(); viewModel.setEditingTextOnCanvas(null) },
                            modifier = Modifier.fillMaxWidth().weight(previewWeight.coerceIn(0.20f, 0.62f))
                        )

                        // Resizable Preview Drag Handle (drag up/down to resize preview area!)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(14.dp)
                                .background(StudioColors.BgGraphite)
                                .pointerInput(bodyHeightPx) {
                                    detectVerticalDragGestures { change, dragAmount ->
                                        change.consume()
                                        previewWeight = (previewWeight + dragAmount / bodyHeightPx).coerceIn(0.20f, 0.62f)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(42.dp)
                                    .height(3.5.dp)
                                    .clip(CircleShape)
                                    .background(StudioColors.TextSecondary.copy(alpha = 0.65f))
                            )
                        }

                        // Centered Play + Start / -1f / Play / +1f / End Transport Bar
                        PlaybackTransportBar(
                            playheadMs = playheadMs,
                            totalDurationMs = project.totalDurationMs,
                            isPlaying = isPlaying,
                            magneticSnap = project.magneticSnapEnabled,
                            onJumpStart = { viewModel.jumpToStart() },
                            onStepPrev = { viewModel.stepPlayheadFrames(-1) },
                            onTogglePlay = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); viewModel.togglePlayPause() },
                            onStepNext = { viewModel.stepPlayheadFrames(1) },
                            onJumpEnd = { viewModel.jumpToEnd() },
                            onToggleSnap = { viewModel.toggleMagneticSnap() },
                            onZoomOut = { viewModel.setTimelineZoom(timelineZoom - 0.35f) },
                            onZoomIn = { viewModel.setTimelineZoom(timelineZoom + 0.35f) }
                        )

                        MultiTrackTimeline(
                            project = project, playheadMs = playheadMs, zoom = timelineZoom, selection = selection,
                            longTask = longTask, thumbnailCache = viewModel.thumbnailCache,
                            onSeek = { ms -> viewModel.setPlaying(false); viewModel.setPlayheadMs(ms) },
                            onZoomChange = { viewModel.setTimelineZoom(it) },
                            onToggleTrackSelect = { viewModel.toggleSelectTrack(it) },
                            onToggleTrackHidden = { viewModel.toggleTrackHidden(it) },
                            onMoveTrackOrder = { id, d -> viewModel.moveTrackOrder(id, d) },
                            onSelectVisual = { id, add -> viewModel.selectVisualClip(id, add) },
                            onSelectText = { id, add -> viewModel.selectTextItem(id, add) },
                            onSelectAudio = { id, add -> viewModel.selectAudioClip(id, add) },
                            onDragVisual = { id, ms, vd, c -> viewModel.dragVisualClip(id, ms, vd, c) },
                            onDragText = { id, ms, vd, c -> viewModel.dragTextItem(id, ms, vd, c) },
                            onDragAudio = { id, ms, vd, c -> viewModel.dragAudioClip(id, ms, vd, c) },
                            modifier = Modifier.fillMaxWidth().weight(timelineWeight)
                        )

                        AnimatedContent(
                            targetState = activeTool,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            modifier = Modifier.fillMaxWidth().weight(inspectorWeight),
                            label = "InspectorAnim"
                        ) { currentTab ->
                            InspectorPanel(
                                viewModel = viewModel, project = project, activeTool = currentTab, selection = selection,
                                onImportGalleryVisual = { galleryVisualPicker.launch(arrayOf("video/*", "image/*")) },
                                onImportGalleryAudio = { galleryAudioToBufferPicker.launch(arrayOf("audio/*")) },
                                onOpenReplaceBuffer = { showReplaceBufferSheet = true },
                                onPickMusicDirect = { directMusicPicker.launch(arrayOf("audio/*")) },
                                onToggleVoiceRecord = {
                                    if (isRecordingVoice) viewModel.stopVoiceRecording()
                                    else {
                                        val ok = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                                        if (ok) viewModel.startVoiceRecording() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                },
                                onOpenFontPicker = { showFontPicker = true },
                                onOpenTextColorPicker = { showTextColorPicker = true },
                                onOpenBgColorPicker = { showBgColorPicker = true },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                BottomToolDock(
                    activeTool = activeTool,
                    onSelectTool = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); viewModel.setActiveTool(it) }
                )
            }
        }
    }

    if (showReplaceBufferSheet) {
        MediaBufferSheet(
            bufferItems = project.mediaBuffer,
            replaceMode = true,
            thumbnailCache = viewModel.thumbnailCache,
            onImportGalleryVideoPhoto = { galleryVisualPicker.launch(arrayOf("video/*", "image/*")) },
            onImportGalleryAudio = { galleryAudioToBufferPicker.launch(arrayOf("audio/*")) },
            onSelectBufferItem = { item ->
                viewModel.replaceSelectedVisualWithBuffer(item)
                showReplaceBufferSheet = false
            },
            onDeleteBufferItem = { viewModel.removeFromBuffer(it) },
            onDismiss = { showReplaceBufferSheet = false }
        )
    }

    if (showExportSheet) {
        ExportSheet(viewModel = viewModel, onDismiss = { showExportSheet = false })
    }

    if (showFontPicker && activeTextItem != null) {
        val (cw, ch) = project.resolvedDimensions()
        val ov = TextOverlayMapper.toStudioOverlay(activeTextItem, cw, ch)
        StudioFontPickerDialog(
            selectedFont = ov.style.fontFamily,
            customFontName = ov.style.customFontName,
            previewText = ov.style.text,
            onSelectFont = { font -> viewModel.selectBuiltInFontForPrimaryText(font) },
            onImportCustomFontFile = { customFontPicker.launch(arrayOf("font/*", "application/octet-stream", "*/*")) },
            onClearCustomFont = { viewModel.selectBuiltInFontForPrimaryText(ov.style.fontFamily) },
            onDismiss = { showFontPicker = false }
        )
    }

    val activeVisualClip = project.visualClips.firstOrNull { it.id == selection.primaryId }
        ?: project.visualClips.firstOrNull { it.id in selection.visualClipIds }
    if (showBgColorPicker && activeVisualClip != null) {
        StudioColorPickerDialog(
            initialColor = activeVisualClip.backgroundConfig.solidColorArgb.toInt(),
            onDismiss = { showBgColorPicker = false },
            onConfirm = { picked ->
                viewModel.updateBgConfig(true) { it.copy(mode = BackgroundMode.COLOR, solidColorArgb = picked.toLong() and 0xFFFFFFFFL) }
                showBgColorPicker = false
            }
        )
    }

    if (showTextColorPicker && activeTextItem != null) {
        val (cw, ch) = project.resolvedDimensions()
        val ov = TextOverlayMapper.toStudioOverlay(activeTextItem, cw, ch)
        StudioColorPickerDialog(
            initialColor = ov.style.color,
            onDismiss = { showTextColorPicker = false },
            onConfirm = { picked ->
                viewModel.updatePrimaryTextStyle(ov.style.copy(color = picked), true)
                showTextColorPicker = false
            }
        )
    }
}

@Composable
private fun PlaybackTransportBar(
    playheadMs: Long,
    totalDurationMs: Long,
    isPlaying: Boolean,
    magneticSnap: Boolean,
    onJumpStart: () -> Unit,
    onStepPrev: () -> Unit,
    onTogglePlay: () -> Unit,
    onStepNext: () -> Unit,
    onJumpEnd: () -> Unit,
    onToggleSnap: () -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.BgGraphite)
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        // Left: Compact timecode
        Column(modifier = Modifier.align(Alignment.CenterStart)) {
            Text(formatTimecode(playheadMs), color = StudioColors.TextPrimary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            Text(formatTimecode(totalDurationMs), color = StudioColors.TextSecondary, fontSize = 8.sp)
        }

        // Center: Strictly centered [ |< ] [ < ] [ PLAY ] [ > ] [ >| ]
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(onClick = onJumpStart, modifier = Modifier.size(28.dp)) {
                Icon(StudioIcons.PrevFrame, "В начало", tint = StudioColors.TextPrimary, modifier = Modifier.size(17.dp))
            }
            IconButton(onClick = onStepPrev, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.ChevronLeft, "-1 кадр", tint = StudioColors.TextPrimary, modifier = Modifier.size(18.dp))
            }
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(StudioColors.AccentBlue)
                    .clickable(onClick = onTogglePlay),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (isPlaying) StudioIcons.Pause else StudioIcons.Play, "Play", tint = Color.White, modifier = Modifier.size(20.dp))
            }
            IconButton(onClick = onStepNext, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.ChevronRight, "+1 кадр", tint = StudioColors.TextPrimary, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onJumpEnd, modifier = Modifier.size(28.dp)) {
                Icon(StudioIcons.NextFrame, "В конец", tint = StudioColors.TextPrimary, modifier = Modifier.size(17.dp))
            }
        }

        // Right: Magnet & Zoom
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(StudioShapes.Small)
                    .background(if (magneticSnap) StudioColors.SuccessGreen.copy(alpha = 0.25f) else StudioColors.BgPanel)
                    .border(1.dp, if (magneticSnap) StudioColors.SuccessGreen else StudioColors.BorderSubtle, StudioShapes.Small)
                    .clickable(onClick = onToggleSnap)
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) { Text("M", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = if (magneticSnap) StudioColors.SuccessGreen else StudioColors.TextSecondary) }
            IconButton(onClick = onZoomOut, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.ZoomOut, null, tint = StudioColors.TextSecondary, modifier = Modifier.size(15.dp))
            }
            IconButton(onClick = onZoomIn, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.ZoomIn, null, tint = StudioColors.TextSecondary, modifier = Modifier.size(15.dp))
            }
        }
    }
}

@Composable
private fun LongTaskProgressBanner(
    task: LongTaskState,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.BgPanel)
            .border(0.5.dp, StudioColors.AccentLightBlue.copy(alpha = 0.6f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    color = StudioColors.AccentLightBlue,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "${task.title} — ${task.progressPercent}%${if (task.detail.isNotBlank()) " • ${task.detail}" else ""}",
                    color = StudioColors.TextPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (task.isCancellable) {
                Box(
                    modifier = Modifier
                        .clip(StudioShapes.Small)
                        .background(StudioColors.DangerRed.copy(alpha = 0.22f))
                        .border(1.dp, StudioColors.DangerRed.copy(alpha = 0.7f), StudioShapes.Small)
                        .clickable(onClick = onCancel)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Отмена", color = StudioColors.DangerRed, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        LinearProgressIndicator(
            progress = { (task.progressPercent / 100f).coerceIn(0f, 1f) },
            color = StudioColors.AccentLightBlue,
            trackColor = StudioColors.BgDarkGray,
            modifier = Modifier.fillMaxWidth().height(3.dp)
        )
    }
}

@Composable
private fun BottomToolDock(
    activeTool: EditorToolTab,
    onSelectTool: (EditorToolTab) -> Unit
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .background(StudioColors.BgGraphite)
            .navigationBarsPadding()
            .border(0.5.dp, StudioColors.BorderSubtle)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(EditorToolTab.entries) { tab ->
            val icon = when (tab) {
                EditorToolTab.ADD -> StudioIcons.Add
                EditorToolTab.EDIT -> StudioIcons.SplitClip
                EditorToolTab.TRANSFORM -> StudioIcons.Transform
                EditorToolTab.BACKGROUND -> StudioIcons.SelectObjectAi
                EditorToolTab.AUDIO -> StudioIcons.Audio
                EditorToolTab.TEXT -> StudioIcons.Text
                EditorToolTab.COLOR -> StudioIcons.Adjust
                EditorToolTab.SPEED -> StudioIcons.Speed
            }
            StudioToolSlotButton(
                label = tab.label,
                icon = icon,
                selected = activeTool == tab,
                onClick = { onSelectTool(tab) }
            )
        }
    }
}
