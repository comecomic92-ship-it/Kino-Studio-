package com.kinostudio.app

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kinostudio.app.ui.EditorScreen
import com.kinostudio.app.ui.HomeScreen
import com.kinostudio.app.viewmodel.EditorViewModel
import com.layerstudio.kit.LayerStudioTheme
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.TextInputFocusTracker

class MainActivity : ComponentActivity() {
    private val appInstance: KinoStudioApplication get() = application as KinoStudioApplication

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        setContent {
            LayerStudioTheme {
                val vm: EditorViewModel = viewModel()
                val activeProject by vm.activeProject.collectAsState()
                val highRefreshPref by vm.highRefreshRateEnabled.collectAsState()
                val thermalState by appInstance.hardwareOptimizer.thermalState.collectAsState()

                LaunchedEffect(highRefreshPref, thermalState) {
                    val activeHz = appInstance.hardwareOptimizer.applyPreferredRefreshRate(this@MainActivity, highRefreshPref)
                    vm.refreshHardwareInfo(this@MainActivity, activeHz)
                }

                Surface(modifier = Modifier.fillMaxSize(), color = StudioColors.BgBlack) {
                    Box(modifier = Modifier.fillMaxSize().imePadding()) {
                        Crossfade(targetState = activeProject != null, animationSpec = tween(180), label = "ScreenTransition") { inEditor ->
                            if (inEditor && activeProject != null) EditorScreen(viewModel = vm) else HomeScreen(viewModel = vm)
                        }
                    }
                }
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (TextInputFocusTracker.isAnyTextFieldFocused) return super.dispatchKeyEvent(event)
        return super.dispatchKeyEvent(event)
    }
}
