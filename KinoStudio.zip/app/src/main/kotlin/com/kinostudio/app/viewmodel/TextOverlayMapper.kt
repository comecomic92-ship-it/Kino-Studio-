package com.kinostudio.app.viewmodel

import android.graphics.Color as AndroidColor
import com.kinostudio.core.model.TextTrackItem
import com.layerstudio.kit.StudioTextEngine
import com.layerstudio.kit.StudioTextOverlay
import com.layerstudio.kit.TextAlignment
import com.layerstudio.kit.TextVerticalAlignment
import org.json.JSONObject

object TextOverlayMapper {
    fun toStudioOverlay(item: TextTrackItem, canvasWidth: Int, canvasHeight: Int): StudioTextOverlay {
        val parsed = if (item.studioOverlayJson.isNotBlank()) {
            runCatching { StudioTextOverlay.fromJson(JSONObject(item.studioOverlayJson)) }.getOrNull()
        } else null

        if (parsed != null) {
            return parsed.copy(
                id = item.id,
                startTimeMs = item.timelineStartMs,
                endTimeMs = item.timelineEndMs,
                isVisible = !item.isHidden,
                isLocked = item.isLocked
            )
        }

        val boxW = (canvasWidth * 0.72f).coerceIn(220f, 1400f)
        val boxH = (canvasHeight * 0.14f).coerceIn(90f, 420f)
        val left = (canvasWidth - boxW) * 0.5f
        val top = if (item.isSubtitle) canvasHeight * 0.74f else (canvasHeight - boxH) * 0.45f
        val created = StudioTextEngine.createTextOverlayAt(
            leftDoc = left,
            topDoc = top,
            boxWidth = boxW,
            boxHeight = boxH,
            startTimeMs = item.timelineStartMs,
            endTimeMs = item.timelineEndMs,
            color = AndroidColor.WHITE,
            fontSize = if (item.isSubtitle) (canvasWidth * 0.048f).coerceIn(26f, 72f) else (canvasWidth * 0.07f).coerceIn(36f, 110f)
        )
        return created.copy(
            id = item.id,
            name = item.displayName,
            style = created.style.copy(
                text = if (item.isSubtitle) "Субтитры" else "Новый текст",
                alignment = TextAlignment.CENTER,
                verticalAlignment = TextVerticalAlignment.CENTER,
                strokeWidth = if (item.isSubtitle) 3f else 0f
            )
        )
    }

    fun applyStudioOverlay(item: TextTrackItem, overlay: StudioTextOverlay): TextTrackItem = item.copy(
        displayName = overlay.style.text.take(20).ifBlank { if (item.isSubtitle) "Субтитры" else "Текст" },
        studioOverlayJson = overlay.toJson().toString(),
        transform = item.transform.copy(
            scaleX = overlay.scaleX,
            scaleY = overlay.scaleY,
            rotationDeg = overlay.rotation,
            flipH = overlay.flipHorizontal,
            flipV = overlay.flipVertical,
            opacity = overlay.opacity
        )
    )
}
