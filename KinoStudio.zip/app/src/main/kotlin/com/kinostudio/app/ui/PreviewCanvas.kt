package com.kinostudio.app.ui

import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RenderEffect
import android.net.Uri
import android.os.Build
import android.view.TextureView
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.kinostudio.app.viewmodel.EditorToolTab
import com.kinostudio.app.viewmodel.PreviewAudioMixer
import com.kinostudio.app.viewmodel.SelectionState
import com.kinostudio.app.viewmodel.TextOverlayMapper
import com.kinostudio.app.viewmodel.TransformMode
import com.kinostudio.core.database.ThumbnailCache
import com.kinostudio.core.model.ClipEdgeEffect
import com.kinostudio.core.model.ColorGradingConfig
import com.kinostudio.core.model.TrackKind
import com.kinostudio.core.model.TransformState
import com.kinostudio.core.model.TransitionType
import com.kinostudio.core.model.VideoProject
import com.kinostudio.core.model.VisualClipItem
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.feature.engine.AiBackgroundProcessor
import com.kinostudio.feature.engine.ColorMatrixUtil
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioOnCanvasTextEditor
import com.layerstudio.kit.StudioShapes
import com.layerstudio.kit.StudioTextEngine
import com.layerstudio.kit.TextStyleConfig
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private data class LiveEdgeAnimation(
    val alphaMul: Float = 1f,
    val zoomMul: Float = 1f,
    val slideXFrac: Float = 0f,
    val flashAlpha: Float = 0f
)

private fun evaluateLiveClipTransitions(clip: VisualClipItem, playheadMs: Long): LiveEdgeAnimation {
    val localMs = (playheadMs - clip.timelineStartMs).coerceAtLeast(0L)
    val remMs = (clip.timelineEndMs - playheadMs).coerceAtLeast(0L)
    var alphaMul = 1f
    var zoomMul = 1f
    var slideX = 0f
    var flash = 0f

    if (clip.transitionIn != TransitionType.NONE && clip.transitionDurationMs > 0L && localMs < clip.transitionDurationMs) {
        val t = (localMs.toFloat() / clip.transitionDurationMs.toFloat()).coerceIn(0f, 1f)
        when (clip.transitionIn) {
            TransitionType.NONE -> Unit
            TransitionType.FADE_BLACK, TransitionType.CROSS_DISSOLVE -> alphaMul *= t
            TransitionType.SLIDE_LEFT -> slideX += (1f - t)
            TransitionType.SLIDE_RIGHT -> slideX -= (1f - t)
            TransitionType.ZOOM_IN -> { zoomMul *= (1.35f - 0.35f * t); alphaMul *= t }
            TransitionType.FLASH -> flash += (1f - t)
        }
    }

    if (clip.edgeEffectIn != ClipEdgeEffect.NONE && clip.edgeEffectInMs > 0L && localMs < clip.edgeEffectInMs) {
        val t = (localMs.toFloat() / clip.edgeEffectInMs.toFloat()).coerceIn(0f, 1f)
        when (clip.edgeEffectIn) {
            ClipEdgeEffect.NONE -> Unit
            ClipEdgeEffect.FADE -> alphaMul *= t
            ClipEdgeEffect.ZOOM -> { zoomMul *= (1.30f - 0.30f * t); alphaMul *= t }
            ClipEdgeEffect.SLIDE -> slideX += (1f - t)
            ClipEdgeEffect.FLASH -> flash += (1f - t)
        }
    }

    if (clip.edgeEffectOut != ClipEdgeEffect.NONE && clip.edgeEffectOutMs > 0L && remMs < clip.edgeEffectOutMs) {
        val t = (remMs.toFloat() / clip.edgeEffectOutMs.toFloat()).coerceIn(0f, 1f)
        when (clip.edgeEffectOut) {
            ClipEdgeEffect.NONE -> Unit
            ClipEdgeEffect.FADE -> alphaMul *= t
            ClipEdgeEffect.ZOOM -> { zoomMul *= (1.30f - 0.30f * t); alphaMul *= t }
            ClipEdgeEffect.SLIDE -> slideX -= (1f - t)
            ClipEdgeEffect.FLASH -> flash += (1f - t)
        }
    }

    return LiveEdgeAnimation(alphaMul.coerceIn(0f, 1f), zoomMul, slideX, flash.coerceIn(0f, 1f))
}

@OptIn(UnstableApi::class)
@Composable
fun PreviewCanvas(
    project: VideoProject,
    playheadMs: Long,
    isPlaying: Boolean,
    selection: SelectionState,
    activeTool: EditorToolTab,
    transformMode: TransformMode,
    editingTextOnCanvasId: String?,
    isPickingBgPoints: Boolean = false,
    bgPreviewMask: Bitmap? = null,
    onAddBgPoint: (Float, Float) -> Unit = { _, _ -> },
    thumbnailCache: ThumbnailCache,
    onPlayheadAdvance: (Long) -> Unit,
    onPlaybackEnded: () -> Unit,
    onSelectVisual: (String) -> Unit,
    onTapTextOnCanvas: (String) -> Unit,
    onUpdateSelectedTransform: (Boolean, (TransformState) -> TransformState) -> Unit,
    onUpdateTextStyle: (TextStyleConfig, Boolean) -> Unit,
    onTranslateTextDoc: (String, Float, Float, Boolean) -> Unit,
    onOpenFontPicker: () -> Unit,
    onOpenTextColorPicker: () -> Unit,
    onDoneEditingText: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val localDensity = LocalDensity.current
    val (projW, projH) = project.resolvedDimensions()
    val aspect = (projW.toFloat() / projH.toFloat()).coerceIn(0.35f, 2.8f)

    val visibleVisualTracks = remember(project.tracks) { project.tracks.filter { it.kind == TrackKind.VISUAL && !it.isHidden } }
    val visualTrackOrder = remember(visibleVisualTracks) { visibleVisualTracks.mapIndexed { idx, t -> t.id to idx }.toMap() }
    val activeVisualClips = remember(project.visualClips, visualTrackOrder, playheadMs) {
        project.visualClips
            .filter { !it.isHidden && it.trackId in visualTrackOrder && playheadMs in it.timelineStartMs..it.timelineEndMs }
            .sortedBy { visualTrackOrder[it.trackId] ?: 0 }
    }

    val primaryVideoClip = activeVisualClips.firstOrNull { !it.isImage && !it.hasTransparentVideoMask }
    val exoPlayer = remember(context) { ExoPlayer.Builder(context).build().apply { repeatMode = Player.REPEAT_MODE_OFF } }
    val audioMixer = remember(context) { PreviewAudioMixer(context) }
    var textureViewRef by remember { mutableStateOf<TextureView?>(null) }

    DisposableEffect(exoPlayer, audioMixer) {
        onDispose { audioMixer.releaseAll(); exoPlayer.release() }
    }

    var loadedClipSignature by remember { mutableStateOf("") }
    val targetClipSignature = primaryVideoClip?.let { "${it.id}:${it.activeUri}:${it.trimStartMs}:${it.trimEndMs}" } ?: ""

    LaunchedEffect(targetClipSignature) {
        if (targetClipSignature == loadedClipSignature) return@LaunchedEffect
        loadedClipSignature = targetClipSignature
        val clip = primaryVideoClip
        if (clip == null) {
            exoPlayer.stop(); exoPlayer.clearMediaItems()
        } else {
            val item = MediaItem.Builder()
                .setMediaId(clip.id)
                .setUri(Uri.parse(clip.activeUri))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.trimStartMs.coerceAtLeast(0L))
                        .setEndPositionMs(clip.trimEndMs.coerceAtLeast(clip.trimStartMs + 100L))
                        .build()
                )
                .build()
            exoPlayer.setMediaItem(item); exoPlayer.prepare()
            exoPlayer.seekTo(((playheadMs - clip.timelineStartMs).coerceAtLeast(0L) * clip.speed).toLong().coerceAtLeast(0L))
        }
    }

    LaunchedEffect(isPlaying, primaryVideoClip?.speed, primaryVideoClip?.isAudioMuted, primaryVideoClip?.volume) {
        val clip = primaryVideoClip
        if (clip != null) {
            exoPlayer.setPlaybackSpeed(clip.speed.coerceIn(0.25f, 8f))
            exoPlayer.volume = if (clip.isAudioMuted || clip.isReversed) 0f else clip.volume.coerceIn(0f, 1f)
            exoPlayer.playWhenReady = isPlaying
        } else exoPlayer.playWhenReady = false
        if (!isPlaying) audioMixer.pauseAll()
    }

    LaunchedEffect(playheadMs, isPlaying, targetClipSignature) {
        val clip = primaryVideoClip
        if (!isPlaying && clip != null) {
            val localMs = ((playheadMs - clip.timelineStartMs).coerceAtLeast(0L) * clip.speed).toLong()
            if (abs(exoPlayer.currentPosition - localMs) > 28L) exoPlayer.seekTo(localMs.coerceAtLeast(0L))
        }
        audioMixer.syncTracks(project.tracks, project.audioClips, playheadMs, isPlaying)
    }

    val currentPlayhead by rememberUpdatedState(playheadMs)
    val currentTotalDur by rememberUpdatedState(project.totalDurationMs)
    val currentProject by rememberUpdatedState(project)

    // Frame tick for perspective video bitmap refresh when perspective is active
    var perspectiveTick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(isPlaying, primaryVideoClip?.transform?.hasPerspective()) {
        if (primaryVideoClip?.transform?.hasPerspective() != true) return@LaunchedEffect
        while (isActive) {
            perspectiveTick++
            delay(if (isPlaying) 33L else 120L)
        }
    }

    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        var lastNs = System.nanoTime()
        while (isActive && isPlaying) {
            val now = System.nanoTime()
            val dtMs = ((now - lastNs) / 1_000_000L).coerceIn(1L, 60L)
            lastNs = now
            val nextMs = currentPlayhead + dtMs
            if (currentTotalDur <= 0L || nextMs >= currentTotalDur) {
                onPlayheadAdvance(currentTotalDur); onPlaybackEnded(); break
            } else {
                onPlayheadAdvance(nextMs)
                audioMixer.syncTracks(currentProject.tracks, currentProject.audioClips, nextMs, true)
            }
            delay(16L)
        }
    }

    val visibleTextTrackIds = remember(project.tracks) { project.tracks.filter { it.kind == TrackKind.TEXT && !it.isHidden }.map { it.id }.toSet() }
    val activeTextOverlays = remember(project.textItems, visibleTextTrackIds, playheadMs, projW, projH) {
        project.textItems.filter { !it.isHidden && it.trackId in visibleTextTrackIds && playheadMs in it.timelineStartMs..it.timelineEndMs }
            .map { TextOverlayMapper.toStudioOverlay(it, projW, projH) }
    }

    Box(modifier = modifier.fillMaxSize().background(StudioColors.BgBlack).padding(horizontal = 6.dp, vertical = 2.dp), contentAlignment = Alignment.Center) {
        BoxWithConstraints(modifier = Modifier.aspectRatio(aspect).clip(StudioShapes.Small).background(Color.Black).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Small).clipToBounds()) {
            val canvasW = constraints.maxWidth.toFloat().coerceAtLeast(1f)
            val canvasH = constraints.maxHeight.toFloat().coerceAtLeast(1f)
            val totalScale = canvasW / projW.toFloat().coerceAtLeast(1f)

            if (activeVisualClips.isEmpty() && activeTextOverlays.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Нажмите «+ Добавить» чтобы добавить медиа", color = StudioColors.TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(14.dp))
                }
            }

            for (clip in activeVisualClips) {
                val resolvedColor = ColorMatrixUtil.resolvePreset(ColorMatrixUtil.merge(project.globalColorGrading, clip.colorGrading))
                val tf = clip.transform
                val edgeAnim = evaluateLiveClipTransitions(clip, playheadMs)

                Box(
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        translationX = (tf.offsetX + edgeAnim.slideXFrac) * canvasW
                        translationY = tf.offsetY * canvasH
                        scaleX = tf.scaleX.coerceIn(0.1f, 5f) * edgeAnim.zoomMul * if (tf.flipH) -1f else 1f
                        scaleY = tf.scaleY.coerceIn(0.1f, 5f) * edgeAnim.zoomMul * if (tf.flipV) -1f else 1f
                        rotationZ = tf.rotationDeg
                        alpha = (tf.opacity * edgeAnim.alphaMul).coerceIn(0f, 1f)
                    },
                    contentAlignment = Alignment.Center
                ) {
                    if (!clip.isImage && clip.id == primaryVideoClip?.id && !clip.hasTransparentVideoMask) {
                        val usePolyOverlay = tf.hasPerspective()
                        AndroidView(
                            factory = { ctx ->
                                TextureView(ctx).apply {
                                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                                    exoPlayer.setVideoTextureView(this)
                                    textureViewRef = this
                                }
                            },
                            update = { tv ->
                                textureViewRef = tv
                                tv.alpha = if (usePolyOverlay) 0.005f else 1f
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    if (resolvedColor.isIdentity() || usePolyOverlay) tv.setRenderEffect(null)
                                    else tv.setRenderEffect(RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(ColorMatrixUtil.buildColorMatrix(resolvedColor))))
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )

                        // True pixel-exact 4-corner homography perspective on live video!
                        if (usePolyOverlay) {
                            val liveBmp = remember(perspectiveTick, playheadMs, tf, textureViewRef) {
                                textureViewRef?.let { tv ->
                                    if (tv.isAvailable && tv.width > 0 && tv.height > 0) {
                                        runCatching { tv.getBitmap(tv.width.coerceAtMost(720), tv.height.coerceAtMost(720)) }.getOrNull()
                                    } else null
                                }
                            }
                            if (liveBmp != null) {
                                PerspectiveBitmapCanvas(
                                    bitmap = liveBmp,
                                    transform = tf,
                                    resolvedColor = resolvedColor,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    } else {
                        var bmp by remember(clip.id, clip.activeUri, clip.bgMaskUri) { mutableStateOf<Bitmap?>(null) }
                        val frameBucket = if (clip.isImage) 0L else ((playheadMs - clip.timelineStartMs) / 80L)
                        LaunchedEffect(clip.id, clip.activeUri, clip.bgMaskUri, frameBucket) {
                            bmp = if (clip.isImage) {
                                thumbnailCache.getImageBitmap(clip.activeUri, 1280)
                            } else {
                                val localMs = (playheadMs - clip.timelineStartMs).coerceAtLeast(0L)
                                val tMs = clip.trimStartMs + (localMs * clip.speed).toLong()
                                val rgb = thumbnailCache.getFilmstripFrames(clip.activeUri, tMs, tMs + 100L, 1, 640, 360).firstOrNull()
                                val maskUri = clip.bgMaskUri
                                if (rgb != null && clip.hasTransparentVideoMask && !maskUri.isNullOrBlank()) {
                                    val maskMs = (localMs * clip.speed).toLong()
                                    val msk = thumbnailCache.getFilmstripFrames(maskUri, maskMs, maskMs + 100L, 1, 640, 360).firstOrNull()
                                    if (msk != null) AiBackgroundProcessor.applyGrayscaleMaskToBitmap(rgb, msk) else rgb
                                } else {
                                    rgb
                                }
                            }
                        }
                        bmp?.let { bitmap ->
                            if (tf.hasPerspective()) {
                                PerspectiveBitmapCanvas(
                                    bitmap = bitmap,
                                    transform = tf,
                                    resolvedColor = resolvedColor,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                val cf = remember(resolvedColor) {
                                    if (resolvedColor.isIdentity()) null else ColorFilter.colorMatrix(ColorMatrix(ColorMatrixUtil.buildColorMatrix(resolvedColor).array))
                                }
                                Image(bitmap = bitmap.asImageBitmap(), contentDescription = clip.displayName, contentScale = ContentScale.Fit, colorFilter = cf, modifier = Modifier.fillMaxSize())
                            }
                        }
                    }

                    if (resolvedColor.vignette > 0.01f) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawRect(brush = Brush.radialGradient(listOf(Color.Transparent, Color.Black.copy(alpha = (resolvedColor.vignette * 0.85f).coerceIn(0f, 0.9f))), center = center, radius = size.maxDimension * 0.65f))
                        }
                    }
                    if (edgeAnim.flashAlpha > 0.01f) {
                        Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = edgeAnim.flashAlpha)))
                    }
                }
            }

            // Layer Studio Text Overlays
            for (overlay in activeTextOverlays) {
                val bmp = remember(overlay.id, overlay.style, projW) { StudioTextEngine.getOrRenderCachedBitmap(overlay.id, overlay.style, projW) }
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = overlay.name,
                    contentScale = ContentScale.FillBounds,
                    modifier = Modifier
                        .offset { IntOffset((overlay.offsetX * totalScale).roundToInt(), (overlay.offsetY * totalScale).roundToInt()) }
                        .size(width = with(localDensity) { (bmp.width * totalScale).toDp() }, height = with(localDensity) { (bmp.height * totalScale).toDp() })
                        .graphicsLayer {
                            scaleX = overlay.scaleX * if (overlay.flipHorizontal) -1f else 1f
                            scaleY = overlay.scaleY * if (overlay.flipVertical) -1f else 1f
                            rotationZ = overlay.rotation
                            alpha = overlay.opacity.coerceIn(0f, 1f)
                        }
                )
            }

            val selectedVisual = activeVisualClips.lastOrNull { it.id in selection.visualClipIds }
            val currentSelectedVisual by rememberUpdatedState(selectedVisual)
            val currentActiveTextOverlays by rememberUpdatedState(activeTextOverlays)

            // Live AI Mask Highlight + Green/Red Object Selection Points Overlay
            if (activeTool == EditorToolTab.BACKGROUND && isPickingBgPoints && selectedVisual != null && editingTextOnCanvasId == null) {
                val tf = selectedVisual.transform
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            translationX = tf.offsetX * canvasW
                            translationY = tf.offsetY * canvasH
                            scaleX = tf.scaleX.coerceIn(0.1f, 5f) * if (tf.flipH) -1f else 1f
                            scaleY = tf.scaleY.coerceIn(0.1f, 5f) * if (tf.flipV) -1f else 1f
                            rotationZ = tf.rotationDeg
                        }
                ) {
                    if (bgPreviewMask != null && !bgPreviewMask.isRecycled) {
                        Image(
                            bitmap = bgPreviewMask.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        selectedVisual.backgroundConfig.points.forEach { pt ->
                            val px = pt.x * size.width
                            val py = pt.y * size.height
                            val col = if (pt.isPositive) Color(0xFF22C55E) else Color(0xFFEF4444)
                            drawCircle(Color.White, radius = 10.dp.toPx(), center = Offset(px, py))
                            drawCircle(col, radius = 7.dp.toPx(), center = Offset(px, py))
                        }
                    }
                }
            }

            if (editingTextOnCanvasId == null) {
                val currentPickingBg by rememberUpdatedState(activeTool == EditorToolTab.BACKGROUND && isPickingBgPoints)
                Box(
                    modifier = Modifier.fillMaxSize()
                        .pointerInput(projW, canvasW, canvasH) {
                            detectTapGestures { tap ->
                                if (currentPickingBg) {
                                    val target = currentSelectedVisual
                                    if (target != null) {
                                        val normPt = screenPointToClipNormalized(tap, target.transform, canvasW, canvasH)
                                        if (normPt != null) {
                                            onAddBgPoint(normPt.x, normPt.y)
                                            return@detectTapGestures
                                        }
                                    }
                                }
                                val hitText = StudioTextEngine.hitTestTextOverlays(currentActiveTextOverlays, tap.x / totalScale, tap.y / totalScale, projW, playheadMs)
                                if (hitText != null) { onTapTextOnCanvas(hitText.id); return@detectTapGestures }
                                activeVisualClips.asReversed().firstOrNull { isPointInsideVisualClip(tap, it.transform, canvasW, canvasH) }?.let { onSelectVisual(it.id) }
                            }
                        }
                        .pointerInput(selectedVisual?.id, canvasW, canvasH) {
                            var dragAllowed = false
                            detectDragGestures(
                                onDragStart = { startOffset ->
                                    val t = currentSelectedVisual
                                    dragAllowed = !currentPickingBg && t != null && !t.isLocked && isPointInsideVisualClip(startOffset, t.transform, canvasW, canvasH)
                                },
                                onDragEnd = { if (dragAllowed) onUpdateSelectedTransform(true) { it }; dragAllowed = false },
                                onDragCancel = { dragAllowed = false }
                            ) { change, dragAmount ->
                                if (dragAllowed) {
                                    change.consume()
                                    onUpdateSelectedTransform(false) { tf ->
                                        tf.copy(offsetX = (tf.offsetX + dragAmount.x / canvasW).coerceIn(-1.2f, 1.2f), offsetY = (tf.offsetY + dragAmount.y / canvasH).coerceIn(-1.2f, 1.2f))
                                    }
                                }
                            }
                        }
                )
            }

            if (activeTool == EditorToolTab.TRANSFORM && selectedVisual != null && editingTextOnCanvasId == null) {
                TransformCanvasHandles(selectedVisual.transform, transformMode, canvasW, canvasH, onUpdateSelectedTransform)
            }

            val editingOverlay = editingTextOnCanvasId?.let { id -> activeTextOverlays.firstOrNull { it.id == id } }
            if (editingOverlay != null) {
                StudioOnCanvasTextEditor(
                    item = editingOverlay,
                    canvasWidth = projW,
                    originX = 0f,
                    originY = 0f,
                    totalScale = totalScale,
                    viewportWidthPx = canvasW,
                    viewportHeightPx = canvasH,
                    onUpdateStyle = onUpdateTextStyle,
                    onTranslate = { dxDoc, dyDoc, commit -> onTranslateTextDoc(editingOverlay.id, dxDoc, dyDoc, commit) },
                    onOpenFontPicker = onOpenFontPicker,
                    onOpenColorPicker = onOpenTextColorPicker,
                    onDone = onDoneEditingText,
                    showFloatingToolbar = false
                )
            }
        }
    }
}

@Composable
private fun PerspectiveBitmapCanvas(
    bitmap: Bitmap,
    transform: TransformState,
    resolvedColor: ColorGradingConfig,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (bitmap.isRecycled || size.width <= 1f || size.height <= 1f) return@Canvas
        val bw = bitmap.width.toFloat().coerceAtLeast(1f)
        val bh = bitmap.height.toFloat().coerceAtLeast(1f)
        val fit = minOf(size.width / bw, size.height / bh)
        val dw = bw * fit
        val dh = bh * fit
        val left = (size.width - dw) * 0.5f
        val top = (size.height - dh) * 0.5f

        val src = floatArrayOf(0f, 0f, bw, 0f, 0f, bh, bw, bh)
        val dst = floatArrayOf(
            left + transform.tlX.coerceIn(-0.38f, 0.38f) * dw, top + transform.tlY.coerceIn(-0.38f, 0.38f) * dh,
            left + dw + transform.trX.coerceIn(-0.38f, 0.38f) * dw, top + transform.trY.coerceIn(-0.38f, 0.38f) * dh,
            left + transform.blX.coerceIn(-0.38f, 0.38f) * dw, top + dh + transform.blY.coerceIn(-0.38f, 0.38f) * dh,
            left + dw + transform.brX.coerceIn(-0.38f, 0.38f) * dw, top + dh + transform.brY.coerceIn(-0.38f, 0.38f) * dh
        )
        val matrix = Matrix()
        if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) {
            matrix.setScale(fit, fit)
            matrix.postTranslate(left, top)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            if (!resolvedColor.isIdentity()) {
                colorFilter = ColorMatrixColorFilter(ColorMatrixUtil.buildColorMatrix(resolvedColor))
            }
        }
        drawIntoCanvas { canvas ->
            canvas.nativeCanvas.drawBitmap(bitmap, matrix, paint)
        }
    }
}

private fun isPointInsideVisualClip(pt: Offset, tf: TransformState, canvasW: Float, canvasH: Float): Boolean {
    return screenPointToClipNormalized(pt, tf, canvasW, canvasH) != null
}

private fun screenPointToClipNormalized(pt: Offset, tf: TransformState, canvasW: Float, canvasH: Float): Offset? {
    val dx = pt.x - canvasW * (0.5f + tf.offsetX)
    val dy = pt.y - canvasH * (0.5f + tf.offsetY)
    val rad = Math.toRadians(-tf.rotationDeg.toDouble())
    val lx = (dx * cos(rad) - dy * sin(rad)).toFloat()
    val ly = (dx * sin(rad) + dy * cos(rad)).toFloat()
    val hw = canvasW * 0.5f * abs(tf.scaleX).coerceAtLeast(0.1f)
    val hh = canvasH * 0.5f * abs(tf.scaleY).coerceAtLeast(0.1f)
    if (abs(lx) > hw || abs(ly) > hh) return null
    var nx = (lx / (hw * 2f)) + 0.5f
    var ny = (ly / (hh * 2f)) + 0.5f
    if (tf.flipH) nx = 1f - nx
    if (tf.flipV) ny = 1f - ny
    return Offset(nx.coerceIn(0f, 1f), ny.coerceIn(0f, 1f))
}

@Composable
private fun TransformCanvasHandles(
    transform: TransformState,
    mode: TransformMode,
    canvasW: Float,
    canvasH: Float,
    onUpdateTransform: (Boolean, (TransformState) -> TransformState) -> Unit
) {
    val handleDensity = LocalDensity.current
    val currentTf by rememberUpdatedState(transform)
    val cx = canvasW * (0.5f + transform.offsetX)
    val cy = canvasH * (0.5f + transform.offsetY)
    val hw = canvasW * 0.5f * abs(transform.scaleX).coerceIn(0.12f, 2.2f)
    val hh = canvasH * 0.5f * abs(transform.scaleY).coerceIn(0.12f, 2.2f)
    val rad = Math.toRadians(transform.rotationDeg.toDouble())
    val cosR = cos(rad).toFloat(); val sinR = sin(rad).toFloat()

    fun localToScreen(lx: Float, ly: Float) = Offset(cx + lx * cosR - ly * sinR, cy + lx * sinR + ly * cosR)
    fun screenDeltaToLocal(dx: Float, dy: Float): Offset {
        val invRad = Math.toRadians(-currentTf.rotationDeg.toDouble())
        val c = cos(invRad).toFloat(); val s = sin(invRad).toFloat()
        return Offset(dx * c - dy * s, dx * s + dy * c)
    }

    val tl = if (mode == TransformMode.PERSPECTIVE) localToScreen(-hw + transform.tlX * hw * 2f, -hh + transform.tlY * hh * 2f) else localToScreen(-hw, -hh)
    val tr = if (mode == TransformMode.PERSPECTIVE) localToScreen(hw + transform.trX * hw * 2f, -hh + transform.trY * hh * 2f) else localToScreen(hw, -hh)
    val br = if (mode == TransformMode.PERSPECTIVE) localToScreen(hw + transform.brX * hw * 2f, hh + transform.brY * hh * 2f) else localToScreen(hw, hh)
    val bl = if (mode == TransformMode.PERSPECTIVE) localToScreen(-hw + transform.blX * hw * 2f, hh + transform.blY * hh * 2f) else localToScreen(-hw, hh)
    val rotHandle = localToScreen(0f, -hh - with(handleDensity) { 24.dp.toPx() })
    val rightEdge = localToScreen(hw, 0f)
    val bottomEdge = localToScreen(0f, hh)
    val frameColor = if (mode == TransformMode.PERSPECTIVE) StudioColors.WarningOrange else StudioColors.GuideEdgeCyan

    Canvas(modifier = Modifier.fillMaxSize()) {
        val path = Path().apply { moveTo(tl.x, tl.y); lineTo(tr.x, tr.y); lineTo(br.x, br.y); lineTo(bl.x, bl.y); close() }
        drawPath(path, color = frameColor, style = Stroke(width = 3f))
        if (mode == TransformMode.FREE) drawLine(frameColor, localToScreen(0f, -hh), rotHandle, strokeWidth = 2.5f)
    }

    val handleSizeDp = 22.dp
    val halfPx = with(handleDensity) { (handleSizeDp / 2).toPx() }

    if (mode == TransformMode.FREE) {
        listOf("tl" to (tl to (-1f to -1f)), "tr" to (tr to (1f to -1f)), "br" to (br to (1f to 1f)), "bl" to (bl to (-1f to 1f))).forEach { (key, data) ->
            val (pos, signs) = data
            Box(
                modifier = Modifier.offset { IntOffset((pos.x - halfPx).roundToInt(), (pos.y - halfPx).roundToInt()) }
                    .size(handleSizeDp).clip(StudioShapes.Micro).background(StudioColors.AccentBlue).border(1.5.dp, Color.White, StudioShapes.Micro)
                    .pointerInput(key, canvasW, canvasH) {
                        detectDragGestures(onDragEnd = { onUpdateTransform(true) { it } }) { change, drag ->
                            change.consume()
                            val local = screenDeltaToLocal(drag.x, drag.y)
                            val delta = ((local.x * signs.first) / canvasW + (local.y * signs.second) / canvasH) * 1.3f
                            onUpdateTransform(false) { tf -> tf.copy(scaleX = (tf.scaleX + delta).coerceIn(0.15f, 4.5f), scaleY = (tf.scaleY + delta).coerceIn(0.15f, 4.5f)) }
                        }
                    }
            )
        }
        Box(
            modifier = Modifier.offset { IntOffset((rightEdge.x - halfPx).roundToInt(), (rightEdge.y - halfPx).roundToInt()) }
                .size(handleSizeDp).clip(CircleShape).background(StudioColors.GuideEdgeCyan).border(1.5.dp, Color.White, CircleShape)
                .pointerInput("edgeW", canvasW) {
                    detectDragGestures(onDragEnd = { onUpdateTransform(true) { it } }) { change, drag ->
                        change.consume()
                        val local = screenDeltaToLocal(drag.x, drag.y)
                        onUpdateTransform(false) { tf -> tf.copy(scaleX = (tf.scaleX + (local.x / canvasW) * 2f).coerceIn(0.15f, 4.5f)) }
                    }
                }
        )
        Box(
            modifier = Modifier.offset { IntOffset((bottomEdge.x - halfPx).roundToInt(), (bottomEdge.y - halfPx).roundToInt()) }
                .size(handleSizeDp).clip(CircleShape).background(StudioColors.GuideEdgeCyan).border(1.5.dp, Color.White, CircleShape)
                .pointerInput("edgeH", canvasH) {
                    detectDragGestures(onDragEnd = { onUpdateTransform(true) { it } }) { change, drag ->
                        change.consume()
                        val local = screenDeltaToLocal(drag.x, drag.y)
                        onUpdateTransform(false) { tf -> tf.copy(scaleY = (tf.scaleY + (local.y / canvasH) * 2f).coerceIn(0.15f, 4.5f)) }
                    }
                }
        )
        Box(
            modifier = Modifier.offset { IntOffset((rotHandle.x - halfPx).roundToInt(), (rotHandle.y - halfPx).roundToInt()) }
                .size(handleSizeDp).clip(CircleShape).background(StudioColors.SuccessGreen).border(1.5.dp, Color.White, CircleShape)
                .pointerInput("rotate", canvasW) {
                    detectDragGestures(onDragEnd = { onUpdateTransform(true) { it } }) { change, drag ->
                        change.consume()
                        val local = screenDeltaToLocal(drag.x, drag.y)
                        val deltaDeg = (local.x / (canvasW * 0.45f)) * 90f
                        onUpdateTransform(false) { tf ->
                            val next = ((tf.rotationDeg + deltaDeg + 360f) % 360f).let { if (it > 180f) it - 360f else it }
                            tf.copy(rotationDeg = next)
                        }
                    }
                }
        )
    } else {
        listOf("ptl" to tl, "ptr" to tr, "pbr" to br, "pbl" to bl).forEach { (corner, pos) ->
            Box(
                modifier = Modifier.offset { IntOffset((pos.x - halfPx).roundToInt(), (pos.y - halfPx).roundToInt()) }
                    .size(handleSizeDp).clip(CircleShape).background(StudioColors.WarningOrange).border(2.dp, Color.White, CircleShape)
                    .pointerInput(corner, hw, hh) {
                        detectDragGestures(onDragEnd = { onUpdateTransform(true) { it } }) { change, drag ->
                            change.consume()
                            val local = screenDeltaToLocal(drag.x, drag.y)
                            val dx = local.x / (hw * 2f).coerceAtLeast(40f)
                            val dy = local.y / (hh * 2f).coerceAtLeast(40f)
                            onUpdateTransform(false) { tf ->
                                when (corner) {
                                    "ptl" -> tf.copy(tlX = (tf.tlX + dx).coerceIn(-0.38f, 0.38f), tlY = (tf.tlY + dy).coerceIn(-0.38f, 0.38f))
                                    "ptr" -> tf.copy(trX = (tf.trX + dx).coerceIn(-0.38f, 0.38f), trY = (tf.trY + dy).coerceIn(-0.38f, 0.38f))
                                    "pbr" -> tf.copy(brX = (tf.brX + dx).coerceIn(-0.38f, 0.38f), brY = (tf.brY + dy).coerceIn(-0.38f, 0.38f))
                                    else -> tf.copy(blX = (tf.blX + dx).coerceIn(-0.38f, 0.38f), blY = (tf.blY + dy).coerceIn(-0.38f, 0.38f))
                                }
                            }
                        }
                    }
            )
        }
    }
}
