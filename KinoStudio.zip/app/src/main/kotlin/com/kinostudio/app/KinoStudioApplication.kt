package com.kinostudio.app

import android.app.Application
import android.content.ComponentCallbacks2
import com.kinostudio.core.database.ProjectRepository
import com.kinostudio.core.database.ThumbnailCache
import com.kinostudio.core.hardware.GalaxyS24Optimizer
import com.kinostudio.feature.engine.AiBackgroundProcessor
import com.layerstudio.kit.StudioTextEngine

class KinoStudioApplication : Application() {
    lateinit var projectRepository: ProjectRepository
        private set
    lateinit var thumbnailCache: ThumbnailCache
        private set
    lateinit var hardwareOptimizer: GalaxyS24Optimizer
        private set

    override fun onCreate() {
        super.onCreate()
        projectRepository = ProjectRepository(this)
        thumbnailCache = ThumbnailCache(this)
        hardwareOptimizer = GalaxyS24Optimizer(this)
        hardwareOptimizer.startThermalMonitoring()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            thumbnailCache.trimMemory(aggressive = level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN)
            if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
                StudioTextEngine.clearCache()
                AiBackgroundProcessor.releaseSession()
            }
        }
    }

    override fun onTerminate() {
        AiBackgroundProcessor.releaseSession()
        hardwareOptimizer.stopThermalMonitoring()
        super.onTerminate()
    }
}
