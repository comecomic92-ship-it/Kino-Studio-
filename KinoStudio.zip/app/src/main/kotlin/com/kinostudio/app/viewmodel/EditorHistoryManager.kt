package com.kinostudio.app.viewmodel

import com.kinostudio.core.model.VideoProject

class EditorHistoryManager(private val maxDepth: Int = 50) {
    private val undoStack = ArrayDeque<VideoProject>()
    private val redoStack = ArrayDeque<VideoProject>()

    fun record(previousState: VideoProject) {
        if (undoStack.lastOrNull() == previousState) return
        undoStack.addLast(previousState)
        if (undoStack.size > maxDepth) undoStack.removeFirst()
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(currentState: VideoProject): VideoProject? {
        if (undoStack.isEmpty()) return null
        val prev = undoStack.removeLast()
        redoStack.addLast(currentState)
        return prev
    }

    fun redo(currentState: VideoProject): VideoProject? {
        if (redoStack.isEmpty()) return null
        val next = redoStack.removeLast()
        undoStack.addLast(currentState)
        return next
    }

    fun clear() { undoStack.clear(); redoStack.clear() }
}
