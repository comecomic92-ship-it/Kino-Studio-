package com.kinostudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kinostudio.app.viewmodel.EditorViewModel
import com.kinostudio.core.model.ExportCodec
import com.kinostudio.core.model.ExportConfig
import com.kinostudio.core.model.ExportContainer
import com.kinostudio.core.model.ExportStatus
import com.kinostudio.core.model.ProjectResolutionPreset
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioShapes

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportSheet(viewModel: EditorViewModel, onDismiss: () -> Unit) {
    val exportStatus by viewModel.exportStatus.collectAsState()
    val hwProfile by viewModel.hardwareProfile.collectAsState()
    val project by viewModel.activeProject.collectAsState()
    var config by remember(project?.id) { mutableStateOf(ExportConfig(resolution = project?.resolutionPreset ?: ProjectResolutionPreset.FHD_1080)) }
    val isRunning = exportStatus is ExportStatus.Running

    ModalBottomSheet(onDismissRequest = { if (!isRunning) { viewModel.resetExportStatus(); onDismiss() } }, containerColor = StudioColors.BgGraphite) {
        Column(modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Экспорт — Kino Studio", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StudioColors.TextPrimary)
            Text("Аппаратный кодек: ${hwProfile.socPlatform.displayName}", fontSize = 11.sp, color = StudioColors.AccentLightBlue)
            Text("Разрешение", fontSize = 12.sp, color = StudioColors.TextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ProjectResolutionPreset.entries) { res -> FilterChip(selected = config.resolution == res, enabled = !isRunning, onClick = { config = config.copy(resolution = res) }, label = { Text(res.label, fontSize = 11.sp) }) }
            }
            Text("Частота кадров (FPS)", fontSize = 12.sp, color = StudioColors.TextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf(24, 25, 30, 50, 60)) { fps -> FilterChip(selected = config.fps == fps, enabled = !isRunning, onClick = { config = config.copy(fps = fps) }, label = { Text("$fps FPS", fontSize = 11.sp) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Кодек", fontSize = 12.sp, color = StudioColors.TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportCodec.entries.forEach { codec -> FilterChip(selected = config.codec == codec, enabled = !isRunning, onClick = { config = config.copy(codec = codec) }, label = { Text(if (codec == ExportCodec.H264) "H.264" else "H.265", fontSize = 11.sp) }) }
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Формат", fontSize = 12.sp, color = StudioColors.TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ExportContainer.entries.forEach { c -> FilterChip(selected = config.container == c, enabled = !isRunning, onClick = { config = config.copy(container = c) }, label = { Text(c.label, fontSize = 11.sp) }) }
                    }
                }
            }
            Column {
                Text("Битрейт видео: ${config.videoBitrateMbps.toInt()} Мбит/с", fontSize = 12.sp, color = StudioColors.TextSecondary)
                Slider(value = config.videoBitrateMbps, enabled = !isRunning, onValueChange = { config = config.copy(videoBitrateMbps = it) }, valueRange = 4f..50f)
            }
            when (val status = exportStatus) {
                is ExportStatus.Running -> Column(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Panel).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.AccentLightBlue, StudioShapes.Panel).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(status.stageLabel, color = StudioColors.TextPrimary, fontSize = 12.sp)
                        Text("${status.progressPercent}%", color = StudioColors.AccentLightBlue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    LinearProgressIndicator(progress = { status.progressPercent / 100f }, modifier = Modifier.fillMaxWidth())
                }
                is ExportStatus.Completed -> Column(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Panel).background(StudioColors.SuccessGreen.copy(alpha = 0.16f)).border(1.dp, StudioColors.SuccessGreen, StudioShapes.Panel).padding(10.dp)) {
                    Text("Сохранено в Галерею!", color = StudioColors.SuccessGreen, fontWeight = FontWeight.Bold)
                    Text("Movies/KinoStudio/${status.fileName}", color = StudioColors.TextPrimary, fontSize = 11.sp)
                }
                is ExportStatus.Failed -> Column(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Panel).background(StudioColors.DangerRed.copy(alpha = 0.16f)).border(1.dp, StudioColors.DangerRed, StudioShapes.Panel).padding(10.dp)) {
                    Text("Ошибка экспорта", color = StudioColors.DangerRed, fontWeight = FontWeight.Bold)
                    Text(status.errorMessage, color = StudioColors.TextPrimary, fontSize = 11.sp)
                }
                ExportStatus.Cancelled -> Text("Экспорт отменён", color = StudioColors.TextSecondary, fontSize = 12.sp)
                ExportStatus.Idle -> Unit
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isRunning) {
                    OutlinedButton(onClick = { viewModel.cancelExport() }, modifier = Modifier.fillMaxWidth()) { Text("Отменить", color = StudioColors.DangerRed) }
                } else {
                    OutlinedButton(onClick = { viewModel.resetExportStatus(); onDismiss() }, modifier = Modifier.weight(1f)) { Text("Закрыть", color = StudioColors.TextSecondary) }
                    Button(onClick = { viewModel.startExport(config) }, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue), modifier = Modifier.weight(1.5f)) { Text("Сохранить видео", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}
