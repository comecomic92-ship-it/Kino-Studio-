package com.kinostudio.app.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kinostudio.app.R
import com.kinostudio.app.viewmodel.EditorViewModel
import com.kinostudio.core.database.ProjectSummary
import com.kinostudio.core.model.AspectRatioPreset
import com.kinostudio.core.model.ProjectResolutionPreset
import com.kinostudio.core.model.VideoProject
import com.layerstudio.kit.StudioColors
import com.layerstudio.kit.StudioIcons
import com.layerstudio.kit.StudioShapes
import com.layerstudio.kit.trackTextInputFocus
import java.io.File

@Composable
fun HomeScreen(viewModel: EditorViewModel) {
    val projects by viewModel.projectSummaries.collectAsState()
    val hwProfile by viewModel.hardwareProfile.collectAsState()
    val thermal by viewModel.thermalState.collectAsState()
    val highRefresh by viewModel.highRefreshRateEnabled.collectAsState()
    val recoverableId by viewModel.recoverableProjectId.collectAsState()
    val haptic = LocalHapticFeedback.current

    var showCreateDialog by remember { mutableStateOf(false) }
    var renamingProject by remember { mutableStateOf<ProjectSummary?>(null) }
    var deletingProject by remember { mutableStateOf<ProjectSummary?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(StudioColors.BgBlack).statusBarsPadding().navigationBarsPadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_fg_ks),
                        contentDescription = "Kino Studio",
                        modifier = Modifier.size(40.dp).clip(StudioShapes.Card).background(Color(0xFF0A061A)).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card)
                    )
                    Column {
                        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Kino Studio", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = StudioColors.TextPrimary)
                            Text("1.4.0", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = StudioColors.TextSecondary, modifier = Modifier.padding(bottom = 2.dp))
                        }
                        Text("${hwProfile.socPlatform.displayName} • ${hwProfile.activeRefreshRate.toInt()} Гц • ${thermal.label}", fontSize = 11.sp, color = StudioColors.AccentLightBlue)
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.clip(StudioShapes.Card).background(StudioColors.BgGraphite).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card).padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Memory, null, tint = StudioColors.AccentLightBlue, modifier = Modifier.size(14.dp))
                    Text("120 Гц", fontSize = 11.sp, color = StudioColors.TextPrimary)
                    Switch(checked = highRefresh, onCheckedChange = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); viewModel.toggleHighRefreshRate(it) })
                }
            }
        }

        item {
            AnimatedVisibility(visible = recoverableId != null) {
                Surface(shape = StudioShapes.Card, color = StudioColors.BgPanel, modifier = Modifier.fillMaxWidth().border(1.dp, StudioColors.WarningOrange.copy(alpha = 0.6f), StudioShapes.Card)) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Refresh, null, tint = StudioColors.WarningOrange)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("Восстановить проект", fontWeight = FontWeight.SemiBold, color = StudioColors.TextPrimary, fontSize = 13.sp)
                                Text("Последний сеанс сохранён", color = StudioColors.TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { viewModel.dismissRecoveryPrompt() }) { Text("Позже", color = StudioColors.TextSecondary, fontSize = 12.sp) }
                            Button(onClick = { recoverableId?.let { viewModel.openProject(it) } }, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue), shape = StudioShapes.Chip) {
                                Text("Открыть", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        item {
            Box(
                modifier = Modifier.fillMaxWidth().clip(StudioShapes.Badge)
                    .background(Brush.linearGradient(listOf(StudioColors.AccentBlue.copy(alpha = 0.35f), StudioColors.BgPanel)))
                    .border(1.dp, StudioColors.AccentLightBlue.copy(alpha = 0.6f), StudioShapes.Badge)
                    .clickable { haptic.performHapticFeedback(HapticFeedbackType.LongPress); showCreateDialog = true }
                    .padding(vertical = 22.dp, horizontal = 18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(modifier = Modifier.size(46.dp).clip(CircleShape).background(StudioColors.AccentBlue), contentAlignment = Alignment.Center) {
                        Icon(StudioIcons.Add, "Новый проект", tint = Color.White, modifier = Modifier.size(28.dp))
                    }
                    Column {
                        Text("Новый проект", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = StudioColors.TextPrimary)
                        Spacer(Modifier.height(2.dp))
                        Text("Соотношение сторон • Разрешение (HD / Full HD / 2K / 4K)", fontSize = 11.sp, color = StudioColors.TextSecondary)
                    }
                }
            }
        }

        if (projects.isNotEmpty()) {
            item { Text("Недавние", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = StudioColors.TextPrimary) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(projects.take(6), key = { "rec_${it.id}" }) { proj -> RecentProjectCard(proj) { viewModel.openProject(proj.id) } }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Все проекты (${projects.size})", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = StudioColors.TextPrimary)
                if (hwProfile.isGalaxyS24Family) Text("Galaxy S24", fontSize = 11.sp, color = StudioColors.SuccessGreen, fontWeight = FontWeight.Medium)
            }
        }

        if (projects.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Card).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card).padding(28.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(StudioIcons.Timeline, null, tint = StudioColors.TextSecondary, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Проектов пока нет", color = StudioColors.TextPrimary, fontWeight = FontWeight.Medium)
                        Text("Нажмите «Новый проект» выше", color = StudioColors.TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(projects, key = { it.id }) { proj ->
                ProjectListCard(proj, { viewModel.openProject(proj.id) }, { renamingProject = proj }, { deletingProject = proj })
            }
        }
    }

    if (showCreateDialog) {
        CreateProjectDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, ratio, res, cw, ch -> showCreateDialog = false; viewModel.createNewProject(name, ratio, res, cw, ch) }
        )
    }

    renamingProject?.let { proj ->
        var text by remember(proj.id) { mutableStateOf(proj.name) }
        AlertDialog(
            onDismissRequest = { renamingProject = null },
            containerColor = StudioColors.BgPanel,
            title = { Text("Переименовать проект", color = StudioColors.TextPrimary, fontSize = 16.sp) },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true, label = { Text("Название") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = StudioColors.TextPrimary, unfocusedTextColor = StudioColors.TextPrimary),
                    modifier = Modifier.fillMaxWidth().trackTextInputFocus()
                )
            },
            confirmButton = { TextButton(onClick = { viewModel.renameProject(proj.id, text); renamingProject = null }) { Text("Сохранить", color = StudioColors.AccentLightBlue) } },
            dismissButton = { TextButton(onClick = { renamingProject = null }) { Text("Отмена", color = StudioColors.TextSecondary) } }
        )
    }

    deletingProject?.let { proj ->
        AlertDialog(
            onDismissRequest = { deletingProject = null },
            containerColor = StudioColors.BgPanel,
            title = { Text("Удалить проект?", color = StudioColors.TextPrimary, fontSize = 16.sp) },
            text = { Text("Проект «${proj.name}» будет удалён. Исходные файлы на устройстве сохранятся.", color = StudioColors.TextSecondary) },
            confirmButton = { Button(colors = ButtonDefaults.buttonColors(containerColor = StudioColors.DangerRed), onClick = { viewModel.deleteProject(proj.id); deletingProject = null }) { Text("Удалить", color = Color.White) } },
            dismissButton = { TextButton(onClick = { deletingProject = null }) { Text("Отмена", color = StudioColors.TextSecondary) } }
        )
    }
}

@Composable
private fun RecentProjectCard(summary: ProjectSummary, onOpen: () -> Unit) {
    Column(modifier = Modifier.width(150.dp).clip(StudioShapes.Card).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card).clickable(onClick = onOpen)) {
        ProjectThumbBox(summary.thumbnailPath, summary.aspectRatioLabel, summary.durationMs, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Column(modifier = Modifier.padding(8.dp)) {
            Text(summary.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = StudioColors.TextPrimary, fontSize = 12.sp)
            Text(formatProjectDate(summary.updatedAtMs), fontSize = 10.sp, color = StudioColors.TextSecondary)
        }
    }
}

@Composable
private fun ProjectListCard(summary: ProjectSummary, onOpen: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Card).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Card).clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ProjectThumbBox(summary.thumbnailPath, summary.aspectRatioLabel, summary.durationMs, Modifier.width(100.dp).height(60.dp).clip(StudioShapes.Chip))
        Column(modifier = Modifier.weight(1f)) {
            Text(summary.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = StudioColors.TextPrimary, fontSize = 14.sp)
            Text("${summary.aspectRatioLabel} • ${formatTimecode(summary.durationMs)}", fontSize = 11.sp, color = StudioColors.AccentLightBlue)
            Text(formatProjectDate(summary.updatedAtMs), fontSize = 10.sp, color = StudioColors.TextSecondary)
        }
        IconButton(onClick = onRename, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Edit, "Переименовать", tint = StudioColors.TextSecondary, modifier = Modifier.size(18.dp)) }
        IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) { Icon(StudioIcons.Delete, "Удалить", tint = StudioColors.DangerRed, modifier = Modifier.size(18.dp)) }
    }
}

@Composable
private fun ProjectThumbBox(path: String?, aspectRatioLabel: String, durationMs: Long, modifier: Modifier = Modifier) {
    val bmp = remember(path) { if (!path.isNullOrBlank() && File(path).exists()) BitmapFactory.decodeFile(path)?.asImageBitmap() else null }
    Box(modifier = modifier.background(StudioColors.BgGraphite), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        else Icon(StudioIcons.Timeline, null, tint = StudioColors.TextSecondary.copy(alpha = 0.5f))
        Box(modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(StudioShapes.Small).background(Color.Black.copy(alpha = 0.72f)).padding(horizontal = 4.dp, vertical = 1.dp)) {
            Text(formatTimecode(durationMs), fontSize = 9.sp, color = Color.White)
        }
        Box(modifier = Modifier.align(Alignment.TopStart).padding(4.dp).clip(StudioShapes.Small).background(StudioColors.AccentBlue.copy(alpha = 0.85f)).padding(horizontal = 4.dp, vertical = 1.dp)) {
            Text(aspectRatioLabel.substringBefore(" •"), fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun CreateProjectDialog(onDismiss: () -> Unit, onCreate: (String, AspectRatioPreset, ProjectResolutionPreset, Int, Int) -> Unit) {
    var name by remember { mutableStateOf("Проект ${formatProjectDate(System.currentTimeMillis()).take(5)}") }
    var selectedRatio by remember { mutableStateOf(AspectRatioPreset.RATIO_9_16) }
    var selectedResolution by remember { mutableStateOf(ProjectResolutionPreset.FHD_1080) }
    var customW by remember { mutableStateOf("1080") }
    var customH by remember { mutableStateOf("1920") }
    val (previewW, previewH) = VideoProject.computeDimensions(selectedRatio, selectedResolution, customW.toIntOrNull() ?: 1080, customH.toIntOrNull() ?: 1920)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = StudioColors.BgPanel,
        title = { Text("Новый проект", color = StudioColors.TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, label = { Text("Название проекта") }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = StudioColors.TextPrimary, unfocusedTextColor = StudioColors.TextPrimary),
                    modifier = Modifier.fillMaxWidth().trackTextInputFocus()
                )
                Text("Соотношение сторон", fontSize = 12.sp, color = StudioColors.TextSecondary)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(AspectRatioPreset.entries) { preset ->
                        FilterChip(selected = selectedRatio == preset, onClick = { selectedRatio = preset }, label = { Text(preset.label, fontSize = 11.sp) })
                    }
                }
                if (selectedRatio == AspectRatioPreset.CUSTOM) {
                    Text("Своё разрешение (пиксели)", fontSize = 12.sp, color = StudioColors.TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customW, onValueChange = { customW = it.filter { ch -> ch.isDigit() } }, label = { Text("Ширина") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = StudioColors.TextPrimary, unfocusedTextColor = StudioColors.TextPrimary),
                            modifier = Modifier.weight(1f).trackTextInputFocus()
                        )
                        OutlinedTextField(
                            value = customH, onValueChange = { customH = it.filter { ch -> ch.isDigit() } }, label = { Text("Высота") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = StudioColors.TextPrimary, unfocusedTextColor = StudioColors.TextPrimary),
                            modifier = Modifier.weight(1f).trackTextInputFocus()
                        )
                    }
                } else {
                    Text("Разрешение", fontSize = 12.sp, color = StudioColors.TextSecondary)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(ProjectResolutionPreset.entries) { res ->
                            FilterChip(selected = selectedResolution == res, onClick = { selectedResolution = res }, label = { Text(res.label, fontSize = 11.sp) })
                        }
                    }
                }
                Box(modifier = Modifier.fillMaxWidth().clip(StudioShapes.Chip).background(StudioColors.BgDarkGray).border(1.dp, StudioColors.BorderSubtle, StudioShapes.Chip).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("Размер кадра: $previewW × $previewH px", color = StudioColors.AccentLightBlue, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        },
        confirmButton = {
            Button(colors = ButtonDefaults.buttonColors(containerColor = StudioColors.AccentBlue), onClick = { onCreate(name, selectedRatio, selectedResolution, customW.toIntOrNull() ?: 1080, customH.toIntOrNull() ?: 1920) }) {
                Text("Создать", color = Color.White)
            }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена", color = StudioColors.TextSecondary) } }
    )
}
