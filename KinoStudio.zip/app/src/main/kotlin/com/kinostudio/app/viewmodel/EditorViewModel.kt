package com.kinostudio.app.viewmodel

import android.app.Activity
import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kinostudio.app.KinoStudioApplication
import com.kinostudio.core.database.ProjectSummary
import com.kinostudio.core.hardware.DeviceHardwareProfile
import com.kinostudio.core.model.AspectRatioPreset
import com.kinostudio.core.model.BackgroundConfig
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.core.model.BackgroundPoint
import com.kinostudio.core.model.LongTaskState
import com.kinostudio.core.model.AudioClipItem
import com.kinostudio.core.model.BufferedMediaItem
import com.kinostudio.core.model.ColorGradingConfig
import com.kinostudio.core.model.ColorPreset
import com.kinostudio.core.model.ExportConfig
import com.kinostudio.core.model.ExportStatus
import com.kinostudio.core.model.MediaKind
import com.kinostudio.core.model.ProjectResolutionPreset
import com.kinostudio.core.model.SpeedRampPoint
import com.kinostudio.core.model.TextTrackItem
import com.kinostudio.core.model.TimelineTrack
import com.kinostudio.core.model.TrackKind
import com.kinostudio.core.model.TransformState
import com.kinostudio.core.model.TransitionType
import com.kinostudio.core.model.VideoProject
import com.kinostudio.core.model.VisualClipItem
import com.kinostudio.feature.engine.AiBackgroundProcessor
import com.kinostudio.feature.engine.AiModelManager
import com.kinostudio.feature.engine.AudioExtractorUtil
import com.kinostudio.feature.engine.MediaProbeUtil
import com.kinostudio.feature.engine.VideoExportEngine
import com.kinostudio.feature.engine.VideoReverseProcessor
import com.kinostudio.feature.engine.VoiceRecorder
import com.kinostudio.feature.engine.WaveformExtractor
import com.layerstudio.kit.LayerFontFamily
import com.layerstudio.kit.StudioTextEngine
import com.layerstudio.kit.TextStyleConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs

enum class EditorToolTab(val label: String) {
    ADD("Добавить"),
    EDIT("Монтаж"),
    TRANSFORM("Трансформ."),
    BACKGROUND("Фон"),
    AUDIO("Звук"),
    TEXT("Текст"),
    COLOR("Цвет"),
    SPEED("Скорость")
}

enum class EditSubPanel { NONE, TRIM, TRANSITIONS }
enum class TransformMode { FREE, PERSPECTIVE }
enum class AudioSubPanel { ADD, EDIT }

data class SelectionState(
    val visualClipIds: Set<String> = emptySet(),
    val textItemIds: Set<String> = emptySet(),
    val audioClipIds: Set<String> = emptySet(),
    val selectedTrackIds: Set<String> = emptySet(),
    val primaryId: String? = null
) {
    val isEmpty: Boolean get() = visualClipIds.isEmpty() && textItemIds.isEmpty() && audioClipIds.isEmpty()
    val totalSelectedCount: Int get() = visualClipIds.size + textItemIds.size + audioClipIds.size
}

private data class ClipboardBundle(
    val visuals: List<VisualClipItem> = emptyList(),
    val texts: List<TextTrackItem> = emptyList(),
    val audios: List<AudioClipItem> = emptyList()
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as KinoStudioApplication
    private val repository = app.projectRepository
    val thumbnailCache = app.thumbnailCache
    private val hardwareOptimizer = app.hardwareOptimizer
    private val exportEngine = VideoExportEngine(application)
    private val voiceRecorder = VoiceRecorder(application)
    private val history = EditorHistoryManager()

    val projectSummaries: StateFlow<List<ProjectSummary>> = repository.observeProjectSummaries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val highRefreshRateEnabled: StateFlow<Boolean> = repository.observeHighRefreshRatePref()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val thermalState = hardwareOptimizer.thermalState
    val exportStatus: StateFlow<ExportStatus> = exportEngine.status

    private val _hardwareProfile = MutableStateFlow(hardwareOptimizer.detectHardwareProfile(null))
    val hardwareProfile: StateFlow<DeviceHardwareProfile> = _hardwareProfile.asStateFlow()
    private val _activeProject = MutableStateFlow<VideoProject?>(null)
    val activeProject: StateFlow<VideoProject?> = _activeProject.asStateFlow()
    private val _selection = MutableStateFlow(SelectionState())
    val selection: StateFlow<SelectionState> = _selection.asStateFlow()
    private val _activeTool = MutableStateFlow(EditorToolTab.ADD)
    val activeTool: StateFlow<EditorToolTab> = _activeTool.asStateFlow()
    private val _editSubPanel = MutableStateFlow(EditSubPanel.TRIM)
    val editSubPanel: StateFlow<EditSubPanel> = _editSubPanel.asStateFlow()
    private val _transformMode = MutableStateFlow(TransformMode.FREE)
    val transformMode: StateFlow<TransformMode> = _transformMode.asStateFlow()
    private val _audioSubPanel = MutableStateFlow(AudioSubPanel.ADD)
    val audioSubPanel: StateFlow<AudioSubPanel> = _audioSubPanel.asStateFlow()
    private val _editingTextOnCanvasId = MutableStateFlow<String?>(null)
    val editingTextOnCanvasId: StateFlow<String?> = _editingTextOnCanvasId.asStateFlow()
    private val _showTextStyleInspector = MutableStateFlow(false)
    val showTextStyleInspector: StateFlow<Boolean> = _showTextStyleInspector.asStateFlow()
    private val _playheadMs = MutableStateFlow(0L)
    val playheadMs: StateFlow<Long> = _playheadMs.asStateFlow()
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()
    private val _timelineZoom = MutableStateFlow(1.0f)
    val timelineZoom: StateFlow<Float> = _timelineZoom.asStateFlow()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()
    private val _hasClipboard = MutableStateFlow(false)
    val hasClipboard: StateFlow<Boolean> = _hasClipboard.asStateFlow()
    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()
    private val _reverseProgress = MutableStateFlow<Int?>(null)
    val reverseProgress: StateFlow<Int?> = _reverseProgress.asStateFlow()
    private val _longTask = MutableStateFlow<LongTaskState?>(null)
    val longTask: StateFlow<LongTaskState?> = _longTask.asStateFlow()
    private val _isBgModelReady = MutableStateFlow(AiModelManager.isModelReady(application))
    val isBgModelReady: StateFlow<Boolean> = _isBgModelReady.asStateFlow()
    private val _isPickingBgPoints = MutableStateFlow(false)
    val isPickingBgPoints: StateFlow<Boolean> = _isPickingBgPoints.asStateFlow()
    private val _bgPointPositiveMode = MutableStateFlow(true)
    val bgPointPositiveMode: StateFlow<Boolean> = _bgPointPositiveMode.asStateFlow()
    private val _bgPreviewMask = MutableStateFlow<Bitmap?>(null)
    val bgPreviewMask: StateFlow<Bitmap?> = _bgPreviewMask.asStateFlow()
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()
    private val _recoverableProjectId = MutableStateFlow<String?>(null)
    val recoverableProjectId: StateFlow<String?> = _recoverableProjectId.asStateFlow()

    private var clipboard: ClipboardBundle? = null
    private var autoSaveJob: Job? = null
    private var activeLongTaskJob: Job? = null
    private var previewMaskJob: Job? = null

    init {
        viewModelScope.launch {
            val lastId = repository.getLastOpenedProjectId()
            if (!lastId.isNullOrBlank() && repository.loadProject(lastId) != null) {
                _recoverableProjectId.value = lastId
            }
        }
    }

    fun refreshHardwareInfo(activity: Activity, activeHz: Float) {
        _hardwareProfile.value = hardwareOptimizer.detectHardwareProfile(activity).copy(activeRefreshRate = activeHz)
    }

    fun toggleHighRefreshRate(enabled: Boolean) { viewModelScope.launch { repository.setHighRefreshRatePref(enabled) } }
    fun clearStatusMessage() { _statusMessage.value = null }
    private fun postMessage(msg: String) { _statusMessage.value = msg }

    fun createNewProject(name: String, aspectRatio: AspectRatioPreset, resolutionPreset: ProjectResolutionPreset, customW: Int = 1080, customH: Int = 1920) {
        val (w, h) = VideoProject.computeDimensions(aspectRatio, resolutionPreset, customW, customH)
        val project = VideoProject(
            name = name.trim().ifEmpty { "Проект ${projectSummaries.value.size + 1}" },
            aspectRatio = aspectRatio, resolutionPreset = resolutionPreset,
            projectWidth = w, projectHeight = h, tracks = VideoProject.defaultTracks()
        )
        viewModelScope.launch { repository.saveProject(project); openLoadedProject(project) }
    }

    fun openProject(projectId: String) {
        viewModelScope.launch {
            val loaded = repository.loadProject(projectId)
            if (loaded != null) openLoadedProject(loaded) else postMessage("Не удалось открыть проект")
        }
    }

    fun dismissRecoveryPrompt() { _recoverableProjectId.value = null }

    private fun openLoadedProject(project: VideoProject) {
        history.clear()
        val ready = pruneEmptyTracks(project.copy(tracks = project.tracks.ifEmpty { VideoProject.defaultTracks() }))
        _activeProject.value = ready
        val firstClip = ready.visualClips.firstOrNull()
        _selection.value = if (firstClip != null) SelectionState(visualClipIds = setOf(firstClip.id), primaryId = firstClip.id) else SelectionState()
        _playheadMs.value = 0L; _isPlaying.value = false; _timelineZoom.value = 1f
        _editingTextOnCanvasId.value = null; _showTextStyleInspector.value = false; _recoverableProjectId.value = null
        syncHistoryFlags()
        viewModelScope.launch { repository.setLastOpenedProjectId(ready.id) }
    }

    fun closeEditorAndSave() {
        val current = _activeProject.value ?: return
        _isPlaying.value = false; _editingTextOnCanvasId.value = null
        if (voiceRecorder.isRecording()) stopVoiceRecording()
        viewModelScope.launch {
            repository.saveProject(current); repository.setLastOpenedProjectId(null)
            _activeProject.value = null; _selection.value = SelectionState()
        }
    }

    fun saveProjectNow() {
        val current = _activeProject.value ?: return
        viewModelScope.launch { repository.saveProject(current); postMessage("Проект сохранён") }
    }

    fun renameProject(projectId: String, newName: String) {
        viewModelScope.launch {
            repository.renameProject(projectId, newName)
            _activeProject.value?.let { if (it.id == projectId) _activeProject.value = it.copy(name = newName.trim().ifEmpty { it.name }) }
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.deleteProject(projectId)
            if (_recoverableProjectId.value == projectId) _recoverableProjectId.value = null
        }
    }

    private fun pruneEmptyTracks(project: VideoProject): VideoProject {
        val usedVisual = project.visualClips.map { it.trackId }.toSet()
        val usedText = project.textItems.map { it.trackId }.toSet()
        val usedAudio = project.audioClips.map { it.trackId }.toSet()

        val keptVisual = project.tracks
            .filter { it.kind == TrackKind.VISUAL && it.id in usedVisual }
            .ifEmpty {
                listOf(
                    project.tracks.firstOrNull { it.kind == TrackKind.VISUAL }
                        ?: TimelineTrack(id = "track_v1", kind = TrackKind.VISUAL, name = "V1")
                )
            }
            .mapIndexed { idx, t -> t.copy(name = "V${idx + 1}") }

        val keptText = project.tracks
            .filter { it.kind == TrackKind.TEXT && it.id in usedText }
            .mapIndexed { idx, t -> t.copy(name = "T${idx + 1}") }

        val keptAudio = project.tracks
            .filter { it.kind == TrackKind.AUDIO && it.id in usedAudio }
            .mapIndexed { idx, t -> t.copy(name = "A${idx + 1}") }

        val allKept = keptVisual + keptText + keptAudio
        val keptIds = allKept.map { it.id }.toSet()
        if (_selection.value.selectedTrackIds.any { it !in keptIds }) {
            _selection.value = _selection.value.copy(selectedTrackIds = _selection.value.selectedTrackIds.intersect(keptIds))
        }
        return project.copy(tracks = allKept)
    }

    private fun updateProject(recordUndo: Boolean = true, pruneEmpty: Boolean = true, transform: (VideoProject) -> VideoProject) {
        val current = _activeProject.value ?: return
        val transformed = transform(current)
        val cleaned = if (pruneEmpty) pruneEmptyTracks(transformed) else transformed
        val next = cleaned.copy(updatedAtMs = System.currentTimeMillis())
        if (next == current) return
        if (recordUndo) { history.record(current); syncHistoryFlags() }
        _activeProject.value = next
        scheduleAutoSave(next)
    }

    fun jumpToStart() {
        _isPlaying.value = false
        _playheadMs.value = 0L
    }

    fun jumpToEnd() {
        _isPlaying.value = false
        _playheadMs.value = (_activeProject.value?.totalDurationMs ?: 0L).coerceAtLeast(0L)
    }

    fun stepPlayheadFrames(deltaFrames: Int) {
        _isPlaying.value = false
        val frameMs = 33L
        val maxMs = (_activeProject.value?.totalDurationMs ?: 0L).coerceAtLeast(0L)
        _playheadMs.value = (_playheadMs.value + deltaFrames * frameMs).coerceIn(0L, maxMs)
    }

    private fun scheduleAutoSave(project: VideoProject) {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch { delay(700L); repository.saveProject(project) }
    }

    fun undo() {
        val cur = _activeProject.value ?: return
        val prev = history.undo(cur) ?: return
        _activeProject.value = prev; syncHistoryFlags(); scheduleAutoSave(prev)
    }

    fun redo() {
        val cur = _activeProject.value ?: return
        val next = history.redo(cur) ?: return
        _activeProject.value = next; syncHistoryFlags(); scheduleAutoSave(next)
    }

    private fun syncHistoryFlags() { _canUndo.value = history.canUndo(); _canRedo.value = history.canRedo() }

    fun setActiveTool(tab: EditorToolTab) {
        _activeTool.value = tab
        if (tab != EditorToolTab.TEXT) { _editingTextOnCanvasId.value = null; _showTextStyleInspector.value = false }
        if (tab != EditorToolTab.BACKGROUND) {
            _isPickingBgPoints.value = false
            clearPreviewMaskBitmap()
        }
    }

    private fun clearPreviewMaskBitmap() {
        previewMaskJob?.cancel()
        _bgPreviewMask.value?.let { if (!it.isRecycled) it.recycle() }
        _bgPreviewMask.value = null
    }

    fun cancelLongTask() {
        activeLongTaskJob?.cancel()
        activeLongTaskJob = null
        _longTask.value = null
        _reverseProgress.value = null
        postMessage("Операция отменена")
    }

    fun setEditSubPanel(panel: EditSubPanel) { _editSubPanel.value = if (_editSubPanel.value == panel) EditSubPanel.NONE else panel }
    fun setTransformMode(mode: TransformMode) { _transformMode.value = mode }
    fun setAudioSubPanel(panel: AudioSubPanel) { _audioSubPanel.value = panel }
    fun setEditingTextOnCanvas(itemId: String?) {
        _editingTextOnCanvasId.value = itemId
        if (itemId != null) { selectTextItem(itemId, false); _activeTool.value = EditorToolTab.TEXT }
    }
    fun toggleTextStyleInspector() { _showTextStyleInspector.value = !_showTextStyleInspector.value }
    fun setPlayheadMs(ms: Long) { _playheadMs.value = ms.coerceIn(0L, (_activeProject.value?.totalDurationMs ?: 0L).coerceAtLeast(0L)) }
    fun setPlaying(playing: Boolean) { _isPlaying.value = playing }
    fun togglePlayPause() {
        val project = _activeProject.value ?: return
        if (project.totalDurationMs <= 0L) return
        if (!_isPlaying.value && _playheadMs.value >= project.totalDurationMs - 50L) _playheadMs.value = 0L
        _editingTextOnCanvasId.value = null
        _isPlaying.value = !_isPlaying.value
    }
    fun setTimelineZoom(zoom: Float) { _timelineZoom.value = zoom.coerceIn(0.35f, 4.5f) }
    fun toggleMagneticSnap() { updateProject(false) { it.copy(magneticSnapEnabled = !it.magneticSnapEnabled) } }

    fun clearSelection() { _selection.value = SelectionState(); _editingTextOnCanvasId.value = null }

    fun selectVisualClip(clipId: String, additive: Boolean = false) {
        _editingTextOnCanvasId.value = null
        _selection.value = if (additive) {
            val cur = _selection.value
            val set = if (clipId in cur.visualClipIds) cur.visualClipIds - clipId else cur.visualClipIds + clipId
            cur.copy(visualClipIds = set, primaryId = clipId)
        } else SelectionState(visualClipIds = setOf(clipId), primaryId = clipId)
    }

    fun selectTextItem(itemId: String, additive: Boolean = false) {
        _selection.value = if (additive) {
            val cur = _selection.value
            val set = if (itemId in cur.textItemIds) cur.textItemIds - itemId else cur.textItemIds + itemId
            cur.copy(textItemIds = set, primaryId = itemId)
        } else SelectionState(textItemIds = setOf(itemId), primaryId = itemId)
    }

    fun selectAudioClip(clipId: String, additive: Boolean = false) {
        _editingTextOnCanvasId.value = null
        _selection.value = if (additive) {
            val cur = _selection.value
            val set = if (clipId in cur.audioClipIds) cur.audioClipIds - clipId else cur.audioClipIds + clipId
            cur.copy(audioClipIds = set, primaryId = clipId)
        } else SelectionState(audioClipIds = setOf(clipId), primaryId = clipId)
    }

    fun toggleSelectTrack(trackId: String) {
        val project = _activeProject.value ?: return
        val cur = _selection.value
        val track = project.tracks.firstOrNull { it.id == trackId } ?: return
        val selected = trackId in cur.selectedTrackIds
        val nextTracks = if (selected) cur.selectedTrackIds - trackId else cur.selectedTrackIds + trackId
        var nv = cur.visualClipIds; var nt = cur.textItemIds; var na = cur.audioClipIds
        when (track.kind) {
            TrackKind.VISUAL -> { val ids = project.visualClips.filter { it.trackId == trackId }.map { it.id }.toSet(); nv = if (selected) nv - ids else nv + ids }
            TrackKind.TEXT -> { val ids = project.textItems.filter { it.trackId == trackId }.map { it.id }.toSet(); nt = if (selected) nt - ids else nt + ids }
            TrackKind.AUDIO -> { val ids = project.audioClips.filter { it.trackId == trackId }.map { it.id }.toSet(); na = if (selected) na - ids else na + ids }
        }
        _selection.value = SelectionState(nv, nt, na, nextTracks, nv.firstOrNull() ?: nt.firstOrNull() ?: na.firstOrNull())
    }

    fun selectAllItems() {
        val p = _activeProject.value ?: return
        val v = p.visualClips.map { it.id }.toSet(); val t = p.textItems.map { it.id }.toSet(); val a = p.audioClips.map { it.id }.toSet()
        _selection.value = SelectionState(v, t, a, p.tracks.map { it.id }.toSet(), v.firstOrNull() ?: t.firstOrNull() ?: a.firstOrNull())
        postMessage("Выбраны все слои (${_selection.value.totalSelectedCount})")
    }

    fun primaryVisualClip(): VisualClipItem? {
        val p = _activeProject.value ?: return null; val s = _selection.value
        return p.visualClips.firstOrNull { it.id == s.primaryId } ?: p.visualClips.firstOrNull { it.id in s.visualClipIds }
    }

    fun primaryTextItem(): TextTrackItem? {
        val p = _activeProject.value ?: return null; val s = _selection.value
        return p.textItems.firstOrNull { it.id == s.primaryId } ?: p.textItems.firstOrNull { it.id in s.textItemIds }
    }

    fun primaryAudioClip(): AudioClipItem? {
        val p = _activeProject.value ?: return null; val s = _selection.value
        return p.audioClips.firstOrNull { it.id == s.primaryId } ?: p.audioClips.firstOrNull { it.id in s.audioClipIds }
    }

    fun importToBuffer(uris: List<Uri>, fallbackKind: MediaKind? = null) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val added = uris.map { uri ->
                persistReadPermission(uri)
                val info = MediaProbeUtil.probeMedia(app, uri.toString(), fallbackKind)
                BufferedMediaItem(uri = uri.toString(), displayName = info.displayName, kind = info.kind, durationMs = info.durationMs, width = info.width, height = info.height, hasAudio = info.hasAudio)
            }
            updateProject(false) { proj ->
                val existing = proj.mediaBuffer.map { it.uri }.toSet()
                proj.copy(mediaBuffer = proj.mediaBuffer + added.filter { it.uri !in existing })
            }
            postMessage("Добавлено в буфер: ${added.size}")
        }
    }

    fun removeFromBuffer(id: String) { updateProject(false) { it.copy(mediaBuffer = it.mediaBuffer.filterNot { b -> b.id == id }) } }

    fun addBufferedItemToTimeline(item: BufferedMediaItem, atPlayhead: Boolean = true) {
        val proj = _activeProject.value ?: return
        if (item.kind == MediaKind.AUDIO) {
            viewModelScope.launch {
                val wave = WaveformExtractor.extractWaveform(app, item.uri, 56)
                updateProject { p ->
                    val aTracks = p.tracks.filter { it.kind == TrackKind.AUDIO }
                    val target = aTracks.firstOrNull() ?: TimelineTrack(kind = TrackKind.AUDIO, name = "A1")
                    val baseTracks = if (aTracks.isEmpty()) p.tracks + target else p.tracks
                    val startMs = if (atPlayhead) _playheadMs.value else (p.audioClips.filter { it.trackId == target.id }.maxOfOrNull { it.timelineEndMs } ?: 0L)
                    val (resTracks, resId) = resolveNonOverlappingTrack(baseTracks, TrackKind.AUDIO, target.id, startMs, startMs + item.durationMs) { tid ->
                        p.audioClips.filter { it.trackId == tid }.map { it.timelineStartMs to it.timelineEndMs }
                    }
                    val clip = AudioClipItem(trackId = resId, displayName = item.displayName, sourceUri = item.uri, sourceDurationMs = item.durationMs, trimStartMs = 0L, trimEndMs = item.durationMs, timelineStartMs = startMs, waveform = wave)
                    _selection.value = SelectionState(audioClipIds = setOf(clip.id), primaryId = clip.id)
                    p.copy(tracks = resTracks, audioClips = p.audioClips + clip)
                }
                postMessage("Аудио добавлено на дорожку")
            }
        } else {
            val isImg = item.kind == MediaKind.IMAGE
            viewModelScope.launch {
                val cover = if (proj.thumbnailPath == null) thumbnailCache.saveProjectCover(proj.id, item.uri, isImg) else proj.thumbnailPath
                updateProject { p ->
                    val vTracks = p.tracks.filter { it.kind == TrackKind.VISUAL }
                    val base = vTracks.firstOrNull() ?: TimelineTrack(kind = TrackKind.VISUAL, name = "V1")
                    val allTr = if (vTracks.isEmpty()) listOf(base) + p.tracks else p.tracks
                    val existingOnBase = p.visualClips.filter { it.trackId == base.id }
                    val startMs = when {
                        existingOnBase.isEmpty() -> 0L
                        atPlayhead -> _playheadMs.value
                        else -> existingOnBase.maxOfOrNull { it.timelineEndMs } ?: 0L
                    }
                    val dur = if (isImg) 4000L else item.durationMs.coerceAtLeast(300L)
                    val (resTracks, resId) = resolveNonOverlappingTrack(allTr, TrackKind.VISUAL, base.id, startMs, startMs + dur) { tid ->
                        p.visualClips.filter { it.trackId == tid }.map { it.timelineStartMs to it.timelineEndMs }
                    }
                    val clip = VisualClipItem(trackId = resId, sourceUri = item.uri, displayName = item.displayName, isImage = isImg, sourceDurationMs = dur, trimStartMs = 0L, trimEndMs = dur, timelineStartMs = startMs, isAudioMuted = isImg || !item.hasAudio)
                    _selection.value = SelectionState(visualClipIds = setOf(clip.id), primaryId = clip.id)
                    p.copy(thumbnailPath = cover ?: p.thumbnailPath, tracks = resTracks, visualClips = p.visualClips + clip)
                }
                postMessage("${item.kind.label} добавлено на дорожку")
            }
        }
    }

    fun importMusicDirectlyAndAdd(uri: Uri) {
        viewModelScope.launch {
            persistReadPermission(uri)
            val info = MediaProbeUtil.probeMedia(app, uri.toString(), MediaKind.AUDIO)
            val buf = BufferedMediaItem(uri = uri.toString(), displayName = info.displayName, kind = MediaKind.AUDIO, durationMs = info.durationMs, hasAudio = true)
            updateProject(false) { p -> if (p.mediaBuffer.any { it.uri == buf.uri }) p else p.copy(mediaBuffer = p.mediaBuffer + buf) }
            addBufferedItemToTimeline(buf, true)
        }
    }

    fun replaceSelectedVisualWithBuffer(item: BufferedMediaItem) {
        if (item.kind == MediaKind.AUDIO) { postMessage("Выберите видео или фото для замены"); return }
        val target = primaryVisualClip() ?: run { postMessage("Выберите клип для замены"); return }
        val isImg = item.kind == MediaKind.IMAGE
        val newDur = if (isImg) target.effectiveDurationMs else item.durationMs.coerceAtLeast(300L)
        updateProject { proj ->
            proj.copy(visualClips = proj.visualClips.map { c ->
                if (c.id == target.id) c.copy(sourceUri = item.uri, reversedUri = null, isReversed = false, displayName = item.displayName, isImage = isImg, sourceDurationMs = newDur, trimStartMs = 0L, trimEndMs = newDur, isAudioMuted = isImg || !item.hasAudio) else c
            })
        }
        postMessage("Файл заменён")
    }

    private fun persistReadPermission(uri: Uri) {
        runCatching { app.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
    }

    private fun resolveNonOverlappingTrack(
        tracks: List<TimelineTrack>, kind: TrackKind, preferredTrackId: String, startMs: Long, endMs: Long,
        existingRanges: (String) -> List<Pair<Long, Long>>
    ): Pair<List<TimelineTrack>, String> {
        val sameKind = tracks.filter { it.kind == kind }
        val startIdx = sameKind.indexOfFirst { it.id == preferredTrackId }.coerceAtLeast(0)
        fun overlaps(tid: String) = existingRanges(tid).any { (a, b) -> startMs < b - 40L && endMs > a + 40L }
        for (i in startIdx until sameKind.size) {
            if (!overlaps(sameKind[i].id)) return tracks to sameKind[i].id
        }
        val newTrack = TimelineTrack(kind = kind, name = "${kind.prefix}${sameKind.size + 1}")
        return insertTrackAboveKind(tracks, kind, newTrack) to newTrack.id
    }

    private fun insertTrackAboveKind(tracks: List<TimelineTrack>, kind: TrackKind, newTrack: TimelineTrack): List<TimelineTrack> {
        val list = tracks.toMutableList()
        val lastIdx = list.indexOfLast { it.kind == kind }
        if (lastIdx >= 0) list.add(lastIdx + 1, newTrack) else list.add(newTrack)
        return list
    }

    fun toggleTrackHidden(trackId: String) {
        updateProject { proj -> proj.copy(tracks = proj.tracks.map { if (it.id == trackId) it.copy(isHidden = !it.isHidden) else it }) }
    }

    fun moveTrackOrder(trackId: String, deltaUp: Int) {
        updateProject { proj ->
            val target = proj.tracks.firstOrNull { it.id == trackId } ?: return@updateProject proj
            val same = proj.tracks.filter { it.kind == target.kind }.toMutableList()
            val idx = same.indexOfFirst { it.id == trackId }
            val newIdx = (idx + deltaUp).coerceIn(0, same.lastIndex)
            if (idx < 0 || idx == newIdx) return@updateProject proj
            val moved = same.removeAt(idx); same.add(newIdx, moved)
            var c = 0
            proj.copy(tracks = proj.tracks.map { if (it.kind == target.kind) same[c++] else it })
        }
    }

    fun dragVisualClip(clipId: String, candidateStartMs: Long, verticalTrackDelta: Int = 0, commitUndo: Boolean = false) {
        val snapped = snapTimeMs(candidateStartMs, excludeId = clipId)
        updateProject(recordUndo = commitUndo, pruneEmpty = commitUndo) { proj ->
            val clip = proj.visualClips.firstOrNull { it.id == clipId } ?: return@updateProject proj
            if (clip.isLocked) return@updateProject proj
            var tracks = proj.tracks
            var preferredTrackId = clip.trackId

            if (verticalTrackDelta != 0) {
                val vTr = tracks.filter { it.kind == TrackKind.VISUAL }
                val idx = vTr.indexOfFirst { it.id == clip.trackId }
                if (idx >= 0) {
                    val targetIdx = idx + verticalTrackDelta
                    preferredTrackId = when {
                        targetIdx < 0 -> vTr.first().id
                        targetIdx >= vTr.size -> {
                            val newTr = TimelineTrack(kind = TrackKind.VISUAL, name = "V${vTr.size + 1}")
                            tracks = insertTrackAboveKind(tracks, TrackKind.VISUAL, newTr)
                            newTr.id
                        }
                        else -> vTr[targetIdx].id
                    }
                }
            }

            val (nextTracks, nextTrackId) = resolveNonOverlappingTrack(tracks, TrackKind.VISUAL, preferredTrackId, snapped, snapped + clip.effectiveDurationMs) { tid ->
                proj.visualClips.filter { it.trackId == tid && it.id != clipId }.map { it.timelineStartMs to it.timelineEndMs }
            }
            proj.copy(tracks = nextTracks, visualClips = proj.visualClips.map { if (it.id == clipId) it.copy(timelineStartMs = snapped, trackId = nextTrackId) else it })
        }
    }

    fun dragTextItem(itemId: String, candidateStartMs: Long, verticalTrackDelta: Int = 0, commitUndo: Boolean = false) {
        val snapped = snapTimeMs(candidateStartMs, excludeId = itemId)
        updateProject(recordUndo = commitUndo, pruneEmpty = commitUndo) { proj ->
            val item = proj.textItems.firstOrNull { it.id == itemId } ?: return@updateProject proj
            if (item.isLocked) return@updateProject proj
            var tracks = proj.tracks
            var preferredTrackId = item.trackId

            if (verticalTrackDelta != 0) {
                val tTr = tracks.filter { it.kind == TrackKind.TEXT }
                val idx = tTr.indexOfFirst { it.id == item.trackId }
                if (idx >= 0) {
                    val targetIdx = idx + verticalTrackDelta
                    preferredTrackId = when {
                        targetIdx < 0 -> tTr.first().id
                        targetIdx >= tTr.size -> {
                            val newTr = TimelineTrack(kind = TrackKind.TEXT, name = "T${tTr.size + 1}")
                            tracks = insertTrackAboveKind(tracks, TrackKind.TEXT, newTr)
                            newTr.id
                        }
                        else -> tTr[targetIdx].id
                    }
                }
            }

            val (nextTracks, nextTrackId) = resolveNonOverlappingTrack(tracks, TrackKind.TEXT, preferredTrackId, snapped, snapped + item.durationMs) { tid ->
                proj.textItems.filter { it.trackId == tid && it.id != itemId }.map { it.timelineStartMs to it.timelineEndMs }
            }
            proj.copy(tracks = nextTracks, textItems = proj.textItems.map { if (it.id == itemId) it.copy(timelineStartMs = snapped, trackId = nextTrackId) else it })
        }
    }

    fun dragAudioClip(clipId: String, candidateStartMs: Long, verticalTrackDelta: Int = 0, commitUndo: Boolean = false) {
        val snapped = snapTimeMs(candidateStartMs, excludeId = clipId)
        updateProject(recordUndo = commitUndo, pruneEmpty = commitUndo) { proj ->
            val clip = proj.audioClips.firstOrNull { it.id == clipId } ?: return@updateProject proj
            if (clip.isLocked) return@updateProject proj
            var tracks = proj.tracks
            var preferredTrackId = clip.trackId

            if (verticalTrackDelta != 0) {
                val aTr = tracks.filter { it.kind == TrackKind.AUDIO }
                val idx = aTr.indexOfFirst { it.id == clip.trackId }
                if (idx >= 0) {
                    val targetIdx = idx + verticalTrackDelta
                    preferredTrackId = when {
                        targetIdx < 0 -> aTr.first().id
                        targetIdx >= aTr.size -> {
                            val newTr = TimelineTrack(kind = TrackKind.AUDIO, name = "A${aTr.size + 1}")
                            tracks = insertTrackAboveKind(tracks, TrackKind.AUDIO, newTr)
                            newTr.id
                        }
                        else -> aTr[targetIdx].id
                    }
                }
            }

            val (nextTracks, nextTrackId) = resolveNonOverlappingTrack(tracks, TrackKind.AUDIO, preferredTrackId, snapped, snapped + clip.effectiveDurationMs) { tid ->
                proj.audioClips.filter { it.trackId == tid && it.id != clipId }.map { it.timelineStartMs to it.timelineEndMs }
            }
            proj.copy(tracks = nextTracks, audioClips = proj.audioClips.map { if (it.id == clipId) it.copy(timelineStartMs = snapped, trackId = nextTrackId) else it })
        }
    }

    fun moveSelectedItemsVerticalTrack(deltaUp: Int) {
        val sel = _selection.value
        if (sel.isEmpty) return
        updateProject { proj ->
            var tracks = proj.tracks
            val nextV = proj.visualClips.map { clip ->
                if (clip.id !in sel.visualClipIds || clip.isLocked) return@map clip
                val vTr = tracks.filter { it.kind == TrackKind.VISUAL }
                val idx = vTr.indexOfFirst { it.id == clip.trackId }
                if (idx < 0) return@map clip
                val tIdx = idx + deltaUp
                val dest = when {
                    tIdx < 0 -> vTr.first().id
                    tIdx >= vTr.size -> { val n = TimelineTrack(kind = TrackKind.VISUAL, name = "V${vTr.size + 1}"); tracks = insertTrackAboveKind(tracks, TrackKind.VISUAL, n); n.id }
                    else -> vTr[tIdx].id
                }
                clip.copy(trackId = dest)
            }
            val nextT = proj.textItems.map { item ->
                if (item.id !in sel.textItemIds || item.isLocked) return@map item
                val tTr = tracks.filter { it.kind == TrackKind.TEXT }
                val idx = tTr.indexOfFirst { it.id == item.trackId }
                if (idx < 0) return@map item
                val tIdx = idx + deltaUp
                val dest = when {
                    tIdx < 0 -> tTr.first().id
                    tIdx >= tTr.size -> { val n = TimelineTrack(kind = TrackKind.TEXT, name = "T${tTr.size + 1}"); tracks = insertTrackAboveKind(tracks, TrackKind.TEXT, n); n.id }
                    else -> tTr[tIdx].id
                }
                item.copy(trackId = dest)
            }
            val nextA = proj.audioClips.map { clip ->
                if (clip.id !in sel.audioClipIds || clip.isLocked) return@map clip
                val aTr = tracks.filter { it.kind == TrackKind.AUDIO }
                val idx = aTr.indexOfFirst { it.id == clip.trackId }
                if (idx < 0) return@map clip
                val tIdx = idx + deltaUp
                val dest = when {
                    tIdx < 0 -> aTr.first().id
                    tIdx >= aTr.size -> { val n = TimelineTrack(kind = TrackKind.AUDIO, name = "A${aTr.size + 1}"); tracks = insertTrackAboveKind(tracks, TrackKind.AUDIO, n); n.id }
                    else -> aTr[tIdx].id
                }
                clip.copy(trackId = dest)
            }
            proj.copy(tracks = tracks, visualClips = nextV, textItems = nextT, audioClips = nextA)
        }
    }

    fun snapTimeMs(candidateMs: Long, excludeId: String? = null): Long {
        val project = _activeProject.value ?: return candidateMs.coerceAtLeast(0L)
        val clamped = candidateMs.coerceAtLeast(0L)
        if (!project.magneticSnapEnabled) return clamped
        val snapThreshold = (150L / _timelineZoom.value).toLong().coerceIn(55L, 240L)
        val pts = mutableListOf(0L, _playheadMs.value)
        project.visualClips.forEach { if (it.id != excludeId) { pts += it.timelineStartMs; pts += it.timelineEndMs } }
        project.textItems.forEach { if (it.id != excludeId) { pts += it.timelineStartMs; pts += it.timelineEndMs } }
        project.audioClips.forEach { if (it.id != excludeId) { pts += it.timelineStartMs; pts += it.timelineEndMs } }
        val nearest = pts.minByOrNull { abs(it - clamped) } ?: return clamped
        return if (abs(nearest - clamped) <= snapThreshold) nearest else clamped
    }

    fun splitSelectedAtPlayhead() {
        val playhead = _playheadMs.value
        primaryVisualClip()?.let { vClip ->
            val local = playhead - vClip.timelineStartMs
            if (local <= 120L || local >= vClip.effectiveDurationMs - 120L) { postMessage("Поставьте курсор внутрь клипа"); return }
            val splitSrc = if (vClip.isImage) vClip.trimStartMs + local else (vClip.trimStartMs + (local * vClip.speed).toLong()).coerceIn(vClip.trimStartMs + 100L, vClip.trimEndMs - 100L)
            val first = vClip.copy(trimEndMs = splitSrc)
            val second = vClip.copy(id = UUID.randomUUID().toString(), trimStartMs = splitSrc, timelineStartMs = playhead, transitionIn = TransitionType.NONE)
            updateProject { p -> p.copy(visualClips = p.visualClips.flatMap { if (it.id == vClip.id) listOf(first, second) else listOf(it) }) }
            selectVisualClip(second.id); return
        }
        primaryAudioClip()?.let { aClip ->
            val local = playhead - aClip.timelineStartMs
            if (local <= 120L || local >= aClip.effectiveDurationMs - 120L) { postMessage("Поставьте курсор внутрь аудио"); return }
            val splitSrc = (aClip.trimStartMs + (local * aClip.speed).toLong()).coerceIn(aClip.trimStartMs + 100L, aClip.trimEndMs - 100L)
            val first = aClip.copy(trimEndMs = splitSrc)
            val second = aClip.copy(id = UUID.randomUUID().toString(), trimStartMs = splitSrc, timelineStartMs = playhead)
            updateProject { p -> p.copy(audioClips = p.audioClips.flatMap { if (it.id == aClip.id) listOf(first, second) else listOf(it) }) }
            selectAudioClip(second.id); return
        }
        primaryTextItem()?.let { tItem ->
            val local = playhead - tItem.timelineStartMs
            if (local <= 150L || local >= tItem.durationMs - 150L) { postMessage("Поставьте курсор внутрь текста"); return }
            val first = tItem.copy(durationMs = local)
            val second = tItem.copy(id = UUID.randomUUID().toString(), timelineStartMs = playhead, durationMs = (tItem.durationMs - local).coerceAtLeast(200L))
            updateProject { p -> p.copy(textItems = p.textItems.flatMap { if (it.id == tItem.id) listOf(first, second) else listOf(it) }) }
            selectTextItem(second.id)
        }
    }

    fun mergeSelectedClips() {
        val proj = _activeProject.value ?: return
        val selV = proj.visualClips.filter { it.id in _selection.value.visualClipIds }.sortedBy { it.timelineStartMs }
        if (selV.size >= 2) {
            val first = selV.first()
            if (selV.all { it.sourceUri == first.sourceUri }) {
                val merged = first.copy(trimStartMs = selV.minOf { it.trimStartMs }, trimEndMs = selV.maxOf { it.trimEndMs })
                val rem = selV.drop(1).map { it.id }.toSet()
                updateProject { p -> p.copy(visualClips = p.visualClips.filterNot { it.id in rem }.map { if (it.id == first.id) merged else it }) }
                selectVisualClip(merged.id); postMessage("Клипы объединены")
            } else {
                var cursor = first.timelineStartMs
                val movedMap = selV.associate { c -> val m = c.copy(trackId = first.trackId, timelineStartMs = cursor); cursor += m.effectiveDurationMs; c.id to m }
                updateProject { p -> p.copy(visualClips = p.visualClips.map { movedMap[it.id] ?: it }) }
                postMessage("Клипы склеены подряд")
            }
            return
        }
        val selA = proj.audioClips.filter { it.id in _selection.value.audioClipIds }.sortedBy { it.timelineStartMs }
        if (selA.size >= 2) {
            val first = selA.first(); var cursor = first.timelineStartMs
            val movedMap = selA.associate { c -> val m = c.copy(trackId = first.trackId, timelineStartMs = cursor); cursor += m.effectiveDurationMs; c.id to m }
            updateProject { p -> p.copy(audioClips = p.audioClips.map { movedMap[it.id] ?: it }) }
            postMessage("Аудио склеены подряд")
        }
    }

    fun copySelected() {
        val proj = _activeProject.value ?: return; val sel = _selection.value
        if (sel.isEmpty) { postMessage("Выберите файл на дорожке"); return }
        clipboard = ClipboardBundle(
            visuals = proj.visualClips.filter { it.id in sel.visualClipIds },
            texts = proj.textItems.filter { it.id in sel.textItemIds },
            audios = proj.audioClips.filter { it.id in sel.audioClipIds }
        )
        _hasClipboard.value = true; postMessage("Скопировано: ${sel.totalSelectedCount}")
    }

    fun pasteClipboardAtPlayhead() {
        val bundle = clipboard ?: run { postMessage("Буфер обмена пуст"); return }
        val playhead = _playheadMs.value
        val baseStart = listOfNotNull(
            bundle.visuals.minOfOrNull { it.timelineStartMs },
            bundle.texts.minOfOrNull { it.timelineStartMs },
            bundle.audios.minOfOrNull { it.timelineStartMs }
        ).minOrNull() ?: 0L
        updateProject { proj ->
            var tracks = proj.tracks
            val newV = mutableListOf<VisualClipItem>()
            for (c in bundle.visuals) {
                val st = (playhead + (c.timelineStartMs - baseStart)).coerceAtLeast(0L)
                val (tr, tid) = resolveNonOverlappingTrack(tracks, TrackKind.VISUAL, c.trackId, st, st + c.effectiveDurationMs) { id -> (proj.visualClips + newV).filter { it.trackId == id }.map { it.timelineStartMs to it.timelineEndMs } }
                tracks = tr; newV += c.copy(id = UUID.randomUUID().toString(), trackId = tid, timelineStartMs = st)
            }
            val newT = mutableListOf<TextTrackItem>()
            for (t in bundle.texts) {
                val st = (playhead + (t.timelineStartMs - baseStart)).coerceAtLeast(0L)
                val (tr, tid) = resolveNonOverlappingTrack(tracks, TrackKind.TEXT, t.trackId, st, st + t.durationMs) { id -> (proj.textItems + newT).filter { it.trackId == id }.map { it.timelineStartMs to it.timelineEndMs } }
                tracks = tr; newT += t.copy(id = UUID.randomUUID().toString(), trackId = tid, timelineStartMs = st)
            }
            val newA = mutableListOf<AudioClipItem>()
            for (a in bundle.audios) {
                val st = (playhead + (a.timelineStartMs - baseStart)).coerceAtLeast(0L)
                val (tr, tid) = resolveNonOverlappingTrack(tracks, TrackKind.AUDIO, a.trackId, st, st + a.effectiveDurationMs) { id -> (proj.audioClips + newA).filter { it.trackId == id }.map { it.timelineStartMs to it.timelineEndMs } }
                tracks = tr; newA += a.copy(id = UUID.randomUUID().toString(), trackId = tid, timelineStartMs = st)
            }
            _selection.value = SelectionState(newV.map { it.id }.toSet(), newT.map { it.id }.toSet(), newA.map { it.id }.toSet(), emptySet(), newV.firstOrNull()?.id ?: newT.firstOrNull()?.id ?: newA.firstOrNull()?.id)
            proj.copy(tracks = tracks, visualClips = proj.visualClips + newV, textItems = proj.textItems + newT, audioClips = proj.audioClips + newA)
        }
        postMessage("Вставлено")
    }

    fun duplicateSelected() {
        val proj = _activeProject.value ?: return; val sel = _selection.value
        if (sel.isEmpty) { postMessage("Выберите файл для дублирования"); return }
        copySelected()
        val endMs = maxOf(
            proj.visualClips.filter { it.id in sel.visualClipIds }.maxOfOrNull { it.timelineEndMs } ?: 0L,
            proj.textItems.filter { it.id in sel.textItemIds }.maxOfOrNull { it.timelineEndMs } ?: 0L,
            proj.audioClips.filter { it.id in sel.audioClipIds }.maxOfOrNull { it.timelineEndMs } ?: 0L
        )
        val savedPh = _playheadMs.value
        _playheadMs.value = endMs
        pasteClipboardAtPlayhead()
        _playheadMs.value = savedPh
    }

    fun deleteSelected() {
        val sel = _selection.value
        if (sel.isEmpty) return
        updateProject { p ->
            p.copy(
                visualClips = p.visualClips.filterNot { it.id in sel.visualClipIds && !it.isLocked },
                textItems = p.textItems.filterNot { it.id in sel.textItemIds && !it.isLocked },
                audioClips = p.audioClips.filterNot { it.id in sel.audioClipIds && !it.isLocked }
            )
        }
        clearSelection()
    }

    fun updatePrimaryVisualClip(recordUndo: Boolean = true, transform: (VisualClipItem) -> VisualClipItem) {
        val target = primaryVisualClip() ?: return
        updateProject(recordUndo) { proj -> proj.copy(visualClips = proj.visualClips.map { if (it.id == target.id && !it.isLocked) transform(it) else it }) }
    }

    fun updateSelectedTransforms(recordUndo: Boolean = false, transform: (TransformState) -> TransformState) {
        val sel = _selection.value; if (sel.isEmpty) return
        val proj = _activeProject.value ?: return
        val (cw, ch) = proj.resolvedDimensions()
        updateProject(recordUndo) { p ->
            val nextV = p.visualClips.map { c -> if (c.id in sel.visualClipIds && !c.isLocked) c.copy(transform = transform(c.transform)) else c }
            val nextT = p.textItems.map { t ->
                if (t.id in sel.textItemIds && !t.isLocked) {
                    val newTf = transform(t.transform)
                    val ov = TextOverlayMapper.toStudioOverlay(t, cw, ch)
                    val updatedOv = ov.copy(
                        offsetX = ov.offsetX + (newTf.offsetX - t.transform.offsetX) * cw,
                        offsetY = ov.offsetY + (newTf.offsetY - t.transform.offsetY) * ch,
                        scaleX = newTf.scaleX, scaleY = newTf.scaleY, rotation = newTf.rotationDeg,
                        flipHorizontal = newTf.flipH, flipVertical = newTf.flipV, opacity = newTf.opacity
                    )
                    TextOverlayMapper.applyStudioOverlay(t.copy(transform = newTf), updatedOv)
                } else t
            }
            p.copy(visualClips = nextV, textItems = nextT)
        }
    }

    fun flipSelectedHorizontal() = updateSelectedTransforms(true) { it.copy(flipH = !it.flipH) }
    fun flipSelectedVertical() = updateSelectedTransforms(true) { it.copy(flipV = !it.flipV) }
    fun resetSelectedTransform() { updateSelectedTransforms(true) { TransformState() }; postMessage("Трансформация сброшена") }

    fun updatePrimaryAudioClip(recordUndo: Boolean = true, transform: (AudioClipItem) -> AudioClipItem) {
        val target = primaryAudioClip() ?: return
        updateProject(recordUndo) { proj -> proj.copy(audioClips = proj.audioClips.map { if (it.id == target.id && !it.isLocked) transform(it) else it }) }
    }

    fun detachAudioFromSelectedClip() {
        val clip = primaryVisualClip() ?: run { postMessage("Выберите видеоклип"); return }
        if (clip.isImage) { postMessage("У фото нет звука"); return }
        viewModelScope.launch {
            val file = AudioExtractorUtil.detachAudioFromVideo(app, clip.activeUri, "audio_${clip.id.take(8)}_${System.currentTimeMillis()}")
            if (file != null) {
                val uriStr = Uri.fromFile(file).toString()
                val wave = WaveformExtractor.extractWaveform(app, uriStr, 56)
                updateProject { proj ->
                    val aTr = proj.tracks.filter { it.kind == TrackKind.AUDIO }
                    val base = aTr.firstOrNull() ?: TimelineTrack(kind = TrackKind.AUDIO, name = "A1")
                    val allTr = if (aTr.isEmpty()) proj.tracks + base else proj.tracks
                    val (nextTr, destId) = resolveNonOverlappingTrack(allTr, TrackKind.AUDIO, base.id, clip.timelineStartMs, clip.timelineEndMs) { tid -> proj.audioClips.filter { it.trackId == tid }.map { it.timelineStartMs to it.timelineEndMs } }
                    val detached = AudioClipItem(trackId = destId, displayName = "Звук: ${clip.displayName}", sourceUri = uriStr, sourceDurationMs = clip.sourceDurationMs, trimStartMs = clip.trimStartMs, trimEndMs = clip.trimEndMs, timelineStartMs = clip.timelineStartMs, volume = clip.volume, speed = clip.speed, waveform = wave)
                    _selection.value = SelectionState(audioClipIds = setOf(detached.id), primaryId = detached.id)
                    proj.copy(tracks = nextTr, visualClips = proj.visualClips.map { if (it.id == clip.id) it.copy(isAudioMuted = true) else it }, audioClips = proj.audioClips + detached)
                }
                _audioSubPanel.value = AudioSubPanel.EDIT
                postMessage("Звук отделён")
            } else postMessage("В видео нет звуковой дорожки")
        }
    }

    fun startVoiceRecording() {
        if (voiceRecorder.startRecording() != null) _isRecordingVoice.value = true else postMessage("Не удалось начать запись")
    }

    fun stopVoiceRecording() {
        val result = voiceRecorder.stopRecording()
        _isRecordingVoice.value = false
        if (result != null) {
            val (file, dur) = result; val startAt = _playheadMs.value
            viewModelScope.launch {
                val uriStr = Uri.fromFile(file).toString()
                val wave = WaveformExtractor.extractWaveform(app, uriStr, 48)
                updateProject { proj ->
                    val aTr = proj.tracks.filter { it.kind == TrackKind.AUDIO }
                    val base = aTr.firstOrNull() ?: TimelineTrack(kind = TrackKind.AUDIO, name = "A1")
                    val allTr = if (aTr.isEmpty()) proj.tracks + base else proj.tracks
                    val (nextTr, destId) = resolveNonOverlappingTrack(allTr, TrackKind.AUDIO, base.id, startAt, startAt + dur) { tid -> proj.audioClips.filter { it.trackId == tid }.map { it.timelineStartMs to it.timelineEndMs } }
                    val voice = AudioClipItem(trackId = destId, displayName = "Голос (${dur / 1000}с)", sourceUri = uriStr, isVoiceover = true, sourceDurationMs = dur, trimStartMs = 0L, trimEndMs = dur, timelineStartMs = startAt, volume = 1f, waveform = wave)
                    _selection.value = SelectionState(audioClipIds = setOf(voice.id), primaryId = voice.id)
                    proj.copy(tracks = nextTr, audioClips = proj.audioClips + voice)
                }
                _audioSubPanel.value = AudioSubPanel.EDIT
                postMessage("Озвучка добавлена")
            }
        }
    }

    fun addStudioText(isSubtitle: Boolean = false) {
        val proj = _activeProject.value ?: return
        val (cw, ch) = proj.resolvedDimensions()
        val startAt = _playheadMs.value; val dur = 4000L
        updateProject { p ->
            val tTr = p.tracks.filter { it.kind == TrackKind.TEXT }
            val base = tTr.firstOrNull() ?: TimelineTrack(kind = TrackKind.TEXT, name = "T1")
            val allTr = if (tTr.isEmpty()) insertTrackAboveKind(p.tracks, TrackKind.VISUAL, base) else p.tracks
            val (nextTr, destId) = resolveNonOverlappingTrack(allTr, TrackKind.TEXT, base.id, startAt, startAt + dur) { tid -> p.textItems.filter { it.trackId == tid }.map { it.timelineStartMs to it.timelineEndMs } }
            val raw = TextTrackItem(trackId = destId, displayName = if (isSubtitle) "Субтитры" else "Новый текст", isSubtitle = isSubtitle, timelineStartMs = startAt, durationMs = dur)
            val finalItem = TextOverlayMapper.applyStudioOverlay(raw, TextOverlayMapper.toStudioOverlay(raw, cw, ch))
            _selection.value = SelectionState(textItemIds = setOf(finalItem.id), primaryId = finalItem.id)
            _editingTextOnCanvasId.value = finalItem.id
            _activeTool.value = EditorToolTab.TEXT
            p.copy(tracks = nextTr, textItems = p.textItems + finalItem)
        }
    }

    fun updatePrimaryTextStyle(newStyle: TextStyleConfig, recordUndo: Boolean) {
        val proj = _activeProject.value ?: return; val target = primaryTextItem() ?: return
        val (cw, ch) = proj.resolvedDimensions()
        val compensated = StudioTextEngine.applyStyleUpdateKeepingPosition(TextOverlayMapper.toStudioOverlay(target, cw, ch), newStyle, cw)
        updateProject(recordUndo) { p -> p.copy(textItems = p.textItems.map { if (it.id == target.id && !it.isLocked) TextOverlayMapper.applyStudioOverlay(it, compensated) else it }) }
    }

    fun translateTextOverlayDoc(itemId: String, dxDoc: Float, dyDoc: Float, commitUndo: Boolean) {
        val proj = _activeProject.value ?: return
        val (cw, ch) = proj.resolvedDimensions()
        updateProject(commitUndo) { p ->
            p.copy(textItems = p.textItems.map { item ->
                if (item.id == itemId && !item.isLocked) {
                    val ov = TextOverlayMapper.toStudioOverlay(item, cw, ch)
                    TextOverlayMapper.applyStudioOverlay(item, ov.copy(offsetX = ov.offsetX + dxDoc, offsetY = ov.offsetY + dyDoc))
                } else item
            })
        }
    }

    fun importCustomFontForPrimaryText(uri: Uri) {
        val target = primaryTextItem() ?: return; val proj = _activeProject.value ?: return
        val (cw, ch) = proj.resolvedDimensions()
        viewModelScope.launch {
            val imported = StudioTextEngine.importCustomFontFromUri(app, uri)
            if (imported != null) {
                val ov = TextOverlayMapper.toStudioOverlay(target, cw, ch)
                updatePrimaryTextStyle(ov.style.copy(customFontPath = imported.first, customFontName = imported.second), true)
                postMessage("Шрифт загружен: ${imported.second}")
            } else postMessage("Ошибка загрузки шрифта")
        }
    }

    fun selectBuiltInFontForPrimaryText(font: LayerFontFamily) {
        val target = primaryTextItem() ?: return; val proj = _activeProject.value ?: return
        val (cw, ch) = proj.resolvedDimensions()
        val ov = TextOverlayMapper.toStudioOverlay(target, cw, ch)
        updatePrimaryTextStyle(ov.style.copy(fontFamily = font, customFontPath = null, customFontName = null), true)
    }

    fun updatePrimaryTextDuration(newDurationMs: Long, recordUndo: Boolean = false) {
        val target = primaryTextItem() ?: return
        updateProject(recordUndo) { p -> p.copy(textItems = p.textItems.map { if (it.id == target.id && !it.isLocked) it.copy(durationMs = newDurationMs.coerceIn(300L, 120_000L)) else it }) }
    }

    fun updateColorGrading(transform: (ColorGradingConfig) -> ColorGradingConfig) {
        if (primaryVisualClip() != null) updatePrimaryVisualClip(false) { it.copy(colorGrading = transform(it.colorGrading)) }
        else updateProject(false) { it.copy(globalColorGrading = transform(it.globalColorGrading)) }
    }

    fun applyColorPreset(preset: ColorPreset) {
        if (primaryVisualClip() != null) updatePrimaryVisualClip(true) { it.copy(colorGrading = it.colorGrading.copy(preset = preset)) }
        else updateProject(true) { it.copy(globalColorGrading = it.globalColorGrading.copy(preset = preset)) }
    }

    fun resetColorGrading() {
        if (primaryVisualClip() != null) updatePrimaryVisualClip(true) { it.copy(colorGrading = ColorGradingConfig()) }
        else updateProject(true) { it.copy(globalColorGrading = ColorGradingConfig()) }
    }

    fun setClipSpeed(speed: Float) = updatePrimaryVisualClip { it.copy(speed = speed.coerceIn(0.25f, 8f), speedRampPoints = emptyList()) }
    fun applySpeedRampPreset(points: List<SpeedRampPoint>) = updatePrimaryVisualClip { it.copy(speedRampPoints = points) }

    fun reverseSelectedVideoClip() {
        val clip = primaryVisualClip() ?: return
        if (clip.isImage || clip.isLocked) return
        if (activeLongTaskJob?.isActive == true) {
            postMessage("Дождитесь завершения текущей операции")
            return
        }
        if (clip.isReversed) {
            viewModelScope.launch {
                val info = MediaProbeUtil.probeMedia(app, clip.sourceUri, MediaKind.VIDEO)
                updatePrimaryVisualClip {
                    it.copy(
                        isReversed = false,
                        sourceDurationMs = info.durationMs,
                        trimStartMs = 0L,
                        trimEndMs = info.durationMs.coerceAtLeast(300L),
                        isAudioMuted = !info.hasAudio
                    )
                }
                postMessage("Реверс отключён")
            }
            return
        }
        activeLongTaskJob = viewModelScope.launch {
            try {
                _reverseProgress.value = 1
                _longTask.value = LongTaskState(
                    title = "Реверс видео",
                    progressPercent = 1,
                    detail = "Подготовка...",
                    targetClipId = clip.id
                )
                val res = VideoReverseProcessor.createReversedClip(
                    context = app,
                    sourceUriString = clip.sourceUri,
                    trimStartMs = clip.trimStartMs,
                    trimEndMs = clip.trimEndMs,
                    targetFps = 30,
                    onProgress = { pct ->
                        _reverseProgress.value = pct
                        _longTask.value = LongTaskState(
                            title = "Реверс видео",
                            progressPercent = pct,
                            detail = "$pct%",
                            targetClipId = clip.id
                        )
                    }
                )
                if (res != null) {
                    updatePrimaryVisualClip {
                        it.copy(
                            reversedUri = Uri.fromFile(res.file).toString(),
                            isReversed = true,
                            sourceDurationMs = res.durationMs,
                            trimStartMs = 0L,
                            trimEndMs = res.durationMs,
                            isAudioMuted = true
                        )
                    }
                    postMessage("Реверс готов")
                } else {
                    postMessage("Не удалось выполнить реверс")
                }
            } finally {
                _reverseProgress.value = null
                _longTask.value = null
                activeLongTaskJob = null
            }
        }
    }

    // ==========================
    // AI BACKGROUND & OBJECT REMOVAL TOOL («Фон»)
    // ==========================

    fun setBgPickingMode(enabled: Boolean) {
        _isPickingBgPoints.value = enabled
        if (enabled) {
            updatePrimaryVisualClip(recordUndo = false) { clip ->
                val cur = clip.backgroundConfig
                val mode = if (cur.mode == BackgroundMode.NONE) BackgroundMode.TRANSPARENT else cur.mode
                clip.copy(backgroundConfig = cur.copy(mode = mode, objectSelectionMode = true))
            }
            if (_isBgModelReady.value) {
                refreshBgPointPreview()
            } else {
                downloadAiModelOnly()
            }
        } else {
            clearPreviewMaskBitmap()
        }
    }

    fun setBgPointPositive(positive: Boolean) {
        _bgPointPositiveMode.value = positive
    }

    fun addBgPointOnSelectedClip(normX: Float, normY: Float) {
        val clip = primaryVisualClip() ?: return
        if (clip.isLocked) return
        val pt = BackgroundPoint(normX.coerceIn(0f, 1f), normY.coerceIn(0f, 1f), _bgPointPositiveMode.value)
        updatePrimaryVisualClip(recordUndo = false) { c ->
            val cur = c.backgroundConfig
            val mode = if (cur.mode == BackgroundMode.NONE) BackgroundMode.TRANSPARENT else cur.mode
            c.copy(backgroundConfig = cur.copy(mode = mode, objectSelectionMode = true, points = cur.points + pt))
        }
        refreshBgPointPreview()
    }

    fun clearBgPoints() {
        updatePrimaryVisualClip(recordUndo = false) { c ->
            c.copy(backgroundConfig = c.backgroundConfig.copy(points = emptyList()))
        }
        clearPreviewMaskBitmap()
    }

    fun updateBgConfig(recordUndo: Boolean = false, transform: (BackgroundConfig) -> BackgroundConfig) {
        updatePrimaryVisualClip(recordUndo = recordUndo) { c ->
            c.copy(backgroundConfig = transform(c.backgroundConfig))
        }
        if (_isPickingBgPoints.value && _isBgModelReady.value) {
            refreshBgPointPreview()
        }
    }

    private fun refreshBgPointPreview() {
        val clip = primaryVisualClip() ?: return
        if (!_isBgModelReady.value) return
        val localMs = (_playheadMs.value - clip.timelineStartMs).coerceIn(0L, clip.effectiveDurationMs)
        val sourceTimeMs = clip.trimStartMs + (localMs * clip.speed).toLong()
        val cfg = clip.backgroundConfig
        previewMaskJob?.cancel()
        previewMaskJob = viewModelScope.launch {
            val bmp = AiBackgroundProcessor.generateLiveMaskPreview(
                context = app,
                sourceUri = clip.rawVideoUri,
                isImage = clip.isImage,
                frameTimeMs = sourceTimeMs,
                config = cfg
            )
            val old = _bgPreviewMask.value
            _bgPreviewMask.value = bmp
            if (old != null && old !== bmp && !old.isRecycled) old.recycle()
        }
    }

    private fun downloadAiModelOnly() {
        if (activeLongTaskJob?.isActive == true) return
        activeLongTaskJob = viewModelScope.launch {
            try {
                _longTask.value = LongTaskState("Загрузка нейросети", 0, "Подключение...")
                val file = AiModelManager.ensureModelDownloaded(app) { pct, detail ->
                    _longTask.value = LongTaskState("Загрузка нейросети", pct, detail)
                }
                _isBgModelReady.value = file != null
                if (file != null) {
                    postMessage("Нейросеть загружена")
                    if (_isPickingBgPoints.value) refreshBgPointPreview()
                } else {
                    postMessage("Не удалось скачать нейросеть — проверьте интернет")
                }
            } finally {
                _longTask.value = null
                activeLongTaskJob = null
            }
        }
    }

    fun applyAutoRemoveBackground() {
        val clip = primaryVisualClip() ?: run { postMessage("Выберите видео или фото"); return }
        if (clip.isLocked) return
        _isPickingBgPoints.value = false
        clearPreviewMaskBitmap()
        val nextCfg = clip.backgroundConfig.let { cur ->
            cur.copy(
                mode = if (cur.mode == BackgroundMode.NONE) BackgroundMode.TRANSPARENT else cur.mode,
                objectSelectionMode = false
            )
        }
        updatePrimaryVisualClip(recordUndo = true) { it.copy(backgroundConfig = nextCfg) }
        runBackgroundProcessingPipeline(clip.id, nextCfg)
    }

    fun applyObjectSelectionBackground() {
        val clip = primaryVisualClip() ?: run { postMessage("Выберите видео или фото"); return }
        if (clip.isLocked) return
        val cur = clip.backgroundConfig
        if (cur.points.isEmpty()) {
            postMessage("Поставьте хотя бы одну точку на объекте")
            return
        }
        _isPickingBgPoints.value = false
        clearPreviewMaskBitmap()
        val nextCfg = cur.copy(
            mode = if (cur.mode == BackgroundMode.NONE) BackgroundMode.TRANSPARENT else cur.mode,
            objectSelectionMode = true
        )
        updatePrimaryVisualClip(recordUndo = true) { it.copy(backgroundConfig = nextCfg) }
        runBackgroundProcessingPipeline(clip.id, nextCfg)
    }

    fun reapplyBackgroundSettings() {
        val clip = primaryVisualClip() ?: return
        if (clip.isLocked) return
        val cur = clip.backgroundConfig
        val nextCfg = cur.copy(mode = if (cur.mode == BackgroundMode.NONE) BackgroundMode.TRANSPARENT else cur.mode)
        updatePrimaryVisualClip(recordUndo = true) { it.copy(backgroundConfig = nextCfg) }
        runBackgroundProcessingPipeline(clip.id, nextCfg)
    }

    fun resetSelectedBackground() {
        _isPickingBgPoints.value = false
        clearPreviewMaskBitmap()
        updatePrimaryVisualClip(recordUndo = true) { clip ->
            clip.copy(
                bgProcessedUri = null,
                bgMaskUri = null,
                backgroundConfig = BackgroundConfig()
            )
        }
        postMessage("Фон восстановлен")
    }

    private fun runBackgroundProcessingPipeline(clipId: String, config: BackgroundConfig) {
        if (activeLongTaskJob?.isActive == true) {
            postMessage("Дождитесь завершения текущей обработки")
            return
        }
        val clip = _activeProject.value?.visualClips?.firstOrNull { it.id == clipId } ?: return
        activeLongTaskJob = viewModelScope.launch {
            try {
                // Step 1: Download high-detail ONNX model once if missing
                if (!AiModelManager.isModelReady(app)) {
                    _longTask.value = LongTaskState("Загрузка нейросети", 0, "Подключение...", targetClipId = clipId)
                    val downloaded = AiModelManager.ensureModelDownloaded(app) { pct, detail ->
                        _longTask.value = LongTaskState("Загрузка нейросети", pct, detail, targetClipId = clipId)
                    }
                    _isBgModelReady.value = downloaded != null
                    if (downloaded == null) {
                        postMessage("Не удалось скачать нейросеть — проверьте интернет")
                        return@launch
                    }
                }

                // Step 2: Process image or full video clip
                val title = if (config.objectSelectionMode) "Выделение объекта" else "Удаление фона"
                _longTask.value = LongTaskState(title, 1, "Запуск...", targetClipId = clipId)

                val result = if (clip.isImage) {
                    AiBackgroundProcessor.processImageBackground(
                        context = app,
                        sourceUri = clip.sourceUri,
                        config = config,
                        onProgress = { pct, detail ->
                            _longTask.value = LongTaskState(title, pct, detail, targetClipId = clipId)
                        }
                    )
                } else {
                    AiBackgroundProcessor.processVideoBackground(
                        context = app,
                        sourceUri = clip.rawVideoUri,
                        trimStartMs = clip.trimStartMs,
                        trimEndMs = clip.trimEndMs,
                        config = config,
                        onProgress = { pct, detail ->
                            _longTask.value = LongTaskState(title, pct, detail, targetClipId = clipId)
                        }
                    )
                }

                if (result != null) {
                    updateProject(recordUndo = true) { proj ->
                        proj.copy(visualClips = proj.visualClips.map { c ->
                            if (c.id == clipId) {
                                c.copy(
                                    bgProcessedUri = result.processedFile?.let { Uri.fromFile(it).toString() },
                                    bgMaskUri = result.maskFile?.let { Uri.fromFile(it).toString() },
                                    backgroundConfig = config
                                )
                            } else c
                        })
                    }
                    postMessage("Обработка фона завершена")
                } else {
                    postMessage("Не удалось обработать фон этого файла")
                }
            } finally {
                _longTask.value = null
                activeLongTaskJob = null
            }
        }
    }

    /**
     * Finds the adjacent pair for a between-clip transition on the same track.
     * Returns the SECOND clip of the pair (where the junction transition applies), or null if no neighbor exists.
     */
    fun findBetweenTransitionTargetClip(project: VideoProject, selected: VisualClipItem): VisualClipItem? {
        val sameTrack = project.visualClips
            .filter { it.trackId == selected.trackId }
            .sortedBy { it.timelineStartMs }
        val idx = sameTrack.indexOfFirst { it.id == selected.id }
        if (idx < 0 || sameTrack.size < 2) return null
        val prev = sameTrack.getOrNull(idx - 1)
        if (prev != null && abs(selected.timelineStartMs - prev.timelineEndMs) <= 350L) {
            return selected
        }
        val next = sameTrack.getOrNull(idx + 1)
        if (next != null && abs(next.timelineStartMs - selected.timelineEndMs) <= 350L) {
            return next
        }
        return null
    }

    fun applyBetweenTransition(targetClipId: String, type: TransitionType, durationMs: Long? = null) {
        updateProject(recordUndo = true) { proj ->
            proj.copy(visualClips = proj.visualClips.map { c ->
                if (c.id == targetClipId && !c.isLocked) {
                    c.copy(
                        transitionIn = type,
                        transitionDurationMs = durationMs ?: c.transitionDurationMs
                    )
                } else c
            })
        }
    }

    fun startExport(config: ExportConfig) {
        val project = _activeProject.value ?: return
        _isPlaying.value = false; _editingTextOnCanvasId.value = null
        viewModelScope.launch { repository.saveProject(project) }
        val (projW, projH) = project.resolvedDimensions()
        val visibleTextTrackIds = project.tracks.filter { it.kind == TrackKind.TEXT && !it.isHidden }.map { it.id }.toSet()
        val trackOrder = project.tracks.mapIndexed { idx, t -> t.id to idx }.toMap()
        val textOverlays = project.textItems.filter { !it.isHidden && it.trackId in visibleTextTrackIds }
            .sortedBy { trackOrder[it.trackId] ?: 0 }
            .map { TextOverlayMapper.toStudioOverlay(it, projW, projH) }
        val drawer: ((Canvas, Int, Int, Long) -> Unit)? = if (textOverlays.isEmpty()) null else { canvas, outW, outH, timeMs ->
            canvas.save()
            canvas.scale(outW.toFloat() / projW.toFloat().coerceAtLeast(1f), outH.toFloat() / projH.toFloat().coerceAtLeast(1f))
            StudioTextEngine.drawOverlaysOnCanvas(canvas, textOverlays, projW, timeMs)
            canvas.restore()
        }
        exportEngine.startExport(project, config, viewModelScope, drawer)
    }

    fun cancelExport() = exportEngine.cancelExport()
    fun resetExportStatus() = exportEngine.resetStatus()

    override fun onCleared() {
        activeLongTaskJob?.cancel(); previewMaskJob?.cancel(); clearPreviewMaskBitmap(); exportEngine.cancelExport(); voiceRecorder.stopRecording(); super.onCleared()
    }
}
