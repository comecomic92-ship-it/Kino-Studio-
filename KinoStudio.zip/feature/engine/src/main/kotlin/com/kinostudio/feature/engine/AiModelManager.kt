package com.kinostudio.feature.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Manages the high-detail ONNX matting neural network (IS-Net 1024x1024, ~178 MB)
 * with one-time in-app download, redirect support, resume/atomic save, and offline reuse.
 */
object AiModelManager {

    private const val MODEL_DIR = "ai_models"
    private const val MODEL_FILENAME = "isnet_hq_matting.onnx"
    private const val MIN_VALID_BYTES = 10L * 1024L * 1024L // 10 MB sanity guard

    private val MODEL_URLS = listOf(
        "https://github.com/danielgatis/rembg/releases/download/v0.0.0/isnet-general-use.onnx",
        "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net.onnx"
    )

    fun getModelFile(context: Context): File {
        val dir = File(context.filesDir, MODEL_DIR).apply { mkdirs() }
        return File(dir, MODEL_FILENAME)
    }

    fun isModelReady(context: Context): Boolean {
        val f = getModelFile(context)
        return f.exists() && f.length() >= MIN_VALID_BYTES
    }

    fun getModelSizeMb(context: Context): Int {
        val f = getModelFile(context)
        return if (f.exists()) (f.length() / (1024L * 1024L)).toInt() else 178
    }

    suspend fun ensureModelDownloaded(
        context: Context,
        onProgress: (percent: Int, detail: String) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        val target = getModelFile(context)
        if (target.exists() && target.length() >= MIN_VALID_BYTES) {
            onProgress(100, "Модель готова")
            return@withContext target
        }

        val partFile = File(target.parentFile, "$MODEL_FILENAME.part")
        for (urlStr in MODEL_URLS) {
            if (partFile.exists()) partFile.delete()
            val ok = runCatching {
                downloadWithRedirects(urlStr, partFile, onProgress)
            }.getOrDefault(false)

            if (ok && partFile.exists() && partFile.length() >= MIN_VALID_BYTES) {
                if (target.exists()) target.delete()
                if (partFile.renameTo(target)) {
                    onProgress(100, "Модель загружена")
                    return@withContext target
                }
            }
            partFile.delete()
        }
        null
    }

    private suspend fun downloadWithRedirects(
        startUrl: String,
        destFile: File,
        onProgress: (Int, String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        var currentUrl = startUrl
        var redirects = 0
        var conn: HttpURLConnection? = null

        try {
            while (redirects < 8) {
                coroutineContext.ensureActive()
                conn?.disconnect()
                val connection = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 20_000
                    readTimeout = 30_000
                    setRequestProperty("User-Agent", "KinoStudio/1.4.0 Android")
                }
                conn = connection
                val code = connection.responseCode
                if (code in 300..399) {
                    val loc = connection.getHeaderField("Location") ?: return@withContext false
                    currentUrl = URL(URL(currentUrl), loc).toString()
                    redirects++
                    continue
                }
                if (code != HttpURLConnection.HTTP_OK) return@withContext false

                val totalBytes = connection.contentLengthLong.coerceAtLeast(1L)
                var downloaded = 0L
                val buf = ByteArray(64 * 1024)
                var lastReportMs = 0L

                connection.inputStream.use { input ->
                    FileOutputStream(destFile).use { out ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val read = input.read(buf)
                            if (read < 0) break
                            out.write(buf, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastReportMs >= 160L) {
                                lastReportMs = now
                                val pct = if (totalBytes > 1L) ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 99) else 0
                                val dlMb = downloaded / (1024 * 1024)
                                val totMb = if (totalBytes > 1L) totalBytes / (1024 * 1024) else 178L
                                onProgress(pct, "$dlMb МБ / $totMb МБ")
                            }
                        }
                    }
                }
                return@withContext downloaded >= MIN_VALID_BYTES
            }
            false
        } finally {
            conn?.disconnect()
        }
    }
}
