package com.kinostudio.feature.engine

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.kinostudio.core.model.MediaKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs

data class ProbedMediaInfo(
    val displayName: String,
    val kind: MediaKind,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val hasAudio: Boolean
)

object MediaProbeUtil {
    suspend fun probeMedia(context: Context, uriString: String, fallbackKind: MediaKind? = null): ProbedMediaInfo = withContext(Dispatchers.IO) {
        val uri = Uri.parse(uriString)
        var name = "Медиафайл"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = cursor.getString(idx) ?: name
                }
            }
        }
        val mime = runCatching { context.contentResolver.getType(uri).orEmpty().lowercase() }.getOrDefault("")
        val lowerName = name.lowercase()
        val detectedKind = when {
            mime.startsWith("image/") || lowerName.endsWith(".png") || lowerName.endsWith(".webp") ||
                lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".gif") ||
                lowerName.endsWith(".heic") || lowerName.endsWith(".bmp") -> MediaKind.IMAGE
            mime.startsWith("audio/") || lowerName.endsWith(".mp3") || lowerName.endsWith(".wav") ||
                lowerName.endsWith(".m4a") || lowerName.endsWith(".aac") || lowerName.endsWith(".ogg") ||
                lowerName.endsWith(".flac") -> MediaKind.AUDIO
            mime.startsWith("video/") -> MediaKind.VIDEO
            fallbackKind != null -> fallbackKind
            else -> MediaKind.VIDEO
        }
        if (detectedKind == MediaKind.IMAGE) {
            var w = 1080; var h = 1080
            runCatching {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (opts.outWidth > 0 && opts.outHeight > 0) { w = opts.outWidth; h = opts.outHeight }
            }
            return@withContext ProbedMediaInfo(name, MediaKind.IMAGE, 4000L, w, h, false)
        }
        val retriever = MediaMetadataRetriever()
        var duration = 5000L; var width = 1920; var height = 1080; var hasAudio = detectedKind == MediaKind.AUDIO
        try {
            retriever.setDataSource(context, uri)
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.coerceAtLeast(200L) ?: 5000L
            if (detectedKind == MediaKind.VIDEO) {
                width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
                height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
                val rot = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rot == 90 || rot == 270) { val t = width; width = height; height = t }
                hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            }
        } catch (_: Throwable) {
        } finally { runCatching { retriever.release() } }
        ProbedMediaInfo(name, detectedKind, duration, width, height, hasAudio)
    }
}

object AudioExtractorUtil {
    suspend fun detachAudioFromVideo(context: Context, videoUriString: String, outputFileName: String): File? = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, "detached_audio").apply { mkdirs() }
        val outFile = File(dir, "$outputFileName.m4a")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(context, Uri.parse(videoUriString), null)
            var audioTrackIndex = -1; var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioTrackIndex = i; audioFormat = fmt; break
                }
            }
            if (audioTrackIndex < 0 || audioFormat == null) return@withContext null
            extractor.selectTrack(audioTrackIndex)
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxTrack = muxer.addTrack(audioFormat)
            muxer.start()
            val buffer = ByteBuffer.allocate(512 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) break
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(muxTrack, buffer, bufferInfo)
                extractor.advance()
            }
            outFile
        } catch (_: Throwable) { outFile.delete(); null } finally {
            runCatching { muxer?.stop() }; runCatching { muxer?.release() }; runCatching { extractor.release() }
        }
    }
}

object WaveformExtractor {
    suspend fun extractWaveform(context: Context, audioUriString: String, barCount: Int = 56): List<Float> = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        val peaks = FloatArray(barCount.coerceAtLeast(8))
        try {
            extractor.setDataSource(context, Uri.parse(audioUriString), null)
            var audioTrack = -1; var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioTrack = i; format = fmt; break
                }
            }
            if (audioTrack < 0 || format == null) return@withContext List(barCount) { 0.35f }
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION).coerceAtLeast(100_000L) else 5_000_000L
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return@withContext List(barCount) { 0.35f }
            extractor.selectTrack(audioTrack)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inputDone = false; var outputDone = false; var budget = 0
            while (!outputDone && budget < 900) {
                budget++
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(5000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sz = extractor.readSampleData(inBuf, 0)
                            if (sz < 0) {
                                codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inIdx, 0, sz, extractor.sampleTime, 0)
                                val stepUs = (durationUs / (barCount * 3L)).coerceAtLeast(0L)
                                if (stepUs > 80_000L) extractor.seekTo(extractor.sampleTime + stepUs, MediaExtractor.SEEK_TO_NEXT_SYNC)
                                else extractor.advance()
                            }
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 5000)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        val bucket = ((info.presentationTimeUs.toFloat() / durationUs.toFloat()) * barCount).toInt().coerceIn(0, peaks.lastIndex)
                        var maxAmp = 0
                        outBuf.position(info.offset); outBuf.limit(info.offset + info.size)
                        while (outBuf.remaining() >= 2) { val s = abs(outBuf.short.toInt()); if (s > maxAmp) maxAmp = s }
                        val norm = (maxAmp / 32767f).coerceIn(0.08f, 1f)
                        if (norm > peaks[bucket]) peaks[bucket] = norm
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                }
            }
            val maxVal = peaks.maxOrNull()?.coerceAtLeast(0.1f) ?: 1f
            peaks.map { (it / maxVal).coerceIn(0.12f, 1f) }
        } catch (_: Throwable) {
            List(barCount) { idx -> 0.25f + 0.55f * ((idx * 37 % 100) / 100f) }
        } finally {
            runCatching { codec?.stop() }; runCatching { codec?.release() }; runCatching { extractor.release() }
        }
    }
}

class VoiceRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var currentFile: File? = null
    private var startedAtMs: Long = 0L

    fun startRecording(): File? {
        stopRecording()
        val dir = File(context.filesDir, "voiceovers").apply { mkdirs() }
        val file = File(dir, "voice_${System.currentTimeMillis()}.m4a")
        return runCatching {
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) MediaRecorder(context)
            else { @Suppress("DEPRECATION") MediaRecorder() }
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(192_000)
            rec.setAudioSamplingRate(48_000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare(); rec.start()
            recorder = rec; currentFile = file; startedAtMs = System.currentTimeMillis()
            file
        }.onFailure { file.delete() }.getOrNull()
    }

    fun stopRecording(): Pair<File, Long>? {
        val rec = recorder ?: return null
        val file = currentFile
        val duration = (System.currentTimeMillis() - startedAtMs).coerceAtLeast(300L)
        recorder = null; currentFile = null
        return runCatching {
            rec.stop(); rec.release()
            if (file != null && file.exists() && file.length() > 0L) file to duration else null
        }.onFailure { runCatching { rec.release() }; file?.delete() }.getOrNull()
    }

    fun isRecording(): Boolean = recorder != null
}
