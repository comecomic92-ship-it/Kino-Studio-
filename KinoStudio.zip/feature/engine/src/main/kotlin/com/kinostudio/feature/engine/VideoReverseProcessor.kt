package com.kinostudio.feature.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * True frame-accurate 30 FPS video reverser:
 *  Phase 1: Hardware MediaExtractor + MediaCodec decodes every frame in [trimStartMs..trimEndMs]
 *           sequentially (no keyframe-only 2 FPS MediaMetadataRetriever stutter!) into temp JPEG files.
 *  Phase 2: Re-encodes frames in strict reverse order (N-1..0) with explicit monotonic 30 FPS PTS
 *           so MediaMuxer writes a silky-smooth, truly reversed MP4 without wall-clock PTS bugs.
 */
object VideoReverseProcessor {

    data class ReverseResult(
        val file: File,
        val durationMs: Long
    )

    suspend fun createReversedClip(
        context: Context,
        sourceUriString: String,
        trimStartMs: Long,
        trimEndMs: Long,
        targetFps: Int = 30,
        onProgress: (Int) -> Unit = {}
    ): ReverseResult? = withContext(Dispatchers.IO) {
        val outDir = File(context.cacheDir, "reversed_clips").apply { mkdirs() }
        val outFile = File(outDir, "rev_${System.currentTimeMillis()}.mp4")
        val framesDir = File(context.cacheDir, "rev_frames_${System.currentTimeMillis()}").apply { mkdirs() }

        var rotationDeg = 0
        var srcWidth = 1280
        var srcHeight = 720
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(sourceUriString))
            srcWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            srcHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            rotationDeg = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } catch (_: Throwable) {
        } finally {
            runCatching { retriever.release() }
        }

        val frameFiles = mutableListOf<File>()
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null

        try {
            // ================= PHASE 1: FAST SEQUENTIAL HARDWARE DECODE =================
            extractor.setDataSource(context, Uri.parse(sourceUriString), null)
            var videoTrack = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    videoTrack = i
                    trackFormat = fmt
                    break
                }
            }
            if (videoTrack < 0 || trackFormat == null) return@withContext null

            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: return@withContext null
            if (trackFormat.containsKey(MediaFormat.KEY_ROTATION)) {
                rotationDeg = trackFormat.getInteger(MediaFormat.KEY_ROTATION)
            }
            trackFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )

            extractor.selectTrack(videoTrack)
            val startUs = trimStartMs.coerceAtLeast(0L) * 1000L
            val endUs = trimEndMs.coerceAtLeast(trimStartMs + 200L) * 1000L
            val spanUs = (endUs - startUs).coerceAtLeast(200_000L)
            val minStepUs = (1_000_000L / targetFps) - 4_000L

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(trackFormat, null, null, 0)
            decoder.start()

            val decInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastSavedPtsUs = Long.MIN_VALUE
            var decodedCount = 0

            while (!outputDone && frameFiles.size < 900) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val inBuf = decoder.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sz = extractor.readSampleData(inBuf, 0)
                            val pts = extractor.sampleTime
                            if (sz < 0 || pts > endUs + 500_000L) {
                                decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inIdx, 0, sz, pts, extractor.sampleFlags)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = decoder.dequeueOutputBuffer(decInfo, 10_000L)
                if (outIdx >= 0) {
                    val ptsUs = decInfo.presentationTimeUs
                    val shouldCapture = decInfo.size > 0 &&
                        ptsUs in startUs..endUs &&
                        (lastSavedPtsUs == Long.MIN_VALUE || (ptsUs - lastSavedPtsUs) >= minStepUs)

                    if (shouldCapture) {
                        val image = runCatching { decoder.getOutputImage(outIdx) }.getOrNull()
                        if (image != null) {
                            try {
                                val f = File(framesDir, String.format("f_%05d.jpg", frameFiles.size))
                                if (saveYuvImageToJpeg(image, f)) {
                                    frameFiles += f
                                    lastSavedPtsUs = ptsUs
                                    decodedCount++
                                }
                            } finally {
                                image.close()
                            }
                        }
                        val pct = (((ptsUs - startUs).toFloat() / spanUs.toFloat()) * 48f).toInt().coerceIn(1, 48)
                        onProgress(pct)
                    }
                    decoder.releaseOutputBuffer(outIdx, false)
                    if ((decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || ptsUs > endUs) {
                        outputDone = true
                    }
                }
            }

            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            decoder = null
            runCatching { extractor.release() }

            if (frameFiles.size < 2) {
                outFile.delete()
                return@withContext null
            }

            // ================= PHASE 2: STRICT REVERSE ENCODE AT EXACT 30 FPS =================
            val firstBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(frameFiles.first().absolutePath, firstBounds)
            val rawW = if (firstBounds.outWidth > 0) firstBounds.outWidth else srcWidth
            val rawH = if (firstBounds.outHeight > 0) firstBounds.outHeight else srcHeight

            var outW = if (rotationDeg == 90 || rotationDeg == 270) rawH else rawW
            var outH = if (rotationDeg == 90 || rotationDeg == 270) rawW else rawH
            val scaleDown = minOf(1f, 1080f / maxOf(outW, outH).toFloat())
            outW = ((outW * scaleDown).toInt() / 2) * 2
            outH = ((outH * scaleDown).toInt() / 2) * 2
            if (outW < 64) outW = 640
            if (outH < 64) outH = 360

            val actualFps = ((frameFiles.size.toDouble() / (spanUs / 1_000_000.0)).toInt()).coerceIn(15, targetFps)
            val frameStepUs = 1_000_000L / actualFps

            val encFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 12_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, actualFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var muxTrack = -1
            var muxerStarted = false
            var emittedFrames = 0L
            val encInfo = MediaCodec.BufferInfo()
            val dstRect = Rect(0, 0, outW, outH)

            val total = frameFiles.size
            for (revIdx in 0 until total) {
                coroutineContext.ensureActive()
                val file = frameFiles[total - 1 - revIdx]
                val rawBmp = BitmapFactory.decodeFile(file.absolutePath)
                if (rawBmp != null) {
                    val bmpToDraw = if (rotationDeg != 0) {
                        val m = Matrix().apply { postRotate(rotationDeg.toFloat()) }
                        val rotated = Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, m, true)
                        if (rotated !== rawBmp) rawBmp.recycle()
                        rotated
                    } else rawBmp

                    val canvas = inputSurface.lockHardwareCanvas()
                    try {
                        canvas.drawBitmap(bmpToDraw, null, dstRect, null)
                    } finally {
                        inputSurface.unlockCanvasAndPost(canvas)
                    }
                    bmpToDraw.recycle()
                }

                emittedFrames = drainEncoderStrictPts(
                    encoder = encoder,
                    muxer = muxer,
                    bufferInfo = encInfo,
                    endOfStream = false,
                    onFormatChanged = { fmt ->
                        muxTrack = muxer.addTrack(fmt)
                        muxer.start()
                        muxerStarted = true
                    },
                    isMuxerStarted = { muxerStarted },
                    trackIndex = { muxTrack },
                    emittedCount = emittedFrames,
                    frameStepUs = frameStepUs
                )
                onProgress(50 + (((revIdx + 1) * 50) / total))
            }

            encoder.signalEndOfInputStream()
            emittedFrames = drainEncoderStrictPts(
                encoder = encoder,
                muxer = muxer,
                bufferInfo = encInfo,
                endOfStream = true,
                onFormatChanged = { fmt ->
                    if (!muxerStarted) {
                        muxTrack = muxer.addTrack(fmt)
                        muxer.start()
                        muxerStarted = true
                    }
                },
                isMuxerStarted = { muxerStarted },
                trackIndex = { muxTrack },
                emittedCount = emittedFrames,
                frameStepUs = frameStepUs
            )

            val finalDurationMs = ((emittedFrames * frameStepUs) / 1000L).coerceAtLeast(300L)
            ReverseResult(outFile, finalDurationMs)
        } catch (_: Throwable) {
            outFile.delete()
            null
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            runCatching { extractor.release() }
            runCatching { inputSurface?.release() }
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { framesDir.deleteRecursively() }
        }
    }

    private fun saveYuvImageToJpeg(image: Image, outFile: File): Boolean {
        return runCatching {
            val width = image.width
            val height = image.height
            val nv21 = yuv420ToNv21(image)
            FileOutputStream(outFile).use { fos ->
                YuvImage(nv21, ImageFormat.NV21, width, height, null)
                    .compressToJpeg(Rect(0, 0, width, height), 88, fos)
            }
            true
        }.getOrDefault(false)
    }

    private fun yuv420ToNv21(image: Image): ByteArray {
        val width = image.width
        val height = image.height
        val ySize = width * height
        val out = ByteArray(ySize + (ySize / 2))

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuf = yPlane.buffer
        val yRowStride = yPlane.rowStride
        val yPixStride = yPlane.pixelStride
        var pos = 0
        for (row in 0 until height) {
            val rowStart = row * yRowStride
            if (yPixStride == 1) {
                yBuf.position(rowStart)
                yBuf.get(out, pos, width)
                pos += width
            } else {
                for (col in 0 until width) {
                    out[pos++] = yBuf.get(rowStart + col * yPixStride)
                }
            }
        }

        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val uRowStride = uPlane.rowStride
        val vRowStride = vPlane.rowStride
        val uPixStride = uPlane.pixelStride
        val vPixStride = vPlane.pixelStride
        val chromaH = height / 2
        val chromaW = width / 2

        for (row in 0 until chromaH) {
            val vRowStart = row * vRowStride
            val uRowStart = row * uRowStride
            for (col in 0 until chromaW) {
                out[pos++] = vBuf.get(vRowStart + col * vPixStride)
                out[pos++] = uBuf.get(uRowStart + col * uPixStride)
            }
        }
        return out
    }

    private fun drainEncoderStrictPts(
        encoder: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onFormatChanged: (MediaFormat) -> Unit,
        isMuxerStarted: () -> Boolean,
        trackIndex: () -> Int,
        emittedCount: Long,
        frameStepUs: Long
    ): Long {
        var count = emittedCount
        while (true) {
            val outIdx = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            when {
                outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) break
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormatChanged(encoder.outputFormat)
                outIdx >= 0 -> {
                    val data = encoder.getOutputBuffer(outIdx)
                    if (data != null && bufferInfo.size > 0 && isMuxerStarted() &&
                        (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                    ) {
                        data.position(bufferInfo.offset)
                        data.limit(bufferInfo.offset + bufferInfo.size)
                        // ALWAYS force exact monotonic PTS (fixes wall-clock 2 FPS Surface bug!)
                        bufferInfo.presentationTimeUs = count * frameStepUs
                        muxer.writeSampleData(trackIndex(), data, bufferInfo)
                        count++
                    }
                    encoder.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
        }
        return count
    }
}
