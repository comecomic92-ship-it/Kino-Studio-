package com.kinostudio.feature.engine

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class VolumeFadeAudioProcessor(
    private val volume: Float,
    private val fadeInMs: Long,
    private val fadeOutMs: Long,
    private val totalDurationMs: Long
) : BaseAudioProcessor() {
    private var processedFrames: Long = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val outputBuffer = replaceOutputBuffer(remaining)
        val channels = inputAudioFormat.channelCount.coerceAtLeast(1)
        val sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(1)
        val frameCount = remaining / (channels * 2)
        for (frame in 0 until frameCount) {
            val currentMs = ((processedFrames + frame) * 1000L) / sampleRate
            var gain = volume.coerceIn(0f, 2f)
            if (fadeInMs > 0L && currentMs < fadeInMs) gain *= (currentMs.toFloat() / fadeInMs.toFloat()).coerceIn(0f, 1f)
            if (fadeOutMs > 0L && totalDurationMs > fadeOutMs) {
                val fadeOutStart = totalDurationMs - fadeOutMs
                if (currentMs > fadeOutStart) gain *= ((totalDurationMs - currentMs).coerceAtLeast(0L).toFloat() / fadeOutMs.toFloat()).coerceIn(0f, 1f)
            }
            for (ch in 0 until channels) {
                val scaled = (inputBuffer.short.toInt() * gain).roundToInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                outputBuffer.putShort(scaled.toShort())
            }
        }
        while (inputBuffer.hasRemaining()) outputBuffer.put(inputBuffer.get())
        processedFrames += frameCount
        outputBuffer.flip()
    }

    override fun onFlush() { processedFrames = 0L }
    override fun onReset() { processedFrames = 0L }
}
