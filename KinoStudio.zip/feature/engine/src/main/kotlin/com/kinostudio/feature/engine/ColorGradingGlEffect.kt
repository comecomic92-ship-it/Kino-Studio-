package com.kinostudio.feature.engine

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import com.kinostudio.core.model.ClipEdgeEffect
import com.kinostudio.core.model.ColorGradingConfig
import com.kinostudio.core.model.TransitionType
import kotlin.math.pow

@OptIn(UnstableApi::class)
class ColorGradingGlEffect(
    private val config: ColorGradingConfig,
    private val clipOpacity: Float = 1f,
    private val clipDurationMs: Long = 5000L,
    private val transitionIn: TransitionType = TransitionType.NONE,
    private val transitionDurationMs: Long = 500L,
    private val edgeEffectIn: ClipEdgeEffect = ClipEdgeEffect.NONE,
    private val edgeEffectInMs: Long = 500L,
    private val edgeEffectOut: ClipEdgeEffect = ClipEdgeEffect.NONE,
    private val edgeEffectOutMs: Long = 500L
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return ColorGradingShaderProgram(
            config = ColorMatrixUtil.resolvePreset(config),
            clipOpacity = clipOpacity,
            clipDurationMs = clipDurationMs.coerceAtLeast(200L),
            transitionIn = transitionIn,
            transitionDurationMs = transitionDurationMs,
            edgeEffectIn = edgeEffectIn,
            edgeEffectInMs = edgeEffectInMs,
            edgeEffectOut = edgeEffectOut,
            edgeEffectOutMs = edgeEffectOutMs,
            useHdr = useHdr
        )
    }
}

@OptIn(UnstableApi::class)
private class ColorGradingShaderProgram(
    private val config: ColorGradingConfig,
    private val clipOpacity: Float,
    private val clipDurationMs: Long,
    private val transitionIn: TransitionType,
    private val transitionDurationMs: Long,
    private val edgeEffectIn: ClipEdgeEffect,
    private val edgeEffectInMs: Long,
    private val edgeEffectOut: ClipEdgeEffect,
    private val edgeEffectOutMs: Long,
    useHdr: Boolean
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
    private var frameWidth = 1920
    private var frameHeight = 1080
    private var firstPtsUs: Long = C.TIME_UNSET

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        frameWidth = inputWidth.coerceAtLeast(1)
        frameHeight = inputHeight.coerceAtLeast(1)
        return Size(frameWidth, frameHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        if (firstPtsUs == C.TIME_UNSET) firstPtsUs = presentationTimeUs
        val localMs = ((presentationTimeUs - firstPtsUs) / 1000L).coerceAtLeast(0L)
        val remainingMs = (clipDurationMs - localMs).coerceAtLeast(0L)

        // Compute effective alpha, zoom, slideX, and flash across between-clip transition + start/end edge effects
        var alphaMul = clipOpacity.coerceIn(0f, 1f)
        var zoomFactor = 1f
        var slideX = 0f
        var flashAdd = 0f

        // 1. Between-clip transition at clip start
        if (transitionIn != TransitionType.NONE && transitionDurationMs > 0L && localMs < transitionDurationMs) {
            val t = (localMs.toFloat() / transitionDurationMs.toFloat()).coerceIn(0f, 1f)
            when (transitionIn) {
                TransitionType.NONE -> Unit
                TransitionType.FADE_BLACK, TransitionType.CROSS_DISSOLVE -> alphaMul *= t
                TransitionType.SLIDE_LEFT -> slideX += (1f - t)
                TransitionType.SLIDE_RIGHT -> slideX -= (1f - t)
                TransitionType.ZOOM_IN -> { zoomFactor *= (1.35f - 0.35f * t); alphaMul *= t }
                TransitionType.FLASH -> flashAdd += (1f - t)
            }
        }

        // 2. Separate Start Edge Effect
        if (edgeEffectIn != ClipEdgeEffect.NONE && edgeEffectInMs > 0L && localMs < edgeEffectInMs) {
            val t = (localMs.toFloat() / edgeEffectInMs.toFloat()).coerceIn(0f, 1f)
            when (edgeEffectIn) {
                ClipEdgeEffect.NONE -> Unit
                ClipEdgeEffect.FADE -> alphaMul *= t
                ClipEdgeEffect.ZOOM -> { zoomFactor *= (1.30f - 0.30f * t); alphaMul *= t }
                ClipEdgeEffect.SLIDE -> slideX += (1f - t)
                ClipEdgeEffect.FLASH -> flashAdd += (1f - t)
            }
        }

        // 3. Separate End Edge Effect
        if (edgeEffectOut != ClipEdgeEffect.NONE && edgeEffectOutMs > 0L && remainingMs < edgeEffectOutMs) {
            val t = (remainingMs.toFloat() / edgeEffectOutMs.toFloat()).coerceIn(0f, 1f)
            when (edgeEffectOut) {
                ClipEdgeEffect.NONE -> Unit
                ClipEdgeEffect.FADE -> alphaMul *= t
                ClipEdgeEffect.ZOOM -> { zoomFactor *= (1.30f - 0.30f * t); alphaMul *= t }
                ClipEdgeEffect.SLIDE -> slideX -= (1f - t)
                ClipEdgeEffect.FLASH -> flashAdd += (1f - t)
            }
        }

        glProgram.use()
        glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
        glProgram.setBufferAttribute("aFramePosition", FULL_FRAME_VERTICES, 4)
        glProgram.setBufferAttribute("aTexSamplingCoord", FULL_TEX_COORDS, 4)
        glProgram.setFloatUniform("uBrightness", config.brightness)
        glProgram.setFloatUniform("uContrast", config.contrast)
        glProgram.setFloatUniform("uExposureMul", 2.0.pow(config.exposure.toDouble()).toFloat())
        glProgram.setFloatUniform("uSaturation", config.saturation)
        glProgram.setFloatUniform("uTemperature", config.temperature)
        glProgram.setFloatUniform("uTint", config.tint)
        glProgram.setFloatUniform("uHighlights", config.highlights)
        glProgram.setFloatUniform("uShadows", config.shadows)
        glProgram.setFloatUniform("uSharpen", config.sharpen)
        glProgram.setFloatUniform("uVignette", config.vignette)
        glProgram.setFloatUniform("uHslHue", config.hslHue / 360f)
        glProgram.setFloatUniform("uHslSat", config.hslSaturation)
        glProgram.setFloatUniform("uHslLum", config.hslLuminance)
        glProgram.setFloatsUniform("uRgbGain", floatArrayOf(config.rgbRedGain, config.rgbGreenGain, config.rgbBlueGain))
        glProgram.setFloatsUniform("uTexelSize", floatArrayOf(1f / frameWidth, 1f / frameHeight))
        glProgram.setFloatUniform("uOpacity", alphaMul.coerceIn(0f, 1f))
        glProgram.setFloatUniform("uZoom", zoomFactor.coerceIn(0.5f, 2.5f))
        glProgram.setFloatUniform("uSlideX", slideX.coerceIn(-1f, 1f))
        glProgram.setFloatUniform("uFlash", flashAdd.coerceIn(0f, 1f))
        glProgram.bindAttributesAndUniforms()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GlUtil.checkGlError()
    }

    override fun release() {
        super.release()
        glProgram.delete()
    }

    companion object {
        private val FULL_FRAME_VERTICES = floatArrayOf(-1f, -1f, 0f, 1f, 1f, -1f, 0f, 1f, -1f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
        private val FULL_TEX_COORDS = floatArrayOf(0f, 0f, 0f, 1f, 1f, 0f, 0f, 1f, 0f, 1f, 0f, 1f, 1f, 1f, 0f, 1f)
        private val VERTEX_SHADER = """
attribute vec4 aFramePosition;
attribute vec4 aTexSamplingCoord;
varying vec2 vTexCoord;
void main() {
    gl_Position = aFramePosition;
    vTexCoord = aTexSamplingCoord.xy;
}
""".trimIndent()

        private val FRAGMENT_SHADER = """
precision mediump float;
uniform sampler2D uTexSampler;
uniform float uBrightness;
uniform float uContrast;
uniform float uExposureMul;
uniform float uSaturation;
uniform float uTemperature;
uniform float uTint;
uniform float uHighlights;
uniform float uShadows;
uniform float uSharpen;
uniform float uVignette;
uniform float uHslHue;
uniform float uHslSat;
uniform float uHslLum;
uniform vec3 uRgbGain;
uniform vec2 uTexelSize;
uniform float uOpacity;
uniform float uZoom;
uniform float uSlideX;
uniform float uFlash;
varying vec2 vTexCoord;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main() {
    vec2 uv = (vTexCoord - 0.5) / uZoom + 0.5;
    uv.x += uSlideX;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    vec4 baseSample = texture2D(uTexSampler, uv);
    vec3 color = baseSample.rgb;
    if (uSharpen > 0.005) {
        vec3 n1 = texture2D(uTexSampler, clamp(uv + vec2(uTexelSize.x, 0.0), 0.0, 1.0)).rgb;
        vec3 n2 = texture2D(uTexSampler, clamp(uv - vec2(uTexelSize.x, 0.0), 0.0, 1.0)).rgb;
        vec3 n3 = texture2D(uTexSampler, clamp(uv + vec2(0.0, uTexelSize.y), 0.0, 1.0)).rgb;
        vec3 n4 = texture2D(uTexSampler, clamp(uv - vec2(0.0, uTexelSize.y), 0.0, 1.0)).rgb;
        color = color + (color * 4.0 - (n1 + n2 + n3 + n4)) * (uSharpen * 0.45);
    }
    color *= uExposureMul;
    color *= uRgbGain;
    color.r += uTemperature * 0.14;
    color.b -= uTemperature * 0.14;
    color.g += uTint * 0.10;
    color += uBrightness * 0.45;
    color = (color - 0.5) * uContrast + 0.5;
    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    color += clamp(1.0 - luma * 2.0, 0.0, 1.0) * uShadows * 0.30;
    color += clamp((luma - 0.5) * 2.0, 0.0, 1.0) * uHighlights * 0.30;
    float lumAfter = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(lumAfter), color, uSaturation);
    if (abs(uHslHue) > 0.001 || abs(uHslSat) > 0.001 || abs(uHslLum) > 0.001) {
        vec3 hsv = rgb2hsv(clamp(color, 0.0, 1.0));
        hsv.x = fract(hsv.x + uHslHue);
        hsv.y = clamp(hsv.y + uHslSat * 0.5, 0.0, 1.0);
        hsv.z = clamp(hsv.z + uHslLum * 0.35, 0.0, 1.0);
        color = hsv2rgb(hsv);
    }
    if (uVignette > 0.005) {
        float dist = distance(vTexCoord, vec2(0.5, 0.5));
        float vig = smoothstep(0.85, 0.25, dist * (1.0 + uVignette * 0.9));
        color *= mix(1.0, vig, uVignette);
    }
    color = clamp(color + vec3(uFlash), 0.0, 1.0) * uOpacity;
    gl_FragColor = vec4(color, baseSample.a);
}
""".trimIndent()
    }
}
