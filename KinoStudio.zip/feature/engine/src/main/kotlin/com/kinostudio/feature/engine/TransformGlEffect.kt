package com.kinostudio.feature.engine

import android.graphics.Matrix
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation
import com.kinostudio.core.model.TransformState

@OptIn(UnstableApi::class)
class TransformMatrixEffect(private val transform: TransformState) : MatrixTransformation {
    private val cachedMatrix: Matrix = Matrix().apply {
        if (transform.hasPerspective()) {
            val src = floatArrayOf(-1f, 1f, 1f, 1f, -1f, -1f, 1f, -1f)
            val dst = floatArrayOf(
                -1f + transform.tlX.coerceIn(-0.38f, 0.38f) * 2f,  1f - transform.tlY.coerceIn(-0.38f, 0.38f) * 2f,
                 1f + transform.trX.coerceIn(-0.38f, 0.38f) * 2f,  1f - transform.trY.coerceIn(-0.38f, 0.38f) * 2f,
                -1f + transform.blX.coerceIn(-0.38f, 0.38f) * 2f, -1f - transform.blY.coerceIn(-0.38f, 0.38f) * 2f,
                 1f + transform.brX.coerceIn(-0.38f, 0.38f) * 2f, -1f - transform.brY.coerceIn(-0.38f, 0.38f) * 2f
            )
            val poly = Matrix()
            if (poly.setPolyToPoly(src, 0, dst, 0, 4)) {
                set(poly)
            }
        }
        val sx = transform.scaleX.coerceIn(0.1f, 5f) * if (transform.flipH) -1f else 1f
        val sy = transform.scaleY.coerceIn(0.1f, 5f) * if (transform.flipV) -1f else 1f
        postScale(sx, sy)
        postRotate(-transform.rotationDeg)
        postTranslate(transform.offsetX * 2f, -transform.offsetY * 2f)
    }

    override fun getMatrix(presentationTimeUs: Long): Matrix = Matrix(cachedMatrix)
}
