package com.kinostudio.feature.engine

import android.graphics.ColorMatrix
import com.kinostudio.core.model.ColorGradingConfig
import com.kinostudio.core.model.ColorPreset
import kotlin.math.abs
import kotlin.math.pow

object ColorMatrixUtil {

    fun merge(global: ColorGradingConfig, clip: ColorGradingConfig): ColorGradingConfig = ColorGradingConfig(
        brightness = (global.brightness + clip.brightness).coerceIn(-1f, 1f),
        contrast = (global.contrast * clip.contrast).coerceIn(0f, 2f),
        exposure = (global.exposure + clip.exposure).coerceIn(-2f, 2f),
        saturation = (global.saturation * clip.saturation).coerceIn(0f, 2f),
        temperature = (global.temperature + clip.temperature).coerceIn(-1f, 1f),
        tint = (global.tint + clip.tint).coerceIn(-1f, 1f),
        highlights = (global.highlights + clip.highlights).coerceIn(-1f, 1f),
        shadows = (global.shadows + clip.shadows).coerceIn(-1f, 1f),
        sharpen = (global.sharpen + clip.sharpen).coerceIn(0f, 1f),
        vignette = (global.vignette + clip.vignette).coerceIn(0f, 1f),
        hslHue = (global.hslHue + clip.hslHue).coerceIn(-180f, 180f),
        hslSaturation = (global.hslSaturation + clip.hslSaturation).coerceIn(-1f, 1f),
        hslLuminance = (global.hslLuminance + clip.hslLuminance).coerceIn(-1f, 1f),
        rgbRedGain = (global.rgbRedGain * clip.rgbRedGain).coerceIn(0.5f, 1.5f),
        rgbGreenGain = (global.rgbGreenGain * clip.rgbGreenGain).coerceIn(0.5f, 1.5f),
        rgbBlueGain = (global.rgbBlueGain * clip.rgbBlueGain).coerceIn(0.5f, 1.5f),
        preset = if (clip.preset != ColorPreset.NONE) clip.preset else global.preset
    )

    fun resolvePreset(base: ColorGradingConfig): ColorGradingConfig = when (base.preset) {
        ColorPreset.NONE -> base
        ColorPreset.CINEMATIC -> base.copy(
            contrast = (base.contrast * 1.14f).coerceIn(0f, 2f),
            saturation = (base.saturation * 0.90f).coerceIn(0f, 2f),
            shadows = (base.shadows - 0.12f).coerceIn(-1f, 1f),
            vignette = (base.vignette + 0.25f).coerceIn(0f, 1f),
            temperature = (base.temperature + 0.06f).coerceIn(-1f, 1f)
        )
        ColorPreset.TEAL_ORANGE -> base.copy(
            contrast = (base.contrast * 1.12f).coerceIn(0f, 2f),
            saturation = (base.saturation * 1.15f).coerceIn(0f, 2f),
            rgbRedGain = (base.rgbRedGain * 1.08f).coerceIn(0.5f, 1.5f),
            rgbBlueGain = (base.rgbBlueGain * 1.05f).coerceIn(0.5f, 1.5f),
            temperature = (base.temperature + 0.14f).coerceIn(-1f, 1f),
            tint = (base.tint - 0.08f).coerceIn(-1f, 1f)
        )
        ColorPreset.VIVID -> base.copy(
            contrast = (base.contrast * 1.18f).coerceIn(0f, 2f),
            saturation = (base.saturation * 1.32f).coerceIn(0f, 2f),
            sharpen = (base.sharpen + 0.25f).coerceIn(0f, 1f)
        )
        ColorPreset.MOODY -> base.copy(
            exposure = (base.exposure - 0.25f).coerceIn(-2f, 2f),
            contrast = (base.contrast * 1.22f).coerceIn(0f, 2f),
            saturation = (base.saturation * 0.72f).coerceIn(0f, 2f),
            vignette = (base.vignette + 0.35f).coerceIn(0f, 1f)
        )
        ColorPreset.VINTAGE -> base.copy(
            contrast = (base.contrast * 0.92f).coerceIn(0f, 2f),
            saturation = (base.saturation * 0.78f).coerceIn(0f, 2f),
            temperature = (base.temperature + 0.22f).coerceIn(-1f, 1f),
            shadows = (base.shadows + 0.18f).coerceIn(-1f, 1f),
            vignette = (base.vignette + 0.30f).coerceIn(0f, 1f)
        )
        ColorPreset.NOIR -> base.copy(
            saturation = 0f,
            contrast = (base.contrast * 1.35f).coerceIn(0f, 2f),
            vignette = (base.vignette + 0.30f).coerceIn(0f, 1f)
        )
        ColorPreset.WARM_SUNSET -> base.copy(
            temperature = (base.temperature + 0.32f).coerceIn(-1f, 1f),
            tint = (base.tint + 0.10f).coerceIn(-1f, 1f),
            saturation = (base.saturation * 1.15f).coerceIn(0f, 2f)
        )
        ColorPreset.COLD_ARCTIC -> base.copy(
            temperature = (base.temperature - 0.32f).coerceIn(-1f, 1f),
            contrast = (base.contrast * 1.10f).coerceIn(0f, 2f),
            highlights = (base.highlights + 0.12f).coerceIn(-1f, 1f)
        )
    }

    fun buildColorMatrix(rawConfig: ColorGradingConfig): ColorMatrix {
        val cfg = resolvePreset(rawConfig)
        val matrix = ColorMatrix()
        val sat = (cfg.saturation + cfg.hslSaturation * 0.5f).coerceIn(0f, 2.5f)
        if (sat != 1f) {
            matrix.postConcat(ColorMatrix().apply { setSaturation(sat) })
        }
        val expMul = 2.0.pow(cfg.exposure.toDouble()).toFloat().coerceIn(0.25f, 4f)
        val rScale = (expMul * cfg.rgbRedGain * cfg.contrast).coerceIn(0f, 4f)
        val gScale = (expMul * cfg.rgbGreenGain * cfg.contrast).coerceIn(0f, 4f)
        val bScale = (expMul * cfg.rgbBlueGain * cfg.contrast).coerceIn(0f, 4f)
        val baseOffset = (128f * (1f - cfg.contrast)) + (cfg.brightness * 115f) + (cfg.hslLuminance * 70f) + ((cfg.shadows + cfg.highlights) * 28f)
        matrix.postConcat(ColorMatrix(floatArrayOf(
            rScale, 0f, 0f, 0f, baseOffset + cfg.temperature * 36f,
            0f, gScale, 0f, 0f, baseOffset + cfg.tint * 26f,
            0f, 0f, bScale, 0f, baseOffset - cfg.temperature * 36f,
            0f, 0f, 0f, 1f, 0f
        )))
        if (abs(cfg.hslHue) > 0.5f) {
            val hueM = ColorMatrix()
            hueM.setRotate(0, cfg.hslHue * 0.35f)
            hueM.setRotate(1, cfg.hslHue * 0.35f)
            hueM.setRotate(2, cfg.hslHue * 0.35f)
            matrix.postConcat(hueM)
        }
        return matrix
    }
}
