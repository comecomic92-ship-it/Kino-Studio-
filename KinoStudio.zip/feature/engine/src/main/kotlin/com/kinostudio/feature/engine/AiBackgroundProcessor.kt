package com.kinostudio.feature.engine

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.view.Surface
import com.kinostudio.core.model.BackgroundConfig
import com.kinostudio.core.model.BackgroundMode
import com.kinostudio.core.model.BackgroundPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

object AiBackgroundProcessor {

    data class BgProcessResult(
        val processedFile: File? = null,
        val maskFile: File? = null,
        val durationMs: Long = 0L
    )

    private var cachedSession: OrtSession? = null
    private var cachedModelPath: String? = null
    private val sessionLock = Any()

    private fun getOrCreateSession(modelFile: File): OrtSession {
        synchronized(sessionLock) {
            if (cachedSession != null && cachedModelPath == modelFile.absolutePath) {
                return cachedSession!!
            }
            runCatching { cachedSession?.close() }
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(4)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }
            val session = env.createSession(modelFile.absolutePath, opts)
            cachedSession = session
            cachedModelPath = modelFile.absolutePath
            return session
        }
    }

    fun releaseSession() {
        synchronized(sessionLock) {
            runCatching { cachedSession?.close() }
            cachedSession = null
            cachedModelPath = null
        }
    }

    /**
     * Generates a highlighted mask preview bitmap for the current frame when user
     * places green (keep) / red (remove) points on the preview canvas.
     */
    suspend fun generateLiveMaskPreview(
        context: Context,
        sourceUri: String,
        isImage: Boolean,
        frameTimeMs: Long,
        config: BackgroundConfig
    ): Bitmap? = withContext(Dispatchers.IO) {
        val modelFile = AiModelManager.getModelFile(context)
        if (!AiModelManager.isModelReady(context)) return@withContext null

        val frame = loadSingleFrame(context, sourceUri, isImage, frameTimeMs, 720) ?: return@withContext null
        try {
            val session = getOrCreateSession(modelFile)
            val alpha = computeFrameAlphaMask(session, frame, config, null)
            val w = frame.width
            val h = frame.height
            val overlay = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(w * h)
            for (i in 0 until w * h) {
                val a = alpha[i].toInt() and 0xFF
                pixels[i] = if (a >= 128) {
                    // Subtle cyan highlight on kept subject
                    Color.argb((a * 0.34f).toInt().coerceIn(0, 110), 0, 229, 255)
                } else {
                    // Dimmed dark overlay on removed background
                    Color.argb(((255 - a) * 0.55f).toInt().coerceIn(0, 150), 10, 10, 18)
                }
            }
            overlay.setPixels(pixels, 0, w, 0, 0, w, h)
            overlay
        } catch (_: Throwable) {
            null
        } finally {
            if (!frame.isRecycled) frame.recycle()
        }
    }

    /**
     * Processes a photo (PNG/JPG/WEBP) with full high-detail matting + edge refinement,
     * saving a real ARGB_8888 PNG to app filesDir.
     */
    suspend fun processImageBackground(
        context: Context,
        sourceUri: String,
        config: BackgroundConfig,
        onProgress: (Int, String) -> Unit
    ): BgProcessResult? = withContext(Dispatchers.IO) {
        val modelFile = AiModelManager.getModelFile(context)
        if (!AiModelManager.isModelReady(context)) return@withContext null

        onProgress(15, "Загрузка изображения...")
        val frame = loadSingleFrame(context, sourceUri, true, 0L, 1440) ?: return@withContext null
        val outDir = File(context.filesDir, "bg_processed").apply { mkdirs() }
        val outFile = File(outDir, "bg_img_${System.currentTimeMillis()}.png")

        try {
            coroutineContext.ensureActive()
            onProgress(40, "Анализ нейросетью...")
            val session = getOrCreateSession(modelFile)
            val alpha = computeFrameAlphaMask(session, frame, config, null)

            coroutineContext.ensureActive()
            onProgress(80, "Обработка краёв...")
            val composited = compositeFrameWithBackground(frame, alpha, config)
            FileOutputStream(outFile).use { fos ->
                composited.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            if (composited !== frame && !composited.isRecycled) composited.recycle()
            onProgress(100, "Готово")
            BgProcessResult(processedFile = outFile, maskFile = null, durationMs = 4000L)
        } catch (_: Throwable) {
            outFile.delete()
            null
        } finally {
            if (!frame.isRecycled) frame.recycle()
        }
    }

    /**
     * Processes every frame of a video clip with the high-detail ONNX neural network
     * + temporal object tracking for point-selected objects.
     *  - For BLUR / COLOR: writes baked 30 FPS H.264 MP4 (`processedFile`).
     *  - For TRANSPARENT: writes 30 FPS grayscale Alpha Matte MP4 (`maskFile`).
     */
    suspend fun processVideoBackground(
        context: Context,
        sourceUri: String,
        trimStartMs: Long,
        trimEndMs: Long,
        config: BackgroundConfig,
        targetFps: Int = 24,
        onProgress: (Int, String) -> Unit
    ): BgProcessResult? = withContext(Dispatchers.IO) {
        val modelFile = AiModelManager.getModelFile(context)
        if (!AiModelManager.isModelReady(context)) return@withContext null

        val outDir = File(context.filesDir, "bg_processed").apply { mkdirs() }
        val isTransparent = config.mode == BackgroundMode.TRANSPARENT
        val outFile = File(outDir, if (isTransparent) "bg_mask_${System.currentTimeMillis()}.mp4" else "bg_vid_${System.currentTimeMillis()}.mp4")
        val framesDir = File(context.cacheDir, "bg_frames_${System.currentTimeMillis()}").apply { mkdirs() }

        var rotationDeg = 0
        var srcWidth = 1280
        var srcHeight = 720
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, Uri.parse(sourceUri))
            srcWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1280
            srcHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 720
            rotationDeg = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        } catch (_: Throwable) {
        } finally {
            runCatching { retriever.release() }
        }

        val frameFiles = mutableListOf<File>()
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null

        try {
            // ================= PHASE 1: SEQUENTIAL HARDWARE DECODE =================
            onProgress(2, "Извлечение кадров...")
            extractor.setDataSource(context, Uri.parse(sourceUri), null)
            var videoTrack = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                if (fmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("video/")) {
                    videoTrack = i
                    trackFormat = fmt
                    break
                }
            }
            if (videoTrack < 0 || trackFormat == null) return@withContext null

            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: return@withContext null
            if (trackFormat.containsKey(MediaFormat.KEY_ROTATION)) {
                rotationDeg = trackFormat.getInteger(MediaFormat.KEY_ROTATION)
            }
            trackFormat.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
            )

            extractor.selectTrack(videoTrack)
            val startUs = trimStartMs.coerceAtLeast(0L) * 1000L
            val endUs = trimEndMs.coerceAtLeast(trimStartMs + 200L) * 1000L
            val spanUs = (endUs - startUs).coerceAtLeast(200_000L)
            val minStepUs = (1_000_000L / targetFps) - 4_000L

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(trackFormat, null, null, 0)
            decoder.start()

            val decInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastSavedPtsUs = Long.MIN_VALUE

            while (!outputDone && frameFiles.size < 720) {
                coroutineContext.ensureActive()
                if (!inputDone) {
                    val inIdx = decoder.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val inBuf = decoder.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sz = extractor.readSampleData(inBuf, 0)
                            val pts = extractor.sampleTime
                            if (sz < 0 || pts > endUs + 500_000L) {
                                decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                decoder.queueInputBuffer(inIdx, 0, sz, pts, extractor.sampleFlags)
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = decoder.dequeueOutputBuffer(decInfo, 10_000L)
                if (outIdx >= 0) {
                    val ptsUs = decInfo.presentationTimeUs
                    val shouldCapture = decInfo.size > 0 &&
                        ptsUs in startUs..endUs &&
                        (lastSavedPtsUs == Long.MIN_VALUE || (ptsUs - lastSavedPtsUs) >= minStepUs)

                    if (shouldCapture) {
                        val image = runCatching { decoder.getOutputImage(outIdx) }.getOrNull()
                        if (image != null) {
                            try {
                                val f = File(framesDir, String.format("f_%05d.jpg", frameFiles.size))
                                if (saveYuvToJpeg(image, f)) {
                                    frameFiles += f
                                    lastSavedPtsUs = ptsUs
                                }
                            } finally {
                                image.close()
                            }
                        }
                        val pct = 2 + (((ptsUs - startUs).toFloat() / spanUs.toFloat()) * 13f).toInt().coerceIn(0, 13)
                        onProgress(pct, "Кадры: ${frameFiles.size}")
                    }
                    decoder.releaseOutputBuffer(outIdx, false)
                    if ((decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || ptsUs > endUs) {
                        outputDone = true
                    }
                }
            }

            runCatching { decoder.stop() }
            runCatching { decoder.release() }
            decoder = null
            runCatching { extractor.release() }

            if (frameFiles.isEmpty()) return@withContext null

            // ================= PHASE 2: AI MATTING + TRACKING + STRICT-PTS ENCODE =================
            val firstBounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(frameFiles.first().absolutePath, firstBounds)
            val rawW = if (firstBounds.outWidth > 0) firstBounds.outWidth else srcWidth
            val rawH = if (firstBounds.outHeight > 0) firstBounds.outHeight else srcHeight

            var outW = if (rotationDeg == 90 || rotationDeg == 270) rawH else rawW
            var outH = if (rotationDeg == 90 || rotationDeg == 270) rawW else rawH
            val maxDim = if (isTransparent) 720f else 1080f
            val scaleDown = minOf(1f, maxDim / maxOf(outW, outH).toFloat())
            outW = ((outW * scaleDown).toInt() / 2) * 2
            outH = ((outH * scaleDown).toInt() / 2) * 2
            if (outW < 64) outW = 640
            if (outH < 64) outH = 360

            val actualFps = ((frameFiles.size.toDouble() / (spanUs / 1_000_000.0)).toInt()).coerceIn(12, targetFps)
            val frameStepUs = 1_000_000L / actualFps

            val encFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, if (isTransparent) 6_000_000 else 12_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, actualFps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var muxTrack = -1
            var muxerStarted = false
            var emittedFrames = 0L
            val encInfo = MediaCodec.BufferInfo()
            val dstRect = Rect(0, 0, outW, outH)

            val session = getOrCreateSession(modelFile)
            val tracker = ObjectTrackerState()
            val total = frameFiles.size
            val phaseStartMs = System.currentTimeMillis()

            for (idx in 0 until total) {
                coroutineContext.ensureActive()
                val rawBmp = BitmapFactory.decodeFile(frameFiles[idx].absolutePath) ?: continue
                val oriented = if (rotationDeg != 0) {
                    val m = Matrix().apply { postRotate(rotationDeg.toFloat()) }
                    val rot = Bitmap.createBitmap(rawBmp, 0, 0, rawBmp.width, rawBmp.height, m, true)
                    if (rot !== rawBmp) rawBmp.recycle()
                    rot
                } else rawBmp

                val workBmp = if (oriented.width != outW || oriented.height != outH) {
                    val sc = Bitmap.createScaledBitmap(oriented, outW, outH, true)
                    if (sc !== oriented) oriented.recycle()
                    sc
                } else oriented

                val alpha = computeFrameAlphaMask(session, workBmp, config, tracker)
                val outBmp = if (isTransparent) {
                    buildGrayscaleMaskBitmap(alpha, outW, outH)
                } else {
                    compositeFrameWithBackground(workBmp, alpha, config)
                }

                val canvas = inputSurface.lockHardwareCanvas()
                try {
                    canvas.drawBitmap(outBmp, null, dstRect, null)
                } finally {
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                if (outBmp !== workBmp && !outBmp.isRecycled) outBmp.recycle()
                if (!workBmp.isRecycled) workBmp.recycle()

                emittedFrames = drainEncoderStrictPts(
                    encoder, muxer, encInfo, false,
                    onFormatChanged = { fmt ->
                        muxTrack = muxer.addTrack(fmt)
                        muxer.start()
                        muxerStarted = true
                    },
                    isMuxerStarted = { muxerStarted },
                    trackIndex = { muxTrack },
                    emittedCount = emittedFrames,
                    frameStepUs = frameStepUs
                )

                val elapsedSec = ((System.currentTimeMillis() - phaseStartMs) / 1000.0).coerceAtLeast(0.1)
                val done = idx + 1
                val remainSec = (((total - done) * (elapsedSec / done)).roundToInt()).coerceAtLeast(1)
                val pct = 15 + ((done * 84) / total)
                onProgress(pct.coerceIn(15, 99), "Кадр $done/$total • ~$remainSec сек")
            }

            encoder.signalEndOfInputStream()
            emittedFrames = drainEncoderStrictPts(
                encoder, muxer, encInfo, true,
                onFormatChanged = { fmt ->
                    if (!muxerStarted) {
                        muxTrack = muxer.addTrack(fmt)
                        muxer.start()
                        muxerStarted = true
                    }
                },
                isMuxerStarted = { muxerStarted },
                trackIndex = { muxTrack },
                emittedCount = emittedFrames,
                frameStepUs = frameStepUs
            )

            val finalDurMs = ((emittedFrames * frameStepUs) / 1000L).coerceAtLeast(300L)
            onProgress(100, "Готово")
            if (isTransparent) {
                BgProcessResult(processedFile = null, maskFile = outFile, durationMs = finalDurMs)
            } else {
                BgProcessResult(processedFile = outFile, maskFile = null, durationMs = finalDurMs)
            }
        } catch (_: Throwable) {
            outFile.delete()
            null
        } finally {
            runCatching { decoder?.stop() }
            runCatching { decoder?.release() }
            runCatching { extractor.release() }
            runCatching { inputSurface?.release() }
            runCatching { encoder?.stop() }
            runCatching { encoder?.release() }
            runCatching { muxer?.stop() }
            runCatching { muxer?.release() }
            runCatching { framesDir.deleteRecursively() }
        }
    }

    // =========================================================================
    // ONNX MATTING + POINT-GUIDED OBJECT SELECTION + TEMPORAL TRACKING
    // =========================================================================

    private class ObjectTrackerState {
        var initialized: Boolean = false
        var posMeanR: Float = 0f
        var posMeanG: Float = 0f
        var posMeanB: Float = 0f
        var negMeanR: Float = 0f
        var negMeanG: Float = 0f
        var negMeanB: Float = 0f
        var hasNegColor: Boolean = false
        var centroidX: Float = 0.5f
        var centroidY: Float = 0.5f
    }

    private fun computeFrameAlphaMask(
        session: OrtSession,
        frame: Bitmap,
        config: BackgroundConfig,
        tracker: ObjectTrackerState?
    ): ByteArray {
        val w = frame.width
        val h = frame.height
        var alpha = runOnnxMatting(session, frame)

        // Point-guided object selection & temporal tracking across video frames
        if (config.objectSelectionMode && config.points.isNotEmpty()) {
            alpha = refineMaskWithPointsAndTracking(frame, alpha, config.points, tracker)
        }

        // Contour expansion / contraction (-12..+12 px)
        val contour = config.contourPx.roundToInt().coerceIn(-12, 12)
        if (contour != 0) {
            alpha = applyMorphology(alpha, w, h, contour)
        }

        // Edge softness / feathering (0..20 px)
        val feather = config.featherPx.roundToInt().coerceIn(0, 20)
        if (feather > 0) {
            alpha = blurAlphaChannel(alpha, w, h, feather)
        }

        // Inversion
        if (config.invertMask) {
            for (i in alpha.indices) {
                alpha[i] = (255 - (alpha[i].toInt() and 0xFF)).toByte()
            }
        }
        return alpha
    }

    private fun runOnnxMatting(session: OrtSession, frame: Bitmap): ByteArray {
        val env = OrtEnvironment.getEnvironment()
        val inputName = session.inputNames.first()
        val inputInfo = session.inputInfo[inputName]?.info as? TensorInfo
        val shape = inputInfo?.shape
        val modelH = if (shape != null && shape.size >= 4 && shape[2] > 0L) shape[2].toInt().coerceIn(256, 1024) else 1024
        val modelW = if (shape != null && shape.size >= 4 && shape[3] > 0L) shape[3].toInt().coerceIn(256, 1024) else 1024

        val resized = if (frame.width != modelW || frame.height != modelH) {
            Bitmap.createScaledBitmap(frame, modelW, modelH, true)
        } else frame

        val pixelCount = modelW * modelH
        val pixels = IntArray(pixelCount)
        resized.getPixels(pixels, 0, modelW, 0, 0, modelW, modelH)
        if (resized !== frame && !resized.isRecycled) resized.recycle()

        // NCHW float32 normalized with IS-Net / standard matting stats (mean=0.5, std=1.0)
        val floatData = FloatArray(3 * pixelCount)
        val meanR = if (modelW >= 512) 0.5f else 0.485f
        val meanG = if (modelW >= 512) 0.5f else 0.456f
        val meanB = if (modelW >= 512) 0.5f else 0.406f
        val stdR = if (modelW >= 512) 1.0f else 0.229f
        val stdG = if (modelW >= 512) 1.0f else 0.224f
        val stdB = if (modelW >= 512) 1.0f else 0.225f

        for (i in 0 until pixelCount) {
            val c = pixels[i]
            floatData[i] = (((c shr 16) and 0xFF) / 255f - meanR) / stdR
            floatData[pixelCount + i] = (((c shr 8) and 0xFF) / 255f - meanG) / stdG
            floatData[2 * pixelCount + i] = ((c and 0xFF) / 255f - meanB) / stdB
        }

        val inputTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(floatData),
            longArrayOf(1L, 3L, modelH.toLong(), modelW.toLong())
        )

        var rawOut = FloatArray(pixelCount)
        var outH = modelH
        var outW = modelW

        inputTensor.use { tensor ->
            session.run(mapOf(inputName to tensor)).use { result ->
                val outTensor = result.get(0) as OnnxTensor
                val outShape = outTensor.info.shape
                if (outShape.size >= 4) {
                    outH = outShape[2].toInt().coerceAtLeast(1)
                    outW = outShape[3].toInt().coerceAtLeast(1)
                } else if (outShape.size == 3) {
                    outH = outShape[1].toInt().coerceAtLeast(1)
                    outW = outShape[2].toInt().coerceAtLeast(1)
                }
                val fb = outTensor.floatBuffer
                val need = min(fb.remaining(), outW * outH)
                rawOut = FloatArray(need)
                fb.get(rawOut, 0, need)
            }
        }

        // Auto-detect logits vs [0..1] probabilities
        var minV = Float.POSITIVE_INFINITY
        var maxV = Float.NEGATIVE_INFINITY
        for (v in rawOut) {
            if (v < minV) minV = v
            if (v > maxV) maxV = v
        }
        val needsSigmoid = minV < -0.2f || maxV > 1.2f
        if (needsSigmoid) {
            minV = Float.POSITIVE_INFINITY
            maxV = Float.NEGATIVE_INFINITY
            for (i in rawOut.indices) {
                val s = (1.0 / (1.0 + exp((-rawOut[i]).toDouble().coerceIn(-30.0, 30.0)))).toFloat()
                rawOut[i] = s
                if (s < minV) minV = s
                if (s > maxV) maxV = s
            }
        }

        val range = (maxV - minV).coerceAtLeast(1e-5f)
        val maskSmall = ByteArray(outW * outH)
        for (i in maskSmall.indices) {
            val norm = ((rawOut[i] - minV) / range).coerceIn(0f, 1f)
            maskSmall[i] = (norm * 255f).roundToInt().coerceIn(0, 255).toByte()
        }

        return if (outW == frame.width && outH == frame.height) {
            maskSmall
        } else {
            resizeAlphaBilinear(maskSmall, outW, outH, frame.width, frame.height)
        }
    }

    private fun refineMaskWithPointsAndTracking(
        frame: Bitmap,
        onnxAlpha: ByteArray,
        points: List<BackgroundPoint>,
        tracker: ObjectTrackerState?
    ): ByteArray {
        val w = frame.width
        val h = frame.height
        val pixels = IntArray(w * h)
        frame.getPixels(pixels, 0, w, 0, 0, w, h)

        val posPts = points.filter { it.isPositive }
        val negPts = points.filter { !it.isPositive }

        fun samplePatchColor(nx: Float, ny: Float): FloatArray {
            val cx = (nx * (w - 1)).roundToInt().coerceIn(0, w - 1)
            val cy = (ny * (h - 1)).roundToInt().coerceIn(0, h - 1)
            var sr = 0f; var sg = 0f; var sb = 0f; var cnt = 0
            for (dy in -3..3) {
                val yy = (cy + dy).coerceIn(0, h - 1)
                for (dx in -3..3) {
                    val xx = (cx + dx).coerceIn(0, w - 1)
                    val c = pixels[yy * w + xx]
                    sr += (c shr 16) and 0xFF
                    sg += (c shr 8) and 0xFF
                    sb += c and 0xFF
                    cnt++
                }
            }
            return floatArrayOf(sr / cnt, sg / cnt, sb / cnt)
        }

        // Build or reuse tracked color signature
        val posColors = mutableListOf<FloatArray>()
        val negColors = mutableListOf<FloatArray>()

        if (tracker != null && tracker.initialized) {
            posColors += floatArrayOf(tracker.posMeanR, tracker.posMeanG, tracker.posMeanB)
            if (tracker.hasNegColor) {
                negColors += floatArrayOf(tracker.negMeanR, tracker.negMeanG, tracker.negMeanB)
            }
        } else {
            posPts.forEach { posColors += samplePatchColor(it.x, it.y) }
            negPts.forEach { negColors += samplePatchColor(it.x, it.y) }
        }

        // Add border samples as weak background reference when no red points exist
        if (negColors.isEmpty()) {
            negColors += samplePatchColor(0.03f, 0.03f)
            negColors += samplePatchColor(0.97f, 0.03f)
            negColors += samplePatchColor(0.03f, 0.97f)
            negColors += samplePatchColor(0.97f, 0.97f)
        }

        // If user ONLY placed red points (erase regions from ONNX mask):
        if (posPts.isEmpty() && negPts.isNotEmpty()) {
            val out = onnxAlpha.copyOf()
            for (y in 0 until h) {
                val ny = y.toFloat() / h
                for (x in 0 until w) {
                    val nx = x.toFloat() / w
                    val idx = y * w + x
                    val c = pixels[idx]
                    val r = ((c shr 16) and 0xFF).toFloat()
                    val g = ((c shr 8) and 0xFF).toFloat()
                    val b = (c and 0xFF).toFloat()
                    for (pIdx in negPts.indices) {
                        val pt = negPts[pIdx]
                        val distSp = sqrt((nx - pt.x) * (nx - pt.x) + (ny - pt.y) * (ny - pt.y))
                        val nc = negColors[pIdx.coerceAtMost(negColors.lastIndex)]
                        val distCol = sqrt((r - nc[0]) * (r - nc[0]) + (g - nc[1]) * (g - nc[1]) + (b - nc[2]) * (b - nc[2]))
                        if (distSp < 0.22f && distCol < 68f) {
                            val suppress = ((1f - distSp / 0.22f) * (1f - distCol / 68f)).coerceIn(0f, 1f)
                            val curA = out[idx].toInt() and 0xFF
                            out[idx] = (curA * (1f - suppress)).roundToInt().coerceIn(0, 255).toByte()
                        }
                    }
                }
            }
            return out
        }

        // Green points present: combine ONNX fine matte with color+spatial object affinity
        val out = ByteArray(w * h)
        var sumX = 0.0; var sumY = 0.0; var sumR = 0.0; var sumG = 0.0; var sumB = 0.0; var sumW = 0.0
        val centerX = if (tracker != null && tracker.initialized) tracker.centroidX else posPts.map { it.x }.average().toFloat()
        val centerY = if (tracker != null && tracker.initialized) tracker.centroidY else posPts.map { it.y }.average().toFloat()

        for (y in 0 until h) {
            val ny = y.toFloat() / h
            for (x in 0 until w) {
                val nx = x.toFloat() / w
                val idx = y * w + x
                val baseProb = (onnxAlpha[idx].toInt() and 0xFF) / 255f
                val c = pixels[idx]
                val r = ((c shr 16) and 0xFF).toFloat()
                val g = ((c shr 8) and 0xFF).toFloat()
                val b = (c and 0xFF).toFloat()

                var minPosDist = Float.POSITIVE_INFINITY
                for (pc in posColors) {
                    val d = sqrt((r - pc[0]) * (r - pc[0]) + (g - pc[1]) * (g - pc[1]) + (b - pc[2]) * (b - pc[2]))
                    if (d < minPosDist) minPosDist = d
                }
                var minNegDist = Float.POSITIVE_INFINITY
                for (nc in negColors) {
                    val d = sqrt((r - nc[0]) * (r - nc[0]) + (g - nc[1]) * (g - nc[1]) + (b - nc[2]) * (b - nc[2]))
                    if (d < minNegDist) minNegDist = d
                }

                // Spatial distance to nearest green point (or tracked centroid)
                var minSp = sqrt((nx - centerX) * (nx - centerX) + (ny - centerY) * (ny - centerY))
                if (tracker == null || !tracker.initialized) {
                    for (pt in posPts) {
                        val d = sqrt((nx - pt.x) * (nx - pt.x) + (ny - pt.y) * (ny - pt.y))
                        if (d < minSp) minSp = d
                    }
                }

                val colorAffinity = (minNegDist / (minPosDist + minNegDist + 1e-3f)).coerceIn(0f, 1f)
                val spatialPrior = exp((-minSp * minSp * 4.5f).toDouble()).toFloat()

                // Fuse ONNX crisp boundary matte with interactive object score
                var score = (baseProb * 0.55f) + (colorAffinity * 0.30f) + (spatialPrior * 0.25f)
                if (minPosDist < 42f && minSp < 0.28f) {
                    score = max(score, 0.85f)
                }
                // Strongly suppress near red points
                for (pt in negPts) {
                    val dn = sqrt((nx - pt.x) * (nx - pt.x) + (ny - pt.y) * (ny - pt.y))
                    if (dn < 0.14f) {
                        score *= (dn / 0.14f).coerceIn(0f, 1f)
                    }
                }

                // Sharpen around threshold while preserving ONNX soft hair edges
                val refined = ((score - 0.42f) / 0.24f).coerceIn(0f, 1f)
                val finalProb = if (baseProb in 0.08f..0.92f) {
                    // Keep ONNX hair alpha where subject is kept
                    (refined * baseProb * 1.45f).coerceIn(0f, 1f)
                } else {
                    refined
                }

                val byteVal = (finalProb * 255f).roundToInt().coerceIn(0, 255)
                out[idx] = byteVal.toByte()

                if (finalProb > 0.65f) {
                    sumX += nx; sumY += ny; sumR += r; sumG += g; sumB += b; sumW += 1.0
                }
            }
        }

        // Update temporal tracker for smooth tracking on the next video frame
        if (tracker != null && sumW > 32.0) {
            val newCx = (sumX / sumW).toFloat()
            val newCy = (sumY / sumW).toFloat()
            val newR = (sumR / sumW).toFloat()
            val newG = (sumG / sumW).toFloat()
            val newB = (sumB / sumW).toFloat()
            if (!tracker.initialized) {
                tracker.initialized = true
                tracker.centroidX = newCx; tracker.centroidY = newCy
                tracker.posMeanR = newR; tracker.posMeanG = newG; tracker.posMeanB = newB
                if (negPts.isNotEmpty()) {
                    tracker.hasNegColor = true
                    tracker.negMeanR = negColors.first()[0]
                    tracker.negMeanG = negColors.first()[1]
                    tracker.negMeanB = negColors.first()[2]
                }
            } else {
                // Smooth EMA update prevents sudden drift
                tracker.centroidX = tracker.centroidX * 0.65f + newCx * 0.35f
                tracker.centroidY = tracker.centroidY * 0.65f + newCy * 0.35f
                tracker.posMeanR = tracker.posMeanR * 0.85f + newR * 0.15f
                tracker.posMeanG = tracker.posMeanG * 0.85f + newG * 0.15f
                tracker.posMeanB = tracker.posMeanB * 0.85f + newB * 0.15f
            }
        }
        return out
    }

    // =========================================================================
    // FAST EDGE REFINEMENT & BACKGROUND COMPOSITING
    // =========================================================================

    private fun applyMorphology(alpha: ByteArray, w: Int, h: Int, radius: Int): ByteArray {
        val r = abs(radius).coerceIn(1, 12)
        val dilate = radius > 0
        val temp = ByteArray(w * h)
        val out = ByteArray(w * h)

        // Horizontal pass
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var best = if (dilate) 0 else 255
                val x0 = max(0, x - r)
                val x1 = min(w - 1, x + r)
                for (xx in x0..x1) {
                    val v = alpha[row + xx].toInt() and 0xFF
                    best = if (dilate) max(best, v) else min(best, v)
                }
                temp[row + x] = best.toByte()
            }
        }
        // Vertical pass
        for (x in 0 until w) {
            for (y in 0 until h) {
                var best = if (dilate) 0 else 255
                val y0 = max(0, y - r)
                val y1 = min(h - 1, y + r)
                for (yy in y0..y1) {
                    val v = temp[yy * w + x].toInt() and 0xFF
                    best = if (dilate) max(best, v) else min(best, v)
                }
                out[y * w + x] = best.toByte()
            }
        }
        return out
    }

    private fun blurAlphaChannel(alpha: ByteArray, w: Int, h: Int, radius: Int): ByteArray {
        val r = radius.coerceIn(1, 20)
        var cur = alpha
        val temp = ByteArray(w * h)
        val out = ByteArray(w * h)
        val win = 2 * r + 1

        repeat(2) {
            // Horizontal sliding sum
            for (y in 0 until h) {
                val row = y * w
                var sum = 0
                for (k in -r..r) {
                    sum += cur[row + k.coerceIn(0, w - 1)].toInt() and 0xFF
                }
                for (x in 0 until w) {
                    temp[row + x] = (sum / win).coerceIn(0, 255).toByte()
                    val addIdx = (x + r + 1).coerceIn(0, w - 1)
                    val remIdx = (x - r).coerceIn(0, w - 1)
                    sum += (cur[row + addIdx].toInt() and 0xFF) - (cur[row + remIdx].toInt() and 0xFF)
                }
            }
            // Vertical sliding sum
            for (x in 0 until w) {
                var sum = 0
                for (k in -r..r) {
                    sum += temp[k.coerceIn(0, h - 1) * w + x].toInt() and 0xFF
                }
                for (y in 0 until h) {
                    out[y * w + x] = (sum / win).coerceIn(0, 255).toByte()
                    val addY = (y + r + 1).coerceIn(0, h - 1)
                    val remY = (y - r).coerceIn(0, h - 1)
                    sum += (temp[addY * w + x].toInt() and 0xFF) - (temp[remY * w + x].toInt() and 0xFF)
                }
            }
            cur = out.copyOf()
        }
        return out
    }

    private fun compositeFrameWithBackground(
        src: Bitmap,
        alpha: ByteArray,
        config: BackgroundConfig
    ): Bitmap {
        val w = src.width
        val h = src.height
        val fgPixels = IntArray(w * h)
        src.getPixels(fgPixels, 0, w, 0, 0, w, h)
        val outPixels = IntArray(w * h)

        when (config.mode) {
            BackgroundMode.TRANSPARENT -> {
                for (i in 0 until w * h) {
                    val a = alpha[i].toInt() and 0xFF
                    outPixels[i] = (a shl 24) or (fgPixels[i] and 0x00FFFFFF)
                }
            }
            BackgroundMode.COLOR -> {
                val bg = config.solidColorArgb.toInt()
                val bgR = (bg shr 16) and 0xFF
                val bgG = (bg shr 8) and 0xFF
                val bgB = bg and 0xFF
                for (i in 0 until w * h) {
                    val a = alpha[i].toInt() and 0xFF
                    val inv = 255 - a
                    val fg = fgPixels[i]
                    val r = (((fg shr 16) and 0xFF) * a + bgR * inv) / 255
                    val g = (((fg shr 8) and 0xFF) * a + bgG * inv) / 255
                    val b = ((fg and 0xFF) * a + bgB * inv) / 255
                    outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            BackgroundMode.BLUR, BackgroundMode.NONE -> {
                val blurBmp = createFastBlurredBitmap(src, config.blurStrength.roundToInt().coerceIn(4, 35))
                val bgPixels = IntArray(w * h)
                blurBmp.getPixels(bgPixels, 0, w, 0, 0, w, h)
                if (blurBmp !== src && !blurBmp.isRecycled) blurBmp.recycle()
                for (i in 0 until w * h) {
                    val a = alpha[i].toInt() and 0xFF
                    val inv = 255 - a
                    val fg = fgPixels[i]
                    val bg = bgPixels[i]
                    val r = (((fg shr 16) and 0xFF) * a + ((bg shr 16) and 0xFF) * inv) / 255
                    val g = (((fg shr 8) and 0xFF) * a + ((bg shr 8) and 0xFF) * inv) / 255
                    val b = ((fg and 0xFF) * a + (bg and 0xFF) * inv) / 255
                    outPixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(outPixels, 0, w, 0, 0, w, h)
        return out
    }

    private fun buildGrayscaleMaskBitmap(alpha: ByteArray, w: Int, h: Int): Bitmap {
        val pixels = IntArray(w * h)
        for (i in 0 until w * h) {
            val a = alpha[i].toInt() and 0xFF
            pixels[i] = (0xFF shl 24) or (a shl 16) or (a shl 8) or a
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, w, 0, 0, w, h)
        }
    }

    private fun createFastBlurredBitmap(src: Bitmap, strength: Int): Bitmap {
        val scale = (0.14f + (35 - strength).coerceIn(0, 31) * 0.008f).coerceIn(0.10f, 0.35f)
        val sw = (src.width * scale).roundToInt().coerceAtLeast(16)
        val sh = (src.height * scale).roundToInt().coerceAtLeast(16)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pix = IntArray(sw * sh)
        small.getPixels(pix, 0, sw, 0, 0, sw, sh)
        val r = (strength / 5).coerceIn(2, 8)
        val tmp = IntArray(sw * sh)
        val win = 2 * r + 1

        repeat(2) {
            for (y in 0 until sh) {
                val row = y * sw
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) {
                    val c = pix[row + k.coerceIn(0, sw - 1)]
                    sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF
                }
                for (x in 0 until sw) {
                    tmp[row + x] = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                    val add = pix[row + (x + r + 1).coerceIn(0, sw - 1)]
                    val rem = pix[row + (x - r).coerceIn(0, sw - 1)]
                    sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
                    sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
                    sb += (add and 0xFF) - (rem and 0xFF)
                }
            }
            for (x in 0 until sw) {
                var sr = 0; var sg = 0; var sb = 0
                for (k in -r..r) {
                    val c = tmp[k.coerceIn(0, sh - 1) * sw + x]
                    sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF
                }
                for (y in 0 until sh) {
                    pix[y * sw + x] = (0xFF shl 24) or ((sr / win) shl 16) or ((sg / win) shl 8) or (sb / win)
                    val add = tmp[(y + r + 1).coerceIn(0, sh - 1) * sw + x]
                    val rem = tmp[(y - r).coerceIn(0, sh - 1) * sw + x]
                    sr += ((add shr 16) and 0xFF) - ((rem shr 16) and 0xFF)
                    sg += ((add shr 8) and 0xFF) - ((rem shr 8) and 0xFF)
                    sb += (add and 0xFF) - (rem and 0xFF)
                }
            }
        }
        small.setPixels(pix, 0, sw, 0, 0, sw, sh)
        val up = Bitmap.createScaledBitmap(small, src.width, src.height, true)
        if (up !== small && !small.isRecycled) small.recycle()
        return up
    }

    private fun resizeAlphaBilinear(src: ByteArray, sw: Int, sh: Int, dw: Int, dh: Int): ByteArray {
        val dst = ByteArray(dw * dh)
        val xRatio = (sw - 1).toFloat() / (dw - 1).coerceAtLeast(1)
        val yRatio = (sh - 1).toFloat() / (dh - 1).coerceAtLeast(1)
        for (y in 0 until dh) {
            val fy = y * yRatio
            val y0 = fy.toInt().coerceIn(0, sh - 1)
            val y1 = (y0 + 1).coerceAtMost(sh - 1)
            val dy = fy - y0
            val r0 = y0 * sw
            val r1 = y1 * sw
            val dRow = y * dw
            for (x in 0 until dw) {
                val fx = x * xRatio
                val x0 = fx.toInt().coerceIn(0, sw - 1)
                val x1 = (x0 + 1).coerceAtMost(sw - 1)
                val dx = fx - x0
                val a00 = src[r0 + x0].toInt() and 0xFF
                val a10 = src[r0 + x1].toInt() and 0xFF
                val a01 = src[r1 + x0].toInt() and 0xFF
                val a11 = src[r1 + x1].toInt() and 0xFF
                val top = a00 + (a10 - a00) * dx
                val bot = a01 + (a11 - a01) * dx
                dst[dRow + x] = (top + (bot - top) * dy).roundToInt().coerceIn(0, 255).toByte()
            }
        }
        return dst
    }

    /**
     * Applies a grayscale mask bitmap as the ARGB alpha channel of an RGB bitmap.
     * Used in both Live Preview and Export for transparent video clips!
     */
    fun applyGrayscaleMaskToBitmap(rgb: Bitmap, mask: Bitmap): Bitmap {
        val w = rgb.width
        val h = rgb.height
        val scaledMask = if (mask.width != w || mask.height != h) {
            Bitmap.createScaledBitmap(mask, w, h, true)
        } else mask
        val rgbPix = IntArray(w * h)
        val mskPix = IntArray(w * h)
        rgb.getPixels(rgbPix, 0, w, 0, 0, w, h)
        scaledMask.getPixels(mskPix, 0, w, 0, 0, w, h)
        if (scaledMask !== mask && !scaledMask.isRecycled) scaledMask.recycle()
        for (i in 0 until w * h) {
            val a = (mskPix[i] shr 16) and 0xFF
            rgbPix[i] = (a shl 24) or (rgbPix[i] and 0x00FFFFFF)
        }
        return Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).apply {
            setPixels(rgbPix, 0, w, 0, 0, w, h)
        }
    }

    private fun loadSingleFrame(
        context: Context,
        sourceUri: String,
        isImage: Boolean,
        frameTimeMs: Long,
        maxDim: Int
    ): Bitmap? {
        return if (isImage) {
            runCatching {
                val uri = Uri.parse(sourceUri)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
                if (max(bmp.width, bmp.height) > maxDim) {
                    val s = maxDim.toFloat() / max(bmp.width, bmp.height).toFloat()
                    val sc = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt().coerceAtLeast(2), (bmp.height * s).toInt().coerceAtLeast(2), true)
                    if (sc !== bmp) bmp.recycle()
                    sc
                } else bmp
            }.getOrNull()
        } else {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, Uri.parse(sourceUri))
                val raw = retriever.getFrameAtTime(frameTimeMs.coerceAtLeast(0L) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: retriever.getFrameAtTime(frameTimeMs.coerceAtLeast(0L) * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return null
                if (max(raw.width, raw.height) > maxDim) {
                    val s = maxDim.toFloat() / max(raw.width, raw.height).toFloat()
                    val sc = Bitmap.createScaledBitmap(raw, (raw.width * s).toInt().coerceAtLeast(2), (raw.height * s).toInt().coerceAtLeast(2), true)
                    if (sc !== raw) raw.recycle()
                    sc
                } else raw
            } catch (_: Throwable) {
                null
            } finally {
                runCatching { retriever.release() }
            }
        }
    }

    private fun saveYuvToJpeg(image: Image, outFile: File): Boolean = runCatching {
        val width = image.width; val height = image.height
        val ySize = width * height
        val nv21 = ByteArray(ySize + ySize / 2)
        val yPlane = image.planes[0]; val uPlane = image.planes[1]; val vPlane = image.planes[2]
        val yBuf = yPlane.buffer; val yRow = yPlane.rowStride; val yPix = yPlane.pixelStride
        var pos = 0
        for (row in 0 until height) {
            val start = row * yRow
            if (yPix == 1) { yBuf.position(start); yBuf.get(nv21, pos, width); pos += width }
            else { for (col in 0 until width) nv21[pos++] = yBuf.get(start + col * yPix) }
        }
        val uBuf = uPlane.buffer; val vBuf = vPlane.buffer
        val uRow = uPlane.rowStride; val vRow = vPlane.rowStride
        val uPix = uPlane.pixelStride; val vPix = vPlane.pixelStride
        for (row in 0 until height / 2) {
            val vs = row * vRow; val us = row * uRow
            for (col in 0 until width / 2) {
                nv21[pos++] = vBuf.get(vs + col * vPix)
                nv21[pos++] = uBuf.get(us + col * uPix)
            }
        }
        FileOutputStream(outFile).use { fos ->
            YuvImage(nv21, ImageFormat.NV21, width, height, null).compressToJpeg(Rect(0, 0, width, height), 88, fos)
        }
        true
    }.getOrDefault(false)

    private fun drainEncoderStrictPts(
        encoder: MediaCodec, muxer: MediaMuxer, bufferInfo: MediaCodec.BufferInfo, endOfStream: Boolean,
        onFormatChanged: (MediaFormat) -> Unit, isMuxerStarted: () -> Boolean, trackIndex: () -> Int,
        emittedCount: Long, frameStepUs: Long
    ): Long {
        var count = emittedCount
        while (true) {
            val outIdx = encoder.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            when {
                outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) break
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormatChanged(encoder.outputFormat)
                outIdx >= 0 -> {
                    val data = encoder.getOutputBuffer(outIdx)
                    if (data != null && bufferInfo.size > 0 && isMuxerStarted() && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        data.position(bufferInfo.offset); data.limit(bufferInfo.offset + bufferInfo.size)
                        bufferInfo.presentationTimeUs = count * frameStepUs
                        muxer.writeSampleData(trackIndex(), data, bufferInfo)
                        count++
                    }
                    encoder.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
            }
        }
        return count
    }
}
