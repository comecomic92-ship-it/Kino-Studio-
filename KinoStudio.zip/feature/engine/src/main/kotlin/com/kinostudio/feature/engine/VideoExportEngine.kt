package com.kinostudio.feature.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SpeedChangingAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.kinostudio.core.model.ExportConfig
import com.kinostudio.core.model.ExportStatus
import com.kinostudio.core.model.TrackKind
import com.kinostudio.core.model.ClipEdgeEffect
import com.kinostudio.core.model.TransitionType
import com.kinostudio.core.model.VideoProject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(UnstableApi::class)
class VideoExportEngine(private val context: Context) {

    private val _status = MutableStateFlow<ExportStatus>(ExportStatus.Idle)
    val status: StateFlow<ExportStatus> = _status.asStateFlow()

    private var activeTransformer: Transformer? = null
    private var progressJob: Job? = null
    private var tempExportFile: File? = null

    fun startExport(
        project: VideoProject,
        config: ExportConfig,
        scope: CoroutineScope,
        textOverlayDrawer: ((Canvas, Int, Int, Long) -> Unit)? = null
    ) {
        val visibleVisualTracks = project.tracks.filter { it.kind == TrackKind.VISUAL && !it.isHidden }
        val visibleTrackIds = visibleVisualTracks.map { it.id }.toSet()
        val allVisibleClips = project.visualClips.filter { !it.isHidden && it.trackId in visibleTrackIds }
        if (allVisibleClips.isEmpty()) {
            _status.value = ExportStatus.Failed("Добавьте хотя бы одно видео или фото на дорожку перед экспортом.")
            return
        }

        val trackOrderMap = visibleVisualTracks.mapIndexed { idx, t -> t.id to idx }.toMap()
        val opaqueBaseTrackId = visibleVisualTracks.firstOrNull { tr ->
            val clipsOnTr = allVisibleClips.filter { it.trackId == tr.id }
            clipsOnTr.isNotEmpty() && clipsOnTr.none { it.hasTransparentVideoMask }
        }?.id
        val baseClips = if (opaqueBaseTrackId != null) {
            allVisibleClips.filter { it.trackId == opaqueBaseTrackId }.sortedBy { it.timelineStartMs }
        } else emptyList()
        val upperClips = allVisibleClips
            .filter { it.trackId != opaqueBaseTrackId }
            .sortedWith(compareBy({ trackOrderMap[it.trackId] ?: 0 }, { it.timelineStartMs }))

        cancelExport()
        _status.value = ExportStatus.Running(0, "Подготовка экспорта...")

        scope.launch(Dispatchers.Main) {
            try {
                val (targetW, targetH) = computeExportDimensions(project, config)
                val cacheDir = File(context.cacheDir, "exports").apply { mkdirs() }
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val safeName = project.name.replace(Regex("[^a-zA-Z0-9а-яА-Я_-]"), "_").take(32)
                val fileName = "KinoStudio_${safeName}_${timestamp}.${config.container.extension}"
                val tempOut = File(cacheDir, fileName)
                if (tempOut.exists()) tempOut.delete()
                tempExportFile = tempOut

                val editedBaseItems = mutableListOf<EditedMediaItem>()
                for (clip in baseClips) {
                    val videoEffects = mutableListOf<Effect>()
                    val audioProcessors = mutableListOf<AudioProcessor>()
                    if (!clip.transform.isIdentity()) videoEffects += TransformMatrixEffect(clip.transform)
                    val mergedColor = ColorMatrixUtil.merge(project.globalColorGrading, clip.colorGrading)
                    val hasVisualFx = !mergedColor.isIdentity() ||
                        clip.transitionIn != TransitionType.NONE ||
                        clip.edgeEffectIn != ClipEdgeEffect.NONE ||
                        clip.edgeEffectOut != ClipEdgeEffect.NONE ||
                        clip.transform.opacity < 0.99f
                    if (hasVisualFx) {
                        videoEffects += ColorGradingGlEffect(
                            config = mergedColor,
                            clipOpacity = clip.transform.opacity,
                            clipDurationMs = clip.effectiveDurationMs,
                            transitionIn = clip.transitionIn,
                            transitionDurationMs = clip.transitionDurationMs,
                            edgeEffectIn = clip.edgeEffectIn,
                            edgeEffectInMs = clip.edgeEffectInMs,
                            edgeEffectOut = clip.edgeEffectOut,
                            edgeEffectOutMs = clip.edgeEffectOutMs
                        )
                    }
                    if (clip.isImage) {
                        val imageMedia = MediaItem.Builder().setUri(Uri.parse(clip.activeUri)).build()
                        editedBaseItems += EditedMediaItem.Builder(imageMedia)
                            .setDurationUs(clip.effectiveDurationMs * 1000L)
                            .setFrameRate(config.fps)
                            .setRemoveAudio(true)
                            .setEffects(Effects(emptyList(), videoEffects))
                            .build()
                    } else {
                        val mediaItem = MediaItem.Builder()
                            .setUri(Uri.parse(clip.activeUri))
                            .setClippingConfiguration(
                                MediaItem.ClippingConfiguration.Builder()
                                    .setStartPositionMs(clip.trimStartMs.coerceAtLeast(0L))
                                    .setEndPositionMs(clip.trimEndMs.coerceAtLeast(clip.trimStartMs + 100L))
                                    .build()
                            )
                            .build()
                        val muteAudio = clip.isAudioMuted || clip.isReversed
                        if (clip.speed != 1f || clip.speedRampPoints.size >= 2) {
                            val sp = ClipSpeedProvider(clip.speed, clip.trimmedSourceDurationMs * 1000L, clip.speedRampPoints)
                            videoEffects += SpeedChangeEffect(sp)
                            if (!muteAudio) audioProcessors += SpeedChangingAudioProcessor(sp)
                        }
                        if (!muteAudio && (clip.volume != 1f || clip.fadeInMs > 0L || clip.fadeOutMs > 0L)) {
                            audioProcessors += VolumeFadeAudioProcessor(clip.volume, clip.fadeInMs, clip.fadeOutMs, clip.effectiveDurationMs)
                        }
                        editedBaseItems += EditedMediaItem.Builder(mediaItem)
                            .setRemoveAudio(muteAudio)
                            .setEffects(Effects(audioProcessors, videoEffects))
                            .build()
                    }
                }

                if (editedBaseItems.isEmpty()) {
                    val blackFile = File(cacheDir, "black_base.png")
                    val blk = android.graphics.Bitmap.createBitmap(16, 16, android.graphics.Bitmap.Config.ARGB_8888)
                    blk.eraseColor(android.graphics.Color.BLACK)
                    java.io.FileOutputStream(blackFile).use { blk.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    blk.recycle()
                    val blkItem = MediaItem.Builder().setUri(Uri.fromFile(blackFile)).build()
                    editedBaseItems += EditedMediaItem.Builder(blkItem)
                        .setDurationUs(project.totalDurationMs.coerceAtLeast(1000L) * 1000L)
                        .setFrameRate(config.fps)
                        .setRemoveAudio(true)
                        .build()
                }
                val sequences = mutableListOf<EditedMediaItemSequence>()
                sequences += EditedMediaItemSequence.Builder(editedBaseItems).build()

                val visibleAudioTrackIds = project.tracks.filter { it.kind == TrackKind.AUDIO && !it.isHidden && !it.isMuted }.map { it.id }.toSet()
                for (track in project.audioClips.filter { !it.isHidden && !it.isMuted && it.trackId in visibleAudioTrackIds }) {
                    val audioItem = MediaItem.Builder()
                        .setUri(Uri.parse(track.sourceUri))
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(track.trimStartMs.coerceAtLeast(0L))
                                .setEndPositionMs(track.trimEndMs.coerceAtLeast(track.trimStartMs + 100L))
                                .build()
                        )
                        .build()
                    val processors = mutableListOf<AudioProcessor>()
                    if (track.speed != 1f) {
                        processors += SpeedChangingAudioProcessor(ClipSpeedProvider(track.speed, (track.trimEndMs - track.trimStartMs) * 1000L, emptyList()))
                    }
                    processors += VolumeFadeAudioProcessor(track.volume, track.fadeInMs, track.fadeOutMs, track.effectiveDurationMs)
                    val editedAudio = EditedMediaItem.Builder(audioItem)
                        .setRemoveVideo(true)
                        .setEffects(Effects(processors, emptyList()))
                        .build()
                    sequences += EditedMediaItemSequence.Builder(listOf(editedAudio)).build()
                }

                val compVideoEffects = mutableListOf<Effect>()
                compVideoEffects += Presentation.createForWidthAndHeight(targetW, targetH, Presentation.LAYOUT_SCALE_TO_FIT)
                compVideoEffects += FrameDropEffect.createDefaultFrameDropEffect(config.fps.toFloat())

                val visibleTextTrackIds = project.tracks.filter { it.kind == TrackKind.TEXT && !it.isHidden }.map { it.id }.toSet()
                val hasVisibleText = project.textItems.any { !it.isHidden && it.trackId in visibleTextTrackIds }
                if (upperClips.isNotEmpty() || (hasVisibleText && textOverlayDrawer != null)) {
                    val dynamicOverlay = DynamicBitmapOverlay(context, targetW, targetH, { upperClips }, project.globalColorGrading, textOverlayDrawer)
                    compVideoEffects += OverlayEffect(ImmutableList.of<TextureOverlay>(dynamicOverlay))
                }

                val composition = Composition.Builder(sequences).setEffects(Effects(emptyList(), compVideoEffects)).build()
                val bitrateBps = (config.videoBitrateMbps * 1_000_000f).toInt().coerceIn(2_000_000, 100_000_000)
                val encoderFactory = DefaultEncoderFactory.Builder(context)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrateBps).build())
                    .setEnableFallback(true)
                    .build()

                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(config.codec.mimeType)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoderFactory)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            progressJob?.cancel(); activeTransformer = null
                            scope.launch {
                                _status.value = ExportStatus.Running(98, "Сохранение в галерею...")
                                val savedUri = saveToGallery(tempOut, fileName, config.container.extension)
                                tempOut.delete()
                                _status.value = if (savedUri != null) {
                                    ExportStatus.Completed(savedUri.toString(), fileName, exportResult.durationMs)
                                } else ExportStatus.Failed("Не удалось сохранить видео в галерею.")
                            }
                        }

                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            progressJob?.cancel(); activeTransformer = null; tempOut.delete()
                            _status.value = ExportStatus.Failed(exportException.localizedMessage ?: "Ошибка кодирования (${exportException.errorCodeName})")
                        }
                    })
                    .build()

                activeTransformer = transformer
                transformer.start(composition, tempOut.absolutePath)

                val holder = ProgressHolder()
                progressJob = scope.launch(Dispatchers.Main) {
                    while (isActive && activeTransformer != null) {
                        if (activeTransformer?.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                            _status.value = ExportStatus.Running(holder.progress.coerceIn(0, 97), "Экспорт ${targetW}x${targetH} • ${config.fps} FPS...")
                        }
                        delay(150L)
                    }
                }
            } catch (t: Throwable) {
                progressJob?.cancel(); activeTransformer = null
                _status.value = ExportStatus.Failed(t.localizedMessage ?: "Ошибка запуска экспорта")
            }
        }
    }

    fun cancelExport() {
        progressJob?.cancel(); progressJob = null
        runCatching { activeTransformer?.cancel() }; activeTransformer = null
        tempExportFile?.delete(); tempExportFile = null
        if (_status.value is ExportStatus.Running) _status.value = ExportStatus.Cancelled
    }

    fun resetStatus() { _status.value = ExportStatus.Idle }

    private fun computeExportDimensions(project: VideoProject, config: ExportConfig): Pair<Int, Int> {
        val (pw, ph) = project.resolvedDimensions()
        val shortSide = config.resolution.shortSidePx
        val rawW = if (pw >= ph) ((shortSide.toFloat() * pw) / ph).toInt() else shortSide
        val rawH = if (pw >= ph) shortSide else ((shortSide.toFloat() * ph) / pw).toInt()
        return ((rawW / 2) * 2).coerceIn(360, 4096) to ((rawH / 2) * 2).coerceIn(360, 4096)
    }

    private suspend fun saveToGallery(sourceFile: File, fileName: String, ext: String): Uri? = withContext(Dispatchers.IO) {
        if (!sourceFile.exists()) return@withContext null
        val mime = if (ext.equals("mov", true)) "video/quicktime" else "video/mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/KinoStudio")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null
        try {
            resolver.openOutputStream(uri)?.use { out -> FileInputStream(sourceFile).use { it.copyTo(out, 64 * 1024) } }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            uri
        } catch (_: Throwable) { runCatching { resolver.delete(uri, null, null) }; null }
    }
}
