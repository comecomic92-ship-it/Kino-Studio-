package com.kinostudio.feature.engine

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import com.kinostudio.core.model.SpeedRampPoint

@OptIn(UnstableApi::class)
class ClipSpeedProvider(
    private val constantSpeed: Float,
    private val durationUs: Long,
    rampPoints: List<SpeedRampPoint>
) : SpeedProvider {
    private val sortedPoints = rampPoints.sortedBy { it.positionFraction }
    private val stepUs = 100_000L

    override fun getSpeed(timeUs: Long): Float {
        if (sortedPoints.size < 2 || durationUs <= 0L) return constantSpeed.coerceIn(0.25f, 8f)
        val frac = (timeUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 1f)
        if (frac <= sortedPoints.first().positionFraction) return sortedPoints.first().speed.coerceIn(0.25f, 8f)
        if (frac >= sortedPoints.last().positionFraction) return sortedPoints.last().speed.coerceIn(0.25f, 8f)
        for (i in 0 until sortedPoints.lastIndex) {
            val a = sortedPoints[i]
            val b = sortedPoints[i + 1]
            if (frac in a.positionFraction..b.positionFraction) {
                val span = (b.positionFraction - a.positionFraction).coerceAtLeast(0.0001f)
                val t = ((frac - a.positionFraction) / span).coerceIn(0f, 1f)
                return (a.speed + (b.speed - a.speed) * t).coerceIn(0.25f, 8f)
            }
        }
        return constantSpeed.coerceIn(0.25f, 8f)
    }

    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long {
        if (sortedPoints.size < 2 || durationUs <= 0L) return C.TIME_UNSET
        val next = ((timeUs / stepUs) + 1L) * stepUs
        return if (next >= durationUs) C.TIME_UNSET else next
    }
}
