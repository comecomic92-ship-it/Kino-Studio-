package com.kinostudio.feature.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import com.kinostudio.core.model.ColorGradingConfig
import com.kinostudio.core.model.VisualClipItem

@OptIn(UnstableApi::class)
class DynamicBitmapOverlay(
    private val context: Context,
    private val width: Int,
    private val height: Int,
    private val upperClipsProvider: () -> List<VisualClipItem>,
    private val globalColorGrading: ColorGradingConfig,
    private val textDrawer: ((Canvas, Int, Int, Long) -> Unit)? = null
) : BitmapOverlay() {

    private val bufferA = Bitmap.createBitmap(width.coerceAtLeast(2), height.coerceAtLeast(2), Bitmap.Config.ARGB_8888)
    private val bufferB = Bitmap.createBitmap(width.coerceAtLeast(2), height.coerceAtLeast(2), Bitmap.Config.ARGB_8888)
    private var useA = true
    private var lastBucket: Long = Long.MIN_VALUE
    private val imageCache = mutableMapOf<String, Bitmap>()
    private val videoRetrievers = mutableMapOf<String, MediaMetadataRetriever>()

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val globalTimeMs = presentationTimeUs / 1000L
        val bucket = globalTimeMs / 33L
        if (bucket == lastBucket) return if (useA) bufferA else bufferB
        lastBucket = bucket
        useA = !useA
        val target = if (useA) bufferA else bufferB
        val canvas = Canvas(target)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val activeClips = upperClipsProvider().filter {
            !it.isHidden && globalTimeMs in it.timelineStartMs..it.timelineEndMs
        }
        for (clip in activeClips) {
            if (clip.transform.opacity <= 0.01f) continue
            val bmp = if (clip.isImage) {
                val cached = imageCache[clip.activeUri]
                if (cached != null && !cached.isRecycled) {
                    cached
                } else {
                    val decoded = decodeAlphaBitmap(clip.activeUri, maxOf(width, height)) ?: continue
                    imageCache[clip.activeUri] = decoded
                    decoded
                }
            } else {
                val rgbUri = clip.activeUri
                val retriever = videoRetrievers.getOrPut(rgbUri) {
                    MediaMetadataRetriever().apply { runCatching { setDataSource(context, Uri.parse(rgbUri)) } }
                }
                val localMs = (globalTimeMs - clip.timelineStartMs).coerceAtLeast(0L)
                val sourceUs = (clip.trimStartMs + (localMs * clip.speed).toLong()) * 1000L
                val rawRgb = runCatching {
                    retriever.getFrameAtTime(sourceUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }.getOrNull() ?: continue

                val maskUri = clip.bgMaskUri
                if (clip.hasTransparentVideoMask && !maskUri.isNullOrBlank()) {
                    val maskRet = videoRetrievers.getOrPut(maskUri) {
                        MediaMetadataRetriever().apply { runCatching { setDataSource(context, Uri.parse(maskUri)) } }
                    }
                    val maskUs = ((localMs * clip.speed).toLong()) * 1000L
                    val maskBmp = runCatching {
                        maskRet.getFrameAtTime(maskUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }.getOrNull()
                    if (maskBmp != null) {
                        val masked = AiBackgroundProcessor.applyGrayscaleMaskToBitmap(rawRgb, maskBmp)
                        rawRgb.recycle()
                        maskBmp.recycle()
                        masked
                    } else rawRgb
                } else {
                    rawRgb
                }
            }
            drawTransformedBitmap(canvas, bmp, clip)
            if (!clip.isImage && !bmp.isRecycled) bmp.recycle()
        }

        textDrawer?.invoke(canvas, width, height, globalTimeMs)
        return target
    }

    private fun drawTransformedBitmap(canvas: Canvas, bmp: Bitmap, clip: VisualClipItem) {
        val tf = clip.transform
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (tf.opacity.coerceIn(0f, 1f) * 255f).toInt().coerceIn(0, 255)
            val merged = ColorMatrixUtil.merge(globalColorGrading, clip.colorGrading)
            if (!merged.isIdentity()) colorFilter = ColorMatrixColorFilter(ColorMatrixUtil.buildColorMatrix(merged))
        }
        val fitScale = minOf(width.toFloat() / bmp.width.coerceAtLeast(1).toFloat(), height.toFloat() / bmp.height.coerceAtLeast(1).toFloat())
        val baseW = bmp.width * fitScale
        val baseH = bmp.height * fitScale
        val matrix = Matrix()
        if (tf.hasPerspective()) {
            val src = floatArrayOf(0f, 0f, bmp.width.toFloat(), 0f, 0f, bmp.height.toFloat(), bmp.width.toFloat(), bmp.height.toFloat())
            val dst = floatArrayOf(
                tf.tlX.coerceIn(-0.38f, 0.38f) * baseW, tf.tlY.coerceIn(-0.38f, 0.38f) * baseH,
                baseW + tf.trX.coerceIn(-0.38f, 0.38f) * baseW, tf.trY.coerceIn(-0.38f, 0.38f) * baseH,
                tf.blX.coerceIn(-0.38f, 0.38f) * baseW, baseH + tf.blY.coerceIn(-0.38f, 0.38f) * baseH,
                baseW + tf.brX.coerceIn(-0.38f, 0.38f) * baseW, baseH + tf.brY.coerceIn(-0.38f, 0.38f) * baseH
            )
            if (!matrix.setPolyToPoly(src, 0, dst, 0, 4)) matrix.postScale(fitScale, fitScale)
        } else {
            matrix.postScale(fitScale, fitScale)
        }
        matrix.postTranslate(-baseW / 2f, -baseH / 2f)
        matrix.postScale(tf.scaleX.coerceIn(0.1f, 5f) * if (tf.flipH) -1f else 1f, tf.scaleY.coerceIn(0.1f, 5f) * if (tf.flipV) -1f else 1f)
        matrix.postRotate(tf.rotationDeg)
        matrix.postTranslate(width * (0.5f + tf.offsetX), height * (0.5f + tf.offsetY))
        canvas.drawBitmap(bmp, matrix, paint)
    }

    private fun decodeAlphaBitmap(uriString: String, maxDim: Int): Bitmap? = runCatching {
        val uri = Uri.parse(uriString)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }.getOrNull()

    override fun release() {
        super.release()
        imageCache.values.forEach { if (!it.isRecycled) it.recycle() }
        imageCache.clear()
        videoRetrievers.values.forEach { runCatching { it.release() } }
        videoRetrievers.clear()
        if (!bufferA.isRecycled) bufferA.recycle()
        if (!bufferB.isRecycled) bufferB.recycle()
    }
}
